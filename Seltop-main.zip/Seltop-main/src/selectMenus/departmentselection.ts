import { ActionRowBuilder, StringSelectMenuBuilder, StringSelectMenuInteraction } from "discord.js";
import config from "../config.js"
import { error } from "../utils/logging.js";

export default {
    id: "departmentselection",
    function: async function ({ interaction, choices }: { interaction: StringSelectMenuInteraction, choices: string[] }) {
        const department = config.departments.find(department => department.id === choices[0]);

        const roleSelection = new StringSelectMenuBuilder().setCustomId("roleselection").setPlaceholder("Please select 1 role").setMinValues(1).setMaxValues(1).addOptions(
            department.specialties.map((role) => ({ label: role.name, value: `${role.id}-${Math.random() * 1000}`, emoji: role.emoji, description: role.description }))
        );

        await interaction.update({ content: "**Please select the roles you want to buy from...**", components: [new ActionRowBuilder<StringSelectMenuBuilder>().addComponents(roleSelection)] }).catch(error);
    }
}