import { ActionRowBuilder, StringSelectMenuBuilder, StringSelectMenuInteraction, StringSelectMenuOptionBuilder } from "discord.js";
import database from "../handlers/databaseHandler.js";
import PublicVoting from "../tables/PublicVoting.js";
import PublicVote from "../tables/PublicVote.js";
import Submission from "../tables/Submission.js";

export default {
    id: "publicVote",
    function: async function({ interaction }: { interaction: StringSelectMenuInteraction }) {
        await interaction.deferReply({ ephemeral: true });

        const vote = interaction.values[0];
        const publicVoting = await database.manager.findOne(PublicVoting, { where: { message: interaction.message.id } });

        if (!publicVoting) return await interaction.editReply({ content: ":x: **There is no public voting for this message.**" });

        const alreadyVoted = await database.manager.findOne(PublicVote, { where: { user: interaction.user.id, competition: publicVoting.competition } });
        
        if (alreadyVoted) {
            await database.manager.update(PublicVote, { user: interaction.user.id, competition: publicVoting.competition }, { submission: Number(vote) });
            const submissions = await database.manager.find(Submission, { where: { competition: publicVoting.competition } });
            const votes = await database.manager.find(PublicVote, { where: { competition: publicVoting.competition } });

            const publicVotingRow = new ActionRowBuilder<StringSelectMenuBuilder>().addComponents(
                new StringSelectMenuBuilder()
                    .setCustomId("publicVote")
                    .setPlaceholder("Select a submission")
                    .addOptions(submissions.map((s) => new StringSelectMenuOptionBuilder().setLabel(`Vote for the submission ID: ${s.id} - Votes: ${votes.filter((v) => v.submission == s.id).length}`).setValue(s.id.toString())))
            );

            await interaction.message.edit({ components: [publicVotingRow] });
            await interaction.editReply({ content: `:white_check_mark: **Your vote has been updated to submission ID: \`${vote}\`.**` });
        } else {
            await database.manager.insert(PublicVote, { user: interaction.user.id, competition: publicVoting.competition, submission: Number(vote) });
            const submissions = await database.manager.find(Submission, { where: { competition: publicVoting.competition } });
            const votes = await database.manager.find(PublicVote, { where: { competition: publicVoting.competition } });

            const publicVotingRow = new ActionRowBuilder<StringSelectMenuBuilder>().addComponents(
                new StringSelectMenuBuilder()
                    .setCustomId("publicVote")
                    .setPlaceholder("Select a submission")
                    .addOptions(submissions.map((s) => new StringSelectMenuOptionBuilder().setLabel(`Vote for the submission ID: ${s.id} - Votes: ${votes.filter((v) => v.submission == s.id).length}`).setValue(s.id.toString())))
            );

            await interaction.message.edit({ components: [publicVotingRow] });
            await interaction.editReply({ content: `:white_check_mark: **Your vote has been casted to submission ID: \`${vote}\`.**` });
        }
    }
}