import { ActionRowBuilder, ModalBuilder, StringSelectMenuInteraction, TextInputBuilder, TextInputStyle } from "discord.js";
import database from "../handlers/databaseHandler.js";
import Application from "../tables/Application.js";
import { error } from "../utils/logging.js";
import config from "../config.js";

export default {
    id: "staffroleselection",
    function: async function ({ interaction, choices: roles }: { interaction: StringSelectMenuInteraction, choices: string[] }) {
        await database.manager.insert(Application, {
            user: interaction.user.id,
            guild: interaction.guild.id,
            roles: JSON.stringify(roles),
            answers: "[]",
            status: "answering",
            createdAt: Date.now()
        });

        const modal = new ModalBuilder().addComponents(
            config.staffQuestions.slice(0, 5).map((question, i) => new ActionRowBuilder<TextInputBuilder>().addComponents(new TextInputBuilder().setPlaceholder(question.question).setRequired(true).setLabel(question.question).setStyle(question.short ? TextInputStyle.Short : TextInputStyle.Paragraph).setCustomId(`question-${i}`)))
        ).setTitle("Apply as a staff member.").setCustomId("staffapply")

        await interaction.showModal(modal).catch(error);
    }
}
