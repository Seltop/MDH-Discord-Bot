import { ActionRowBuilder, ButtonBuilder, StringSelectMenuInteraction } from "discord.js";
import { buildButton } from "../utils/configBuilders.js";

export default {
    id: "scheduleType",
    function: async function({ interaction, choices }: { interaction: StringSelectMenuInteraction, choices: string[] }) {
        const type = choices[0];

        if (type == "embed") {
            const row = new ActionRowBuilder<ButtonBuilder>().addComponents(
                buildButton("scheduleEmbedName")
            );

            return interaction.update({ content: "**Please input the embed name through the button below.**", components: [row] });
        } else if (type == "message") {
            const row = new ActionRowBuilder<ButtonBuilder>().addComponents(
                buildButton("scheduleMessage")
            );

            return interaction.update({ content: "**Please input the message through the button below.**", components: [row] });
        }
    }
}