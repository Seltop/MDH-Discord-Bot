import { StringSelectMenuInteraction } from "discord.js";
import config from "../config.js";
import database from "../handlers/databaseHandler.js";
import Application from "../tables/Application.js";
import { buildEmbed } from "../utils/configBuilders.js";

export default {
    id: "roleselectionaccept",
    function: async function ({ interaction, choices: roles }: { interaction: StringSelectMenuInteraction, choices: string[] }) {
        const application = await database.manager.findOne(Application, { where: { channel: interaction.channelId } });

        if (!application) return await interaction.reply({ content: ":x: **This channel is not an application channel.**", ephemeral: true });

        const user = await interaction.guild.members.fetch(application.user);
        
        if (!user) return await interaction.reply({ content: ":x: **The user that applied for this application is not in the server anymore.**", ephemeral: true });

        const acceptedEmbed = buildEmbed("applicationAccepted").addFields([
            {
                name: "User",
                value: `<@${application.user}>`
            },
            {
                name: "Roles",
                value: roles.map((role) => `<@&${role}>`).join(", ")
            }
        ])

        await interaction.reply({ content: `<@${application.user}>`, embeds: [acceptedEmbed] });

        const departmentsFromRoles = [];

        for (const department of config.departments) {
            for (const role of roles) {
                if (department.specialties.filter((specialty) => specialty.id === role).length > 0) {
                    departmentsFromRoles.push(department);
                }
            }
        }

        for (const department of config.staffDepartments) {
            for (const role of roles) {
                if (department.specialties.filter((specialty) => specialty.id === role).length > 0) {
                    departmentsFromRoles.push(department);
                }
            }
        }

        roles.forEach(async (role) => {
            const guildRole = interaction.guild.roles.cache.get(role);
            await user.roles.add(guildRole);
        });

        // add the department roles
        departmentsFromRoles.forEach(async (department) => {
            await user.roles.add(department.id);
        });

        const { client } = await import("../index.js");

        for (const server of config.otherServers) {
            const guild = await client.guilds.fetch(server).catch(() => null);
            if (!guild?.members) continue;

            await guild.roles.fetch();

            const member = await guild.members.fetch(application.user).catch(() => null);
            if (!member) continue;

            roles.forEach(async (role) => {
                const roleObject = guild.roles.cache.find((r) => r.name.toLowerCase() === interaction.guild.roles.cache.get(role).name.toLowerCase());
                if (!roleObject) return;
                await member.roles.add(roleObject);
            });

            departmentsFromRoles.forEach(async (department) => {
                const roleObject = guild.roles.cache.find((r) => r.name.toLowerCase() === interaction.guild.roles.cache.get(department.id).name.toLowerCase());
                if (!roleObject) return;
                await member.roles.add(roleObject);
            });
        }
    }
}