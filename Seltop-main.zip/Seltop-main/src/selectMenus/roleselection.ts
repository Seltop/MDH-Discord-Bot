import { ActionRowBuilder, ModalBuilder, StringSelectMenuInteraction, TextInputBuilder, TextInputStyle } from "discord.js";
// import { Commission } from "../database/schemas.js";
import database from "../handlers/databaseHandler.js";
import Commission from "../tables/Commission.js";
import { error } from "../utils/logging.js";
import config from "../config.js";

export default {
    id: "roleselection",
    function: async function ({ interaction, choices: roles }: { interaction: StringSelectMenuInteraction, choices: string[] }) {
        roles = roles.map(choice => choice.split("-")[0]);

        const departments = [];

        for (const department of config.departments) {
            for (const role of roles) {
                if (department.specialties.filter((specialty) => specialty.id === role).length > 0) {
                    departments.push(department);
                }
            }
        }

        const specialty = departments[0].specialties.filter((specialty) => roles.includes(specialty.id))[0];
        const questions = specialty.questions || departments[0].questions;

        const rolesFromDepartments = [];

        rolesFromDepartments.push(...departments[0].specialties.filter((specialty) => roles.includes(specialty.id)));
        
        await database.manager.insert(Commission, {
            user: interaction.user.id,
            guild: interaction.guild.id,
            roles: JSON.stringify(roles),
            mainRoles: JSON.stringify(rolesFromDepartments.map((role) => role.mainServerRole)),
            answers: "[]",
            channel: null,
            status: "answering",
            freelancer: null,
            createdAt: Date.now()
        });

        const modal = new ModalBuilder().addComponents(
            questions.slice(0, 5).map((question, i) =>  new ActionRowBuilder().addComponents(new TextInputBuilder().setPlaceholder(question.question).setRequired(true).setLabel(question.question).setStyle(question.short ? TextInputStyle.Short : TextInputStyle.Paragraph).setCustomId(`question-${i}`)))
        ).setTitle("Create a new commission.").setCustomId("newcommission")

        await interaction.showModal(modal).catch(error);
    }
}