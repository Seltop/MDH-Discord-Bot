import { ActionRowBuilder, ButtonBuilder, ChannelSelectMenuInteraction } from "discord.js";
import database from "../handlers/databaseHandler.js";
import Schedule from "../tables/Schedule.js";
import { buildButton, buildEmbed } from "../utils/configBuilders.js";

export default {
    id: "scheduleEmbedChannel",
    function: async function({ interaction }: { interaction: ChannelSelectMenuInteraction }) {
        const schedule = await database.manager.findOne(Schedule, { where: { id: interaction.message.id } });
        if (!schedule) return interaction.reply({ content: ":x: **Could not find that schedule.**", ephemeral: true });

        const channel = interaction.values[0];
        if (!channel) return interaction.reply({ content: ":x: **You did not select a channel.**", ephemeral: true });

        schedule.channel = channel;
        schedule.lastModified = Date.now();
        await database.manager.save(schedule);

        const confirmationEmbed = buildEmbed("confirmSchedule")
            .setDescription(`**Please check all of the following date then confirm the schedule.**\n\n**Name:** \`${schedule.name}\`\n**Date:** <t:${Math.round(schedule.date / 1000)}>\n**Channel:** <#${channel}>\n**Type:** ${schedule.type}\n${schedule.type == "embed" ? `**Embed:** \`${schedule.embed}\`` : `**Message:** \`${schedule.message}\``}`);

        const row = new ActionRowBuilder<ButtonBuilder>().addComponents(
            buildButton("confirmSchedule"),
            buildButton("cancelSchedule")
        );

        await interaction.deferUpdate();
        await interaction.message.edit({ content: null, embeds: [confirmationEmbed], components: [row] });
    }
}