import { Invoices } from "paypal-invoices";
import config from "../config.js";

export default {
    function: async function (client) {
        const paypal = new Invoices(config.paypal.clientId, config.paypal.clientSecret, config.paypal.sandbox);

        client.paypal = paypal;

        paypal.defaultInvoicer({
            invoicer: {
                email_address: config.paypal.email,
                name: {
                    given_name: config.paypal.given_name,
                    surname: config.paypal.surname
                },
                additional_notes: "This payment is for a commission."
            }
        });
    }
}