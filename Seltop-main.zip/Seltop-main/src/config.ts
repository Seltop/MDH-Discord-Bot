export default {
    token: "",
    prefix: "-",
    debugMode: true,
    database: {
        type: "mysql",
        host: "",
        port: 3306,
        username: "",
        password: "",
        database: ""
    },
    syncDatabase: false,
    resetDatabase: false,
    youtube: {
        apiKey: "",
        channel: "",
        interval: 300000
    },
    guildId: "",
    paypal: {
        clientId: "",
        clientSecret: "",
        sandbox: false,
        currency: "USD",
        given_name: "Example",
        surname: "Team",
        email: "",
        toEmail: "",
        fees: {
            fixed: 0,
            percentage: 7.0
        },
        logoImage: "https://img.freepik.com/free-icon/paypal_318-674246.jpg?w=2000",
        tos: "When ordering a service from Example Team you are aware of our terms of service https://example.com/"
    },
    stripe: {
        publicKey: "",
        secretKey: "",
        currency: "USD",
        toEmail: "",
        fees: {
            fixed: 0,
            percentage: 0
        },
        logoImage: "https://b.stripecdn.com/site-statics-srv/assets/assets/img/v3/home/twitter-80afaafee00af0bc21d345164a2a9bb6.png"
    },
    wallet: {
        freelancerCut: 0.85, // 15% cut to the server
        withdrawRequestsChannel: ""
    },
    clientRanks: [],
    support: {
        questions: [
            {
                question: "How can we help you?",
                placeholder: "Help my cat is biting me...",
                short: false,
                required: true
            }
        ],
        categories: [""],
        staffRoles: [""],
        pingRoles: [""],
        transcriptsChannel: ""
    },
    departments: [
        {
            name: "Building",
            description: "Anything and everything Minecraft building related",
            emoji: "🏗️",
            id: "",
            specialties: [
                {
                    name: "Builder",
                    description: "Creates Minecraft buildings.",
                    emoji: "🏗️",
                    id: "",
                    commissionsChannel: ""
                },
                {
                    name: "Terraformer",
                    description: "Creates Minecraft terrain.",
                    emoji: "🌎",
                    id: "",
                    commissionsChannel: ""
                },
                {
                    name: "Redstone Engineer",
                    description: "Creates redstone contraptions.",
                    emoji: "🔌",
                    id: "",
                    commissionsChannel: ""
                },
                {
                    name: "Interior Designer",
                    description: "Creates Minecraft interiors.",
                    emoji: "🏠",
                    id: "",
                    commissionsChannel: ""
                }
            ],
            freelancerChannel: "",
            cmRole: "",
            category: "",
            applicationsCategory: "",
            questions: [
                {
                    question: "Please provide full detail.",
                    placeholder: "I want this, this, this, and that.",
                    short: false,
                    required: true
                },
                {
                    question: "Do you have any reference?",
                    placeholder: "https://imgur.com/a/...",
                    short: false,
                    required: true
                },
                {
                    question: "Any additional information?",
                    placeholder: "I want it to be done in 2 weeks...",
                    short: false,
                    required: true
                },
                {
                    question: "What is the deadline for the project?",
                    placeholder: "1 week, 2 weeks, etc.",
                    short: true,
                    required: true
                },
                {
                    question: "What is your budget for the project?",
                    placeholder: "$5 minimum",
                    short: true,
                    required: true
                }
            ]
        }
    ],
    commissions: {
        staffRoles: [""], // can see all tickets
        reviewsChannel: "",
        freelancerRole: "",
        showcaseChannel: "",
        completedCategory: ""
    },
    vc: {
        categories: [""],
        roles: [""]
    },
    embedscolor: "#43A6C6",
    // applications
    freelancerQuestions: [
        // max 5
        {
            question: "Please provide a link to your portfolio(s).",
            short: true
        },
        {
            question: "How much experience do you have?",
            short: false
        },
        {
            question: "Have you worked with other teams/creators?",
            short: false
        },
        {
            question: "Please provide a link to your BBB profile.",
            short: true
        }
    ],
    staffQuestions: [
        // max 5
        {
            question: "Please provide a link to your portfolio(s).",
            short: true
        },
        {
            question: "How much experience do you have?",
            short: false
        },
        {
            question: "Have you worked with other teams/creators?",
            short: false
        },
        {
            question: "Please provide a link to your BBB profile.",
            short: true
        }
    ],
    channels: {
        transcripts: "",
        stafftranscripts: "",
        suggestions: "",
        levelUp: "",
        submissions: "",
        ties: "",
        results: ""
    },
    eloTiers: {
        tierThree: {
            elo: 1000,
            role: ""
        },
        tierTwo: {
            elo: 2500,
            role: ""
        },
        tierOne: {
            elo: 5000,
            role: ""
        }
    },
    roles: {
        applicationReviewers: "",
        client: "",
        competitionJudges: ""
    },
    staffDepartments: [
        {
            name: "Managers",
            description: "Server managers",
            emoji: "👨‍💼",
            id: "",
            specialties: [
                {
                    name: "Commission Manager",
                    description: "Apply for a commission manager position",
                    emoji: "👨‍💼",
                    id: ""
                }
            ],
            category: ""
        }
    ],
    otherServers: [],
    embeds: {
        giveaway: {
            title: "Giveaway",
            description: "React with 🎉 to enter!",
            color: "#2F3136",
            footer: {
                text: "Giveaway",
                iconURL: ""
            },
            thumbnail: "",
            image: "",
            author: {
                name: "Giveaway",
                iconURL: ""
            },
            timestamp: true
        },
        giveawayEnded: {
            title: "Giveaway Ended",
            description: "**Prize:** {prize}\n**Winners:** {winners}",
            color: "#2F3136",
            footer: {
                text: "Giveaway",
                iconURL: ""
            },
            thumbnail: "",
            image: "",
            author: {
                name: "Giveaway",
                iconURL: ""
            },
            timestamp: true
        },
        giveawayWinner: {
            title: "Giveaway Winner",
            description: "Congratulations {winner}! You won {prize}!",
            color: "#2F3136",
            footer: {
                text: "Giveaway",
                iconURL: ""
            },
            thumbnail: "",
            image: "",
            author: {
                name: "Giveaway",
                iconURL: ""
            },
            timestamp: true
        },
        confirmSchedule: {
            title: "Confirm Schedule",
            description: "",
            color: "#00ff00",
            footer: {
                text: "",
                iconURL: ""
            },
            thumbnail: "",
            image: "",
            author: {
                name: "",
                iconURL: ""
            },
            timestamp: true
        },

        supportpanel: {
            title: "Support",
            description: "Looking for support on one of our products? Or general questions?",
            color: "#43A6C6",
            footer: {
                text: "Please report any bugs to @mx1d",
                iconURL: ""
            },
            thumbnail: "",
            image: "",
            author: {
                name: "",
                iconURL: ""
            },
            timestamp: true
        },
        orderpanel: {
            title: "Commissions",
            description: "Open an order here.",
            color: "#43A6C6",
            footer: {
                text: "Please report any bugs to @mx1d",
                iconURL: ""
            },
            thumbnail: "",
            image: "",
            author: {
                name: "",
                iconURL: ""
            },
            timestamp: true
        },
        allpanel: {
            title: "",
            description: "",
            color: "#43A6C6",
            footer: {
                text: "Please report any bugs to @mx1d",
                iconURL: ""
            },
            thumbnail: "",
            image: "https://media.discordapp.net/attachments/970399585304461333/1050859344075444334/Untitled_design_4.png?ex=65eb6987&is=65d8f487&hm=503e61bff66b01292b1eec45512a1b8d03c05c268000c78375e7749f016e8248&=&format=webp&quality=lossless&width=960&height=480",
            author: {
                name: "",
                iconURL: ""
            },
            timestamp: true
        },
        support: {
            title: "Support",
            description: "A member of our staff team will be with you shortly!",
            color: "#43A6C6",
            footer: {
                text: "Please report any bugs to @mx1d",
                iconURL: ""
            },
            thumbnail: "",
            image: "",
            author: {
                name: "",
                iconURL: ""
            },
            timestamp: true,
            inline: false
        },
        ticketOpened: {
            title: "Ticket Opened",
            description: "Your ticked has been opened.",
            color: "#43A6C6",
            footer: {
                text: "Please report any bugs to @mx1d",
                iconURL: ""
            },
            thumbnail: "",
            image: "",
            author: {
                name: "",
                iconURL: ""
            },
            timestamp: true,
            inline: false
        },
        userAdded: {
            title: "User Added",
            description: "Successfully added the user to the ticket.",
            color: "#43A6C6",
            footer: {
                text: "Please report any bugs to @mx1d",
                iconURL: ""
            },
            thumbnail: "",
            image: "",
            author: {
                name: "",
                iconURL: ""
            },
            timestamp: true
        },
        userRemoved: {
            title: "User Removed",
            description: "Successfully removed the user from the ticket.",
            color: "#43A6C6",
            footer: {
                text: "Please report any bugs to @mx1d",
                iconURL: ""
            },
            thumbnail: "",
            image: "",
            author: {
                name: "",
                iconURL: ""
            },
            timestamp: true
        },
        commissionCreated: {
            title: "Commission Created",
            description: "Your commission has been created.",
            color: "#43A6C6",
            footer: {
                text: "Please report any bugs to @mx1d",
                iconURL: ""
            },
            thumbnail: "",
            image: "",
            author: {
                name: "",
                iconURL: ""
            },
            timestamp: true
        },
        commission: {
            title: "Commission",
            description: "Thanks for your interest in our services!",
            color: "#43A6C6",
            footer: {
                text: "Please report any bugs to @mx1d",
                iconURL: ""
            },
            thumbnail: "",
            image: "",
            author: {
                name: "",
                iconURL: ""
            },
            timestamp: true
        },
        newCommissionFreelancers: {
            title: "New Commission",
            description: "A new commission has been created!",
            color: "#43A6C6",
            footer: {
                text: "Please report any bugs to @mx1d",
                iconURL: ""
            },
            thumbnail: "",
            image: "",
            author: {
                name: "",
                iconURL: ""
            },
            timestamp: true
        },
        newCommissionCM: {
            title: "New Commission",
            description: "A new commission has been created!",
            color: "#43A6C6",
            footer: {
                text: "Please report any bugs to @mx1d",
                iconURL: ""
            },
            thumbnail: "",
            image: "",
            author: {
                name: "",
                iconURL: ""
            },
            timestamp: true
        },
        quote: {
            title: "Quote",
            description: "Thanks for your interest in our services!",
            color: "#43A6C6",
            footer: {
                text: "Please report any bugs to @mx1d",
                iconURL: ""
            },
            thumbnail: "",
            image: "",
            timestamp: true
        },
        quoteAcceptedDM: {
            title: "Quote Accepted",
            description: "Your quote has been accepted!",
            color: "#43A6C6",
            footer: {
                text: "Please report any bugs to @mx1d",
                iconURL: ""
            },
            thumbnail: "",
            image: "",
            author: {
                name: "",
                iconURL: ""
            },
            timestamp: true
        },
        quoteAcceptedTicket: {
            title: "Quote Accepted",
            description: "The quote has been accepted!",
            color: "#43A6C6",
            footer: {
                text: "Please report any bugs to @mx1d",
                iconURL: ""
            },
            thumbnail: "",
            image: "",
            author: {
                name: "",
                iconURL: ""
            },
            timestamp: true
        },
        quoteDeclinedDM: {
            title: "Quote Declined",
            description: "Your quote has been declined.",
            color: "#43A6C6",
            footer: {
                text: "Please report any bugs to @mx1d",
                iconURL: ""
            },
            thumbnail: "",
            image: "",
            author: {
                name: "",
                iconURL: ""
            },
            timestamp: true
        },
        quoteDeclinedTicket: {
            title: "Quote Declined",
            description: "The quote has been declined.",
            color: "#43A6C6",
            footer: {
                text: "Please report any bugs to @mx1d",
                iconURL: ""
            },
            thumbnail: "",
            image: "",
            author: {
                name: "",
                iconURL: ""
            },
            timestamp: true
        },
        counteroffer: {
            title: "Counteroffer",
            color: "#43A6C6",
            footer: {
                text: "Please report any bugs to @mx1d",
                iconURL: ""
            },
            thumbnail: "",
            image: "",
            author: {
                name: "",
                iconURL: ""
            },
            timestamp: true
        },
        counterofferAccepted: {
            title: "Counteroffer Accepted",
            description: "The counteroffer has been accepted!",
            color: "#43A6C6",
            footer: {
                text: "Please report any bugs to @mx1d",
                iconURL: ""
            },
            thumbnail: "",
            image: "",
            author: {
                name: "",
                iconURL: ""
            },
            timestamp: true
        },
        counterofferDeclined: {
            title: "Counteroffer Declined",
            description: "The counteroffer has been declined.",
            color: "#43A6C6",
            footer: {
                text: "Please report any bugs to @mx1d",
                iconURL: ""
            },
            thumbnail: "",
            image: "",
            author: {
                name: "",
                iconURL: ""
            },
            timestamp: true
        },
        message: {
            title: "Message",
            color: "#43A6C6",
            footer: {
                text: "Please report any bugs to @mx1d",
                iconURL: ""
            },
            thumbnail: "",
            image: "",
            timestamp: true
        },
        vcRequest: {
            title: "Voice Channel Request",
            description: "A user has requested a voice channel!",
            color: "#43A6C6",
            footer: {
                text: "Please report any bugs to @mx1d",
                iconURL: ""
            },
            thumbnail: "",
            image: "",
            author: {
                name: "",
                iconURL: ""
            },
            timestamp: true
        },
        vcAccepted: {
            title: "Voice Channel Accepted",
            description: "Your voice channel request has been accepted!\n\nNOTE: Once the channel is empty it will be deleted.",
            color: "#43A6C6",
            footer: {
                text: "Please report any bugs to @mx1d",
                iconURL: ""
            },
            thumbnail: "",
            image: "",
            author: {
                name: "",
                iconURL: ""
            },
            timestamp: true
        },
        vcDeclined: {
            title: "Voice Channel Declined",
            description: "Your voice channel request has been declined.",
            color: "#43A6C6",
            footer: {
                text: "Please report any bugs to @mx1d",
                iconURL: ""
            },
            thumbnail: "",
            image: "",
            author: {
                name: "",
                iconURL: ""
            },
            timestamp: true
        },
        vcDeclinedTicket: {
            title: "Voice Channel Declined",
            description: "The voice channel request has been declined.",
            color: "#43A6C6",
            footer: {
                text: "Please report any bugs to @mx1d",
                iconURL: ""
            },
            thumbnail: "",
            image: "",
            author: {
                name: "",
                iconURL: ""
            },
            timestamp: true
        },
        vcCreated: {
            title: "Voice Channel Created",
            description: "Your voice channel has been created!\n\nNOTE: Once the channel is empty it will be deleted.",
            color: "#43A6C6",
            footer: {
                text: "Please report any bugs to @mx1d",
                iconURL: ""
            },
            thumbnail: "",
            image: "",
            author: {
                name: "",
                iconURL: ""
            },
            timestamp: true
        },
        voiceDeleted: {
            title: "Voice Channel Deleted",
            description: "A voice channel you had with a freelancer has been deleted due to being empty.",
            color: "#43A6C6",
            footer: {
                text: "Please report any bugs to @mx1d",
                iconURL: ""
            },
            thumbnail: "",
            image: "",
            author: {
                name: "",
                iconURL: ""
            },
            timestamp: true
        },
        voiceDeletedDM: {
            title: "Voice Channel Deleted",
            description: "A voice channel you had with a client has been deleted due to being empty.",
            color: "#43A6C6",
            footer: {
                text: "Please report any bugs to @mx1d",
                iconURL: ""
            },
            thumbnail: "",
            image: "",
            author: {
                name: "",
                iconURL: ""
            },
            timestamp: true
        },
        commissionClaimed: {
            title: "Commission Claimed",
            description: "A commission manager has claimed your commission!",
            color: "#43A6C6",
            footer: {
                text: "Please report any bugs to @mx1d",
                iconURL: ""
            },
            thumbnail: "",
            image: "",
            author: {
                name: "",
                iconURL: ""
            },
            timestamp: true
        },
        invoiceChoice: {
            title: "Invoice Choice",
            description: "Please choose a payment method from below.",
            color: "#43A6C6",
            footer: {
                text: "Please report any bugs to @mx1d",
                iconURL: ""
            },
            thumbnail: "",
            image: "",
            author: {
                name: "",
                iconURL: ""
            },
            timestamp: true
        },
        invoiceerror: {
            title: "Invoice Error",
            description: "There was an error creating your invoice. Please try again.",
            color: "#43A6C6",
            footer: {
                text: "Please report any bugs to @mx1d",
                iconURL: ""
            },
            thumbnail: "",
            image: "",
            author: {
                name: "",
                iconURL: ""
            },
            timestamp: true
        },
        invoicecreated: {
            title: "Invoice Created",
            description: "Your invoice has been created.",
            color: "#43A6C6",
            footer: {
                text: "Please report any bugs to @mx1d",
                iconURL: ""
            },
            thumbnail: "",
            image: "",
            author: {
                name: "",
                iconURL: ""
            },
            timestamp: true
        },
        invoicePaid: {
            title: "Invoice Paid",
            description: "Your invoice has been paid.",
            color: "#43A6C6",
            footer: {
                text: "Please report any bugs to @mx1d",
                iconURL: ""
            },
            thumbnail: "",
            image: "",
            author: {
                name: "",
                iconURL: ""
            },
            timestamp: true
        },
        startReview: {
            title: "Start Review",
            description: "Please start your review by clicking the button below.",
            color: "#43A6C6",
            footer: {
                text: "Please report any bugs to @mx1d",
                iconURL: ""
            },
            thumbnail: "",
            image: "",
            author: {
                name: "",
                iconURL: ""
            },
            timestamp: true
        },
        reviewComplete: {
            title: "Review Complete",
            description: "Your review has been completed. Thank you for your feedback!",
            color: "#43A6C6",
            footer: {
                text: "Please report any bugs to @mx1d",
                iconURL: ""
            },
            thumbnail: "",
            image: "",
            author: {
                name: "",
                iconURL: ""
            },
            timestamp: true
        },
        newReview: {
            title: "New Review",
            description: "",
            color: "#43A6C6",
            footer: {
                text: "Please report any bugs to @mx1d",
                iconURL: ""
            },
            thumbnail: "",
            image: "",
            author: {
                name: "",
                iconURL: ""
            },
            timestamp: true
        },
        paymentComplete: {
            title: "Payment Complete",
            description: "Your payment has been completed. Thank you for your business!",
            color: "#43A6C6",
            footer: {
                text: "Please report any bugs to @mx1d",
                iconURL: ""
            },
            thumbnail: "",
            image: "",
            author: {
                name: "",
                iconURL: ""
            },
            timestamp: true
        },
        wallet: {
            title: "Wallet",
            description: "",
            color: "#43A6C6",
            footer: {
                text: "For security purposes this message will disabled in 5 mins.",
                iconURL: ""
            },
            thumbnail: "",
            image: "",
            author: {
                name: "",
                iconURL: ""
            },
            timestamp: true
        },
        transactions: {
            title: "Transactions",
            description: "",
            color: "#43A6C6",
            footer: {
                text: "Please report any bugs to @mx1d",
                iconURL: ""
            },
            thumbnail: "",
            image: "",
            author: {
                name: "",
                iconURL: ""
            },
            timestamp: true
        },
        withdrawalRequest: {
            title: "Withdrawal Request",
            description: "A withdrawal request has been made.",
            color: "#43A6C6",
            footer: {
                text: "Please report any bugs to @mx1d",
                iconURL: ""
            },
            thumbnail: "",
            image: "",
            author: {
                name: "",
                iconURL: ""
            },
            timestamp: true
        },
        withdrawalAccepted: {
            title: "Withdrawal Accepted",
            description: "Your withdrawal request has been accepted.",
            color: "#43A6C6",
            footer: {
                text: "Please report any bugs to @mx1d",
                iconURL: ""
            },
            thumbnail: "",
            image: "",
            author: {
                name: "",
                iconURL: ""
            },
            timestamp: true
        },
        withdrawalDenied: {
            title: "Withdrawal Denied",
            description: "Your withdrawal request has been denied.",
            color: "#43A6C6",
            footer: {
                text: "Please report any bugs to @mx1d",
                iconURL: ""
            },
            thumbnail: "",
            image: "",
            author: {
                name: "",
                iconURL: ""
            },
            timestamp: true
        },
        askShowcase: {
            title: "Showcase",
            description: "Would you like to submit an image to showcase your work?",
            color: "#43A6C6",
            footer: {
                text: "Please report any bugs to @mx1d",
                iconURL: ""
            },
            thumbnail: "",
            image: "",
            author: {
                name: "",
                iconURL: ""
            },
            timestamp: true
        },
        showcase: {
            title: "Showcase",
            description: "NEW! Some showcase images just dropped 👀",
            color: "#43A6C6",
            footer: {
                text: "Please report any bugs to @mx1d",
                iconURL: ""
            },
            thumbnail: "",
            image: "",
            timestamp: true
        },
        profile: {
            title: "Profile",
            description: "",
            color: "#43A6C6",
            footer: {
                text: "Please report any bugs to @mx1d",
                iconURL: ""
            },
            thumbnail: "",
            image: "",
            author: {
                name: "",
                iconURL: ""
            },
            timestamp: true,
        },
        freelancerPanel: {
            title: "Apply as a freelancer",
            description: "Make sure to read our ToS and follow them!",
            color: "#43A6C6",
            author: {
                name: "Freelancers",
                iconURL: ""
            },
            footer: {
                text: "Please report any bugs to @mx1d",
                iconURL: ""
            },
            image: "",
            thumbnail: "",
            timestamp: true
        },
        staffPanel: {
            title: "Apply as a staff",
            description: "Make sure to read our ToS and follow them!",
            color: "#43A6C6",
            author: {
                name: "",
                iconURL: ""
            },
            footer: {
                text: "Please report any bugs to @mx1d",
                iconURL: ""
            },
            image: "",
            thumbnail: "",
            timestamp: true
        },
        applicationCreated: {
            title: "Application Created",
            description: "Your application has been created, please wait for a reviewer to review your application.",
            color: "#43A6C6",
            author: {
                name: "",
                iconURL: ""
            },
            footer: {
                text: "Please report any bugs to @mx1d",
                iconURL: ""
            },
            image: "",
            thumbnail: "",
            timestamp: true
        },
        applicationSent: {
            title: "New Application",
            description: "A new application has been received.",
            color: "#43A6C6",
            author: {
                name: "",
                iconURL: ""
            },
            footer: {
                text: "Please report any bugs to @mx1d",
                iconURL: ""
            },
            image: "",
            thumbnail: "",
            timestamp: true
        },
        applicationAccepted: {
            title: "Application Accepted",
            description: "Your application has been accepted, welcome to the team!",
            color: "#43A6C6",
            author: {
                name: "",
                iconURL: ""
            },
            footer: {
                text: "Please report any bugs to @mx1d",
                iconURL: ""
            },
            image: "",
            thumbnail: "",
            timestamp: true
        },
        applicationDenied: {
            title: "Application Denied",
            description: "Your application has been denied, you can apply again in 2 weeks.",
            color: "#43A6C6",
            author: {
                name: "",
                iconURL: ""
            },
            footer: {
                text: "Please report any bugs to @mx1d",
                iconURL: ""
            },
            image: "",
            thumbnail: "",
            timestamp: true
        },
        level: {
            title: "User Level",
            description: "",
            color: "#43A6C6",
            author: {
                name: "",
                iconURL: ""
            },
            footer: {
                text: "Please report any bugs to @mx1d",
                iconURL: ""
            },
            image: "",
            thumbnail: "",
            timestamp: true
        },
        leaderboard: {
            title: "Leaderboard",
            description: "",
            color: "#43A6C6",
            author: {
                name: "",
                iconURL: ""
            },
            footer: {
                text: "Please report any bugs to @mx1d",
                iconURL: ""
            },
            image: "",
            thumbnail: "",
            timestamp: true
        },
        competitionStarted: {
            title: "", // Manually assigned in the command
            description: "", // Manually assigned in the command
            color: "#43A6C6",
            author: {
                name: "",
                iconURL: ""
            },
            footer: {
                text: "Please report any bugs to @mx1d",
                iconURL: ""
            },
            image: "",
            thumbnail: "",
            timestamp: true
        },
        submission: {
            title: "",
            description: "",
            color: "#43A6C6",
            author: {
                name: "",
                iconURL: ""
            },
            footer: {
                text: "Please report any bugs to @mx1d",
                iconURL: ""
            },
            image: "",
            thumbnail: "",
            timestamp: true
        },
        publicVote: {
            title: "",
            description: "",
            color: "#43A6C6",
            author: {
                name: "",
                iconURL: ""
            },
            footer: {
                text: "Please report any bugs to @mx1d",
                iconURL: ""
            },
            image: "",
            thumbnail: "",
            timestamp: true
        },
        eloDifference: {
            title: "Competition Results",
            description: "",
            color: "#43A6C6",
            author: {
                name: "",
                iconURL: ""
            },
            footer: {
                text: "Please report any bugs to @mx1d",
                iconURL: ""
            },
            image: "",
            thumbnail: "",
            timestamp: true
        }
    },
    buttons: {
        scheduleEmbedName: {
            label: "Input Embed Name",
            style: "Primary",
            emoji: "📝"
        },
        scheduleMessage: {
            label: "Input Message",
            style: "Primary",
            emoji: "📝"
        },
        scheduleEmbedDate: {
            label: "Input Date",
            style: "Primary",
            emoji: "📅"
        },
        confirmSchedule: {
            label: "Confirm Schedule",
            style: "Success",
            emoji: "✅"
        },
        cancelSchedule: {
            label: "Cancel Schedule",
            style: "Danger",
            emoji: "❌"
        },
        joinGiveaway: {
            label: "Join Giveaway!",
            style: "Primary",
            emoji: "🎉"
        },
        editGiveaway: {
            label: "",
            style: "Secondary",
            emoji: "📝"
        },
        cancelGiveaway: {
            label: "",
            style: "Danger",
            emoji: "💥"
        },
        endGiveaway: {
            label: "End",
            style: "Primary",
            emoji: "⌚"
        },
        applications: {
            label: "Applications",
            style: "Primary",
            emoji: "📝"
        },
        support: {
            label: "Support",
            style: "Primary",
            emoji: "🎫"
        },
        order: {
            label: "Order",
            style: "Primary",
            emoji: "📦"
        },
        quote: {
            label: "Quote",
            style: "Primary",
            emoji: "💰"
        },
        toggleNotifications: {
            label: "Toggle Notifications",
            style: "Secondary",
            emoji: "🔔"
        },
        messagefreelancer: {
            label: "Message",
            style: "Primary",
            emoji: "💬"
        },
        vcfreelancer: {
            label: "Voice Chat",
            style: "Primary",
            emoji: "🎙️"
        },
        claimcm: {
            label: "Claim",
            style: "Primary",
            emoji: "📥"
        },
        acceptQuote: {
            label: "Accept",
            style: "Success",
            emoji: "✅"
        },
        declineQuote: {
            label: "Deny",
            style: "Danger",
            emoji: "❌"
        },
        messageQuote: {
            label: "Message",
            style: "Primary",
            emoji: "💬"
        },
        counteroffer: {
            label: "Counteroffer",
            style: "Primary",
            emoji: "💰"
        },
        reply: {
            label: "Reply",
            style: "Primary",
            emoji: "💬"
        },
        acceptCounter: {
            label: "Accept",
            style: "Success",
            emoji: "✅"
        },
        declineCounter: {
            label: "Deny",
            style: "Danger",
            emoji: "❌"
        },
        vcaccept: {
            label: "Accept",
            style: "Success",
            emoji: "✅"
        },
        vcdecline: {
            label: "Deny",
            style: "Danger",
            emoji: "❌"
        },
        paypalinvoice: {
            label: "PayPal",
            style: "Primary",
            emoji: "🅿️"
        },
        stripeinvoice: {
            label: "Stripe",
            style: "Primary",
            emoji: "💳"
        },
        startReview: {
            label: "Review",
            style: "Primary",
            emoji: "📝"
        },
        withdraw: {
            label: "Withdraw",
            style: "Primary",
            emoji: "💰"
        },
        transactions: {
            label: "Transactions",
            style: "Primary",
            emoji: "📝"
        },
        withdrawAll: {
            label: "100%",
            style: "Primary",
            emoji: "💰"
        },
        withdrawHalf: {
            label: "50%",
            style: "Primary",
            emoji: "💰"
        },
        withdrawCustom: {
            label: "Custom",
            style: "Primary",
            emoji: "💰"
        },
        WithdrawalRequestApprove: {
            label: "Approve",
            style: "Success",
            emoji: "✅"
        },
        WithdrawalRequestDeny: {
            label: "Deny",
            style: "Danger",
            emoji: "❌"
        },
        showcaseAccept: {
            label: "Accept",
            style: "Success",
            emoji: "✅"
        },
        showcaseDeny: {
            label: "Deny",
            style: "Danger",
            emoji: "❌"
        },
        freelancerapply: {
            label: "Apply",
            style: "Success",
            emoji: "📋"
        },
        staffapply: {
            label: "Apply",
            style: "Success",
            emoji: "👨‍💼"
        },
        submit: {
            label: "Submit",
            style: "Primary",
            emoji: "📩"
        },
        vote1: {
            label: "",
            style: "Primary",
            emoji: "1️⃣"
        },
        vote2: {
            label: "",
            style: "Primary",
            emoji: "2️⃣"
        },
        vote4: {
            label: "",
            style: "Primary",
            emoji: "4️⃣"
        },
        vote6: {
            label: "",
            style: "Primary",
            emoji: "6️⃣"
        },
        vote8: {
            label: "",
            style: "Primary",
            emoji: "8️⃣"
        },
        viewVotes: {
            label: "View Votes",
            style: "Primary",
            emoji: "📊"
        }
    }
}
