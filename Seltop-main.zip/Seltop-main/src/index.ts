// Package imports
import config from "./config.js";
import { error, log } from "./utils/logging.js";
import { Client, Collection, IntentsBitField, Partials } from "discord.js";
import { Invoices } from "paypal-invoices";

// Define a new class that extends Client
class CustomClient extends Client {
    cooldowns: any[] = [];
    commands: Collection<String, any> = new Collection();
    slashCommands: Collection<String, any> = new Collection();
    selectMenus: Collection<String, any> = new Collection();
    modals: Collection<String, any> = new Collection();
    contextMenus: Collection<String, any> = new Collection();
    buttons: Collection<String, any> = new Collection();
    paypal: Invoices = new Invoices(config.paypal.clientId, config.paypal.clientSecret, config.paypal.sandbox);
}

// Initialize the extended client
export const client = new CustomClient({
    intents: [IntentsBitField.Flags.Guilds, IntentsBitField.Flags.GuildMessages, IntentsBitField.Flags.MessageContent, IntentsBitField.Flags.DirectMessages],
    partials: [Partials.Message, Partials.GuildMember, Partials.Channel, Partials.Reaction, Partials.User]
});

// Command & event handlers
import eventHandler from "./handlers/eventHandler.js";
import idkHowToCallThisHandler from "./handlers/idkHowToCallThisHandler.js";
import database from "./handlers/databaseHandler.js";

if (database.isInitialized) log("Database connection established.");
idkHowToCallThisHandler.init();
eventHandler.function();

// Catching all the errors
process.on("uncaughtException", config.debugMode ? console.error : error);
process.on("unhandledRejection", config.debugMode ? console.error : error);

client.login(config.token);
