import { Entity, Column, PrimaryGeneratedColumn } from "typeorm";

@Entity()
export default class Giveaway {
    @PrimaryGeneratedColumn()
    id: number;

    @Column({ type: "varchar", nullable: false })
    guild: string;

    @Column({ type: "varchar", nullable: false })
    channel: string;

    @Column({ type: "varchar", nullable: false })
    message: string;

    @Column({ type: "varchar", nullable: false })
    prize: string;

    @Column({ type: "integer", nullable: false })
    winners: number;

    @Column({ type: "text", nullable: false })
    length: string

    @Column({ type: "bigint", nullable: false })
    startedAt: Date;

    @Column({ type: "bigint", nullable: false })
    endsAt: number;

    @Column({ type: "boolean", nullable: true })
    ended: boolean;

    @Column({ type: "text", nullable: true })
    requiredRole: string | null;
}