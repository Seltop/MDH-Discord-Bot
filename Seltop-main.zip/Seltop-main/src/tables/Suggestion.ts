import { Entity, PrimaryGeneratedColumn, Column } from "typeorm";

@Entity()
export default class Suggestion {
    @PrimaryGeneratedColumn()
    id: number;

    @Column({ type: "text" })
    message: string;

    @Column({ type: "text" })
    channel: string;

    @Column({ type: "text" })
    state: string;

    @Column({ type: "text", nullable: true })
    upvotes: string;

    @Column({ type: "text", nullable: true })
    downvotes: string;
}
