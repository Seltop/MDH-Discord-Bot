import { Entity, PrimaryGeneratedColumn, Column } from "typeorm";

@Entity()
export default class PublicVoting {
    @PrimaryGeneratedColumn()
    id: number;

    @Column()
    channel: string;

    @Column()
    message: string;

    @Column()
    competition: number;

    @Column({ type: "bigint" })
    endsAt: number;
}