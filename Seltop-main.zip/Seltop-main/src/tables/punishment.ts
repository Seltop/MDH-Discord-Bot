import { Entity, PrimaryGeneratedColumn, Column } from "typeorm";

@Entity()
export default class Punishment {
    @PrimaryGeneratedColumn()
    id: number;

    @Column()
    guildId: string;

    @Column()
    type: string;

    @Column()
    userId: string;

    @Column({ nullable: true })
    moderatorId: string;

    @Column()
    reason: string;

    @Column({ type: "bigint" })
    date: number;
}