import { Entity, PrimaryGeneratedColumn, Column } from "typeorm";

@Entity()
export default class ClientProfile {
    @PrimaryGeneratedColumn()
    id: number;

    @Column({ type: "text" })
    user: string;

    @Column({ type: "text", nullable: true })
    pastTickets: string;

    @Column({ type: "float" })
    totalSpent: number;
}
