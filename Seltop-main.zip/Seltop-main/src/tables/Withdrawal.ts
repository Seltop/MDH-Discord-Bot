import { Entity, PrimaryGeneratedColumn, Column } from "typeorm";

@Entity()
export default class Withdrawal {
    @PrimaryGeneratedColumn()
    id: string;

    @Column({ type: "text" })
    user: string;

    @Column({ type: "float" })
    amount: number;

    @Column({ type: "text" })
    status: string;

    @Column({ type: "bigint" })
    date: Number;
}
