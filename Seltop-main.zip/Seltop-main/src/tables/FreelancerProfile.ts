import { Entity, PrimaryGeneratedColumn, Column } from "typeorm";

@Entity()
export default class FreelancerProfile {
    @PrimaryGeneratedColumn()
    id: number;

    @Column({ type: "text" })
    user: string;

    @Column({ type: "text", nullable: true })
    about: string;

    @Column({ type: "text", nullable: true })
    portfolio: string;

    @Column({ type: "text", nullable: true })
    timezone: string;

    @Column({ type: "text", nullable: true })
    paypal: string;

    @Column({ type: "text", nullable: true })
    paymentMethod: string;
}
