import { Entity, PrimaryGeneratedColumn, Column } from "typeorm";

@Entity()
export default class Subscription {
    @PrimaryGeneratedColumn()
    id: number;
    
    @Column()
    user: String;

    @Column()
    platform: String;

    @Column({ nullable: true })
    live: String;

    @Column({ nullable: true })
    lastVideo: String;
}