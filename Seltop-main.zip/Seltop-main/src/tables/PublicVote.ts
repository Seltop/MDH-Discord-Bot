import { Entity, PrimaryGeneratedColumn, Column } from "typeorm";

@Entity()
export default class PublicVote {    
    @PrimaryGeneratedColumn()
    id: number;
    
    @Column()
    user: string;
    
    @Column()
    submission: number;

    @Column()
    competition: number;
}