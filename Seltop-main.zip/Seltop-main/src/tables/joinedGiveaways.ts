import { Entity, Column, PrimaryGeneratedColumn } from "typeorm";

@Entity()
export default class JoinedGiveaway {
    @PrimaryGeneratedColumn()
    id: number;

    @Column({ type: "varchar", nullable: false })
    giveaway: string;

    @Column({ type: "varchar", nullable: false })
    user: string;
}