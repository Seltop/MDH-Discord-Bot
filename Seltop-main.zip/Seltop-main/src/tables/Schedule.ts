import { Entity, PrimaryColumn, Column } from "typeorm";

@Entity()
export default class Schedule {
    @PrimaryColumn({ type: "varchar" })
    id: string;

    @Column({ type: "varchar", nullable: false })
    guild: string;

    @Column({ type: "varchar", nullable: false })
    name: string;

    @Column({ type: "varchar", nullable: false })
    type: string;

    @Column({ type: "varchar", nullable: true })
    message: string;

    @Column({ type: "varchar", nullable: true })
    channel: string;

    @Column({ type: "varchar", nullable: true })
    embed: string;

    @Column({ type: "bigint", nullable: true })
    date: number;

    @Column({ type: "bigint", nullable: true })
    lastModified: number;

    @Column({ type: "boolean", nullable: true })
    active: boolean;
}