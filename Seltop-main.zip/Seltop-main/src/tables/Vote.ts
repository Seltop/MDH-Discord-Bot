import { Entity, PrimaryGeneratedColumn, Column } from "typeorm";

@Entity()
export default class Vote {
    @PrimaryGeneratedColumn()
    id: number;

    @Column()
    user: string;

    @Column()
    submission: number;

    @Column()
    amount: number;
}