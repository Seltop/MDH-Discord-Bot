import { Entity, PrimaryGeneratedColumn, Column } from "typeorm";

@Entity()
export default class LevelVC {
    @PrimaryGeneratedColumn()
    id: number;

    @Column()
    user: string;

    @Column()
    guildId: string;

    @Column()
    level: number;

    @Column()
    xp: number;
}