import { Entity, Column, PrimaryColumn } from "typeorm";

@Entity()
export default class Invoice {
    @PrimaryColumn()
    id: string;

    @Column({ type: "text" })
    channel: string;

    @Column({ type: "text" })
    message: string;

    @Column({ type: "text" })
    status: string;

    @Column({ type: "text" })
    number: string;

    @Column({ type: "float" })
    amount: number;

    @Column({ type: "float" })
    fees: number;

    @Column({ type: "float" })
    total: number;

    @Column({ type: "text" })
    link: string;

    @Column({ type: "text" })
    type: string;
}
