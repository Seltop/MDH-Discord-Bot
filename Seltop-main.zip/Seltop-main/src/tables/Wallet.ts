import { Entity, PrimaryGeneratedColumn, Column } from "typeorm";

@Entity()
export default class Wallet {
    @PrimaryGeneratedColumn()
    id: number;

    @Column({ type: "text" })
    user: string;

    @Column({ type: "float" })
    balance: number;

    @Column({ type: "text" })
    transactions: string;

    @Column({ type: "int" })
    commissionsDone: number;

    @Column({ type: "float" })
    amountMade: number;
}
