import { Entity, Column, PrimaryGeneratedColumn } from "typeorm";

@Entity()
export default class Panel {
    @PrimaryGeneratedColumn()
    id: number;

    @Column({ type: "varchar", nullable: false })
    guild: string;

    @Column({ type: "varchar", nullable: false })
    channel: string;

    @Column({ type: "varchar", nullable: false })
    message: string;
}