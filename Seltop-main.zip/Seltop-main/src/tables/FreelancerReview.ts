import { Entity, PrimaryGeneratedColumn, Column } from "typeorm";

@Entity()
export default class FreelancerReview {
    @PrimaryGeneratedColumn()
    id: number;

    @Column({ type: "text" })
    user: string;

    @Column({ type: "text" })
    client: string;

    @Column({ type: "text" })
    commission: string;

    @Column({ type: "text" })
    guild: string;

    @Column({ type: "float" })
    rating: number;

    @Column({ type: "text", nullable: true })
    comment: string;
}
