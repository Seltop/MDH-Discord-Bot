import { Entity, PrimaryGeneratedColumn, Column } from "typeorm";

@Entity()
export default class Showcase {
    @PrimaryGeneratedColumn()
    id: number;

    @Column({ type: "text" })
    user: string;

    @Column({ type: "text" })
    message: string;
}
