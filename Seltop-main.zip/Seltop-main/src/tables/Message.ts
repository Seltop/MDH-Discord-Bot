import { Entity, Column, PrimaryColumn } from "typeorm";

@Entity()
export default class Message {
    @PrimaryColumn()
    id: string;

    @Column({ type: "text" })
    source: string;

    @Column({ type: "text" })
    destination: string;

    @Column({ type: "text" })
    guild: string;

    @Column({ type: "text" })
    message: string;

    @Column({ type: "text", nullable: true })
    threadChannel: string;
}
