import { Entity, PrimaryGeneratedColumn, Column } from "typeorm";

@Entity()
export default class Support {
    @PrimaryGeneratedColumn()
    id: number;

    @Column({ type: "text" })
    user: string;

    @Column({ type: "text" })
    channel: string;

    @Column({ type: "text" })
    guild: string;

    @Column({ type: "text", nullable: true })
    added: string;
}
