import { Entity, PrimaryGeneratedColumn, Column } from "typeorm";

@Entity()
export default class Application {
    @PrimaryGeneratedColumn()
    id: number;

    @Column({ type: "text" })
    user: string;

    @Column({ type: "text" })
    guild: string;

    @Column({ type: "text", nullable: true })
    answers: string;

    @Column({ type: "text", nullable: true })
    roles: string;

    @Column({ type: "text" })
    status: string;

    @Column({ type: "text" })
    channel: string;

    @Column({ type: "bigint" })
    createdAt: number;
}
