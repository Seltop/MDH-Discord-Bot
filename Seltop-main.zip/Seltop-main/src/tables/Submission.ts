import { Entity, PrimaryGeneratedColumn, Column } from "typeorm";

@Entity()
export default class Submission {
    @PrimaryGeneratedColumn()
    id: number;

    @Column()
    competition: number;

    @Column()
    user: string;

    @Column()
    message: string;

    @Column({ type: "bigint" })
    submissionDate: number;
}