import { Entity, PrimaryGeneratedColumn, Column } from "typeorm";

@Entity()
export default class Invite {
    @PrimaryGeneratedColumn()
    id: number;

    @Column({ type: "varchar", nullable: false })
    guild: string;

    @Column({ type: "varchar", nullable: false })
    user: string;

    @Column({ type: "varchar", nullable: false })
    invitedBy: string;

    @Column({ type: "boolean", nullable: false })
    left: boolean;

    @Column({ type: "boolean", nullable: false })
    fake: boolean;
}