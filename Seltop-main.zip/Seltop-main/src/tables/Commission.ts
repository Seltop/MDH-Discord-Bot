import { Entity, PrimaryGeneratedColumn, Column } from "typeorm";

@Entity()
export default class Commission {
    @PrimaryGeneratedColumn()
    id: number;

    @Column({ type: "text" })
    user: string;

    @Column({ type: "text" })
    guild: string;

    @Column({ type: "text", nullable: true })
    roles: string;

    @Column({ type: "text", nullable: true })
    mainRoles: string;

    @Column({ type: "text", nullable: true })
    answers: string;

    @Column({ type: "text" })
    status: string;

    @Column({ type: "text" })
    freelancer: string;

    @Column({ type: "text" })
    manager: string;

    @Column({ type: "text" })
    channel: string;

    @Column({ type: "timestamp" })
    createdAt: Date;

    @Column({ type: "text" })
    freelancersMessage: string;

    @Column({ type: "text" })
    freelancersChannel: string;

    @Column({ type: "text" })
    cmMessage: string;

    @Column({ type: "text" })
    thread: string;

    @Column({ type: "text", nullable: true })
    declines: string;

    @Column({ type: "text", nullable: true })
    added: string;

    @Column({ type: "int", nullable: true })
    paidAmount: number;

    @Column({ type: "boolean", nullable: true })
    paidToWallet: boolean;
}
