import { Entity, PrimaryGeneratedColumn, Column } from "typeorm";

@Entity()
export default class Embed {
    @PrimaryGeneratedColumn()
    id: number;

    @Column({ type: "varchar", nullable: false })
    guild: string;

    @Column({ type: "varchar", nullable: false })
    name: string;

    @Column({ type: "varchar", nullable: true })
    title: string;

    @Column({ type: "text", nullable: true })
    description: string;

    @Column({ type: "varchar", nullable: true })
    authorText: string;

    @Column({ type: "varchar", nullable: true })
    authorImage: string;

    @Column({ type: "varchar", nullable: true })
    color: string;

    @Column({ type: "varchar", nullable: true })
    footerImage: string;

    @Column({ type: "varchar", nullable: true })
    footerText: string;

    @Column({ type: "varchar", nullable: true })
    thumbnail: string;

    @Column({ type: "varchar", nullable: true })
    largeImage: string;

    @Column({ type: "boolean", nullable: true })
    timestamp: boolean;
}