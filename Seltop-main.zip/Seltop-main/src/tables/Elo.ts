import { Entity, Column, PrimaryGeneratedColumn } from "typeorm";

@Entity()
export default class Elo {
    @PrimaryGeneratedColumn()
    id: number;

    @Column()
    user: string;

    @Column()
    elo: number;
}