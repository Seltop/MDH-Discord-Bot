import { Entity, PrimaryGeneratedColumn, Column } from "typeorm";

@Entity()
export default class Notifications {
    @PrimaryGeneratedColumn()
    id: number;

    @Column({ type: "text" })
    user: string;

    @Column()
    commission: number;
}
