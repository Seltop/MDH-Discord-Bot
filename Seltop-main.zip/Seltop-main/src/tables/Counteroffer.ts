import { Entity, Column, PrimaryColumn } from "typeorm";

@Entity()
export default class Counteroffer {
    @PrimaryColumn()
    id: string;

    @Column({ type: "text" })
    freelancer: string;

    @Column({ type: "text" })
    guild: string;

    @Column({ type: "text" })
    commission: string;

    @Column({ type: "float" })
    price: number;

    @Column({ type: "text" })
    msg: string;

    @Column()
    quote: string;
}
