import { Entity, PrimaryGeneratedColumn, Column } from "typeorm";

@Entity()
export default class Competition {
    @PrimaryGeneratedColumn()
    id: number;

    @Column()
    name: string;

    @Column()
    channel: string;

    @Column()
    message: string;

    @Column({ type: "bigint" })
    startDate: number;

    @Column()
    submissionsOpen: boolean;

    @Column({ type: "bigint" })
    judgingStartDate: number;

    @Column({ type: "bigint" })
    judgingEndDate: number;

    @Column({ nullable: true })
    completed: boolean;
}