import { ApplicationCommandOptionType, ChatInputCommandInteraction } from "discord.js";
import database from "../handlers/databaseHandler.js";
import FreelancerProfile from "../tables/FreelancerProfile.js";
import config from "../config.js";

export default {
    name: "set",
    description: "Customize your profile.",
    permissions: [],
    roleRequired: config.commissions.freelancerRole,
    options: [
        { name: "bio", description: "Set your bio.", type: ApplicationCommandOptionType.Subcommand, options: [{ name: "about", description: "Your about me.", type: ApplicationCommandOptionType.String, required: true }] },
        { name: "paypal", description: "Set your PayPal.", type: ApplicationCommandOptionType.Subcommand, options: [{ name: "paypal", description: "Your PayPal.", type: ApplicationCommandOptionType.String, required: true }] },
        { name: "timezone", description: "Set your timezone.", type: ApplicationCommandOptionType.Subcommand, options: [{ name: "timezone", description: "Your timezone.", type: ApplicationCommandOptionType.String, required: true }] },
        { name: "portfolio", description: "Set your portfolio.", type: ApplicationCommandOptionType.Subcommand, options: [{ name: "portfolio", description: "Your portfolio.", type: ApplicationCommandOptionType.String, required: true }] },
        { name: "payment-method", description: "Set your preferred payment method", type: ApplicationCommandOptionType.Subcommand, options: [{ name: "method", description: "Your preferred payment method", type: ApplicationCommandOptionType.String, required: true, choices: [{ name: "PayPal", value: "paypal" }] }] }
    ],
    function: async function ({ interaction }: { interaction: ChatInputCommandInteraction }) {
        const subcommand = interaction.options.getSubcommand();

        let data = await database.manager.findOne(FreelancerProfile, { where: { user: interaction.user.id } });
        if (!data) {
            const profile = database.manager.create(FreelancerProfile, {
                user: interaction.user.id,
                about: null,
                portfolio: null,
                timezone: null,
                paypal: null
            });
            data = await database.manager.save(profile);
        }

        switch (subcommand) {
            case "bio": {
                const about = interaction.options.getString("about");
                data.about = about;
                await database.manager.save(data);
                break;
            }
            case "paypal": {
                const paypal = interaction.options.getString("paypal");
                data.paypal = paypal;
                await database.manager.save(data);
                break;
            }
            case "timezone": {
                const timezone = interaction.options.getString("timezone");
                data.timezone = timezone;
                await database.manager.save(data);
                break;
            }
            case "portfolio": {
                const portfolio = interaction.options.getString("portfolio");
                data.portfolio = portfolio;
                await database.manager.save(data);
                break;
            }
            case "payment-method": {
                const method = interaction.options.getString("method");
                data.paymentMethod = method;
                await database.manager.save(data);
                break;
            }
        }

        await interaction.reply({ content: `:white_check_mark: **Your \`${subcommand}\` has been set!**`, ephemeral: true });
    }
}