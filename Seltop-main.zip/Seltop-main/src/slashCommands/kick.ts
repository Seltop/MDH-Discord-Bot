import { ApplicationCommandOptionType, ChatInputCommandInteraction } from "discord.js";
import database from "../handlers/databaseHandler.js";
import Punishment from "../tables/punishment.js";

export default {
    name: "kick",
    description: "Kick a user",
    options: [
        {
            name: "user",
            description: "The user to kick",
            type: ApplicationCommandOptionType.User,
            required: true
        },
        {
            name: "reason",
            description: "The reason for the kick",
            type: ApplicationCommandOptionType.String,
            required: false
        }
    ],
    permissions: ["KickMembers"],
    function: async function ({ interaction }: { interaction: ChatInputCommandInteraction }) {
        const user = interaction.options.getUser("user", true);
        const reason = interaction.options.getString("reason", false) || "No reason provided";

        await interaction.guild.members.kick(user, reason);

        await interaction.reply({ content: `:white_check_mark: **${user.tag} has been kicked.**` });

        await database.manager.insert(Punishment, {
            guildId: interaction.guildId,
            type: "kick",
            userId: user.id,
            reason,
            date: Math.round(Date.now() / 1000),
            moderatorId: interaction.user.id
        });
    }
}