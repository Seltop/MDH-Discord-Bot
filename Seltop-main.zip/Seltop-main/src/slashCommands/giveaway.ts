import { ActionRowBuilder, ApplicationCommandOptionType, Message } from "discord.js";
import { buildButton, buildEmbed } from "../utils/configBuilders.js";
import database from "../handlers/databaseHandler.js";
import Giveaway from "../tables/giveaway.js";
import ms from "ms";

export default {
    name: "giveaway",
    description: "Manage giveaways",
    options: [
        { name: "create", description: "Create a giveaway", type: ApplicationCommandOptionType.Subcommand, options: [{ name: "prize", description: "The giveaway prize", type: ApplicationCommandOptionType.String, required: true }, { name: "winners", description: "The amount of winners in the giveaway", type: ApplicationCommandOptionType.Number, required: true, min_value: 1 }, { name: "length", description: "For how long will the giveaway last?", type: ApplicationCommandOptionType.String, required: true }, { name: "role_requirement", description: "Is there a specific role the users need to join the giveaway?", type: ApplicationCommandOptionType.Role, required: false }] }
    ],
    permissions: ["ManageGuild"],
    function: async function({ interaction }) {
        const subcommand = interaction.options.getSubcommand();

        if (subcommand == "create") {
            const length = interaction.options.getString("length");
            const lengthInMs = ms(length);

            if (isNaN(lengthInMs)) return interaction.reply({ content: ":x: **Invalid length.**", ephemeral: true });

            const embed = buildEmbed("giveaway").setFields([
                { name: "⦁ Sponsor", value: "> " + interaction.user.toString(), inline: true },
                { name: "⦁ Winners", value: "> " + interaction.options.getNumber("winners"), inline: true },
                { name: "⦁ Entries", value: "> 0", inline: true },
                { name: "⦁ Time is ticking", value: "> " + `Giveaway Ending <t:${ Math.round((Date.now() + lengthInMs) / 1000) }:R>`, inline: true },
                { name: "⦁ Prize", value: "> " + interaction.options.getString("prize"), inline: true },
                { name: "⦁ Requirement", value: `> Role: ${interaction.options.getRole("role_requirement")?.toString() || "None"}`, inline: false }
            ]);

            const buttons = new ActionRowBuilder().addComponents(
                buildButton("joinGiveaway"),
                buildButton("editGiveaway"),
                buildButton("cancelGiveaway"),
                buildButton("endGiveaway")
            );

            const msg: Message = await interaction.channel.send({ embeds: [embed], components: [buttons] });

            await interaction.reply({ content: ":white_check_mark: **Successfully created giveaway.**", ephemeral: true });
            await database.manager.insert(Giveaway, { guild: interaction.guildId, channel: interaction.channelId, message: msg.id, prize: interaction.options.getString("prize"), winners: interaction.options.getNumber("winners"), length: interaction.options.getString("length"), startedAt: Date.now(), endsAt: Date.now() + lengthInMs, requiredRole: interaction.options.getRole("role_requirement")?.id, ended: false });
        }
    }
}