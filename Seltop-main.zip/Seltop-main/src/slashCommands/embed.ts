import { ActionRowBuilder, ApplicationCommandOptionType, ButtonBuilder, ButtonStyle, ColorResolvable, ChatInputCommandInteraction, EmbedBuilder } from "discord.js";
import database from "../handlers/databaseHandler.js";
import Embed from "../tables/Embed.js";

export default {
    name: "embed",
    description: "Create a custom embed",
    permissions: ["Administrator"],
    options: [{ name: "new", description: "Make a new embed", type: ApplicationCommandOptionType.Subcommand, options: [{ name: "name", description: "The name of the embed, will be used for saving it", type: ApplicationCommandOptionType.String, required: false }] }, { name: "post", description: "Post an alraedy made embed", type: ApplicationCommandOptionType.Subcommand, options: [{ name: "name", description: "The name of a saved embed to post", type: ApplicationCommandOptionType.String, required: true }, { name: "messageid", description: "The message ID to edit (must be in the same channel as the command)", type: ApplicationCommandOptionType.String, required: false }] }, { name: "edit", description: "Edit an alraedy existing embed", type: ApplicationCommandOptionType.Subcommand, options: [{ name: "name", description: "The name of the embed", type: ApplicationCommandOptionType.String, required: true }] }, { name: "delete", description: "Delete an alraedy existing embed", type: ApplicationCommandOptionType.Subcommand, options: [{ name: "name", description: "The name of the embed", type: ApplicationCommandOptionType.String, required: true }] }, { name: "list", description: "List all current embeds", type: ApplicationCommandOptionType.Subcommand }],
    function: async function ({ interaction }: { interaction: ChatInputCommandInteraction }) {
        const Subcommand = interaction.options.getSubcommand();

        if (Subcommand === "new") {
            const name = interaction.options.getString("name");

            const embed = new EmbedBuilder()
                .setTitle("Embed Builder")
                .setColor("Blue")
                .setDescription("Welcome to the **interactive embed builder**.\nUse the buttons below to build the embed, when you're done click **Post Embed**!");
            const textRow = new ActionRowBuilder<ButtonBuilder>().addComponents(
                new ButtonBuilder().setLabel("Author Text").setCustomId("authortext").setStyle(ButtonStyle.Secondary),
                new ButtonBuilder().setLabel("Title Text").setCustomId("title").setStyle(ButtonStyle.Secondary),
                new ButtonBuilder().setLabel("Description Text").setCustomId("description").setStyle(ButtonStyle.Secondary),
                new ButtonBuilder().setLabel("Footer Text").setCustomId("footertext").setStyle(ButtonStyle.Secondary)
            );
            const imageRow = new ActionRowBuilder<ButtonBuilder>().addComponents(
                new ButtonBuilder().setLabel("Author Image").setCustomId("authorimage").setStyle(ButtonStyle.Secondary),
                new ButtonBuilder().setLabel("Thumbnail Image").setCustomId("thumbnail").setStyle(ButtonStyle.Secondary),
                new ButtonBuilder().setLabel("Large Image").setCustomId("largeimage").setStyle(ButtonStyle.Secondary),
                new ButtonBuilder().setLabel("Footer Image").setCustomId("footerimage").setStyle(ButtonStyle.Secondary),
                new ButtonBuilder().setLabel("Embed Color").setCustomId("color").setStyle(ButtonStyle.Secondary)
            );
            const finalRow = new ActionRowBuilder<ButtonBuilder>().addComponents(
                new ButtonBuilder().setLabel("Add Timestamp").setCustomId("timestamp").setStyle(ButtonStyle.Secondary),
                new ButtonBuilder().setLabel("Post Embed").setCustomId("post").setStyle(ButtonStyle.Danger),
                new ButtonBuilder().setLabel("Save Embed").setCustomId("save").setStyle(ButtonStyle.Success)
            );

            return await interaction.reply({ content: name || undefined, embeds: [embed], components: [textRow, imageRow, finalRow] });
        } else if (Subcommand === "edit") {
            const name = interaction.options.getString("name");
    
            const savedEmbed = await database.manager.findOne(Embed, { where: { name: name, guild: interaction.guildId } });
            if (!savedEmbed) return interaction.reply({ content: ":x: **That embed name doesn't exist!**", ephemeral: true });

            const embed = new EmbedBuilder()
                .setTitle(savedEmbed.title)
                .setDescription(savedEmbed.description)
                .setColor(savedEmbed.color as ColorResolvable)
                .setFooter({ text: savedEmbed.footerText, iconURL: savedEmbed.footerImage })
                .setThumbnail(savedEmbed.thumbnail)
                .setImage(savedEmbed.largeImage)
                .setAuthor({ name: savedEmbed.authorText, iconURL: savedEmbed.authorImage });
            if (savedEmbed.timestamp) embed.setTimestamp();

            const textRow = new ActionRowBuilder<ButtonBuilder>().addComponents(
                new ButtonBuilder().setLabel("Author Text").setCustomId("authortext").setStyle(ButtonStyle.Secondary),
                new ButtonBuilder().setLabel("Title Text").setCustomId("title").setStyle(ButtonStyle.Secondary),
                new ButtonBuilder().setLabel("Description Text").setCustomId("description").setStyle(ButtonStyle.Secondary),
                new ButtonBuilder().setLabel("Footer Text").setCustomId("footertext").setStyle(ButtonStyle.Secondary)
            );
            const imageRow = new ActionRowBuilder<ButtonBuilder>().addComponents(
                new ButtonBuilder().setLabel("Author Image").setCustomId("authorimage").setStyle(ButtonStyle.Secondary),
                new ButtonBuilder().setLabel("Thumbnail Image").setCustomId("thumbnail").setStyle(ButtonStyle.Secondary),
                new ButtonBuilder().setLabel("Large Image").setCustomId("largeimage").setStyle(ButtonStyle.Secondary),
                new ButtonBuilder().setLabel("Footer Image").setCustomId("footerimage").setStyle(ButtonStyle.Secondary),
                new ButtonBuilder().setLabel("Embed Color").setCustomId("color").setStyle(ButtonStyle.Secondary)
            );
            const finalRow = new ActionRowBuilder<ButtonBuilder>().addComponents(
                new ButtonBuilder().setLabel("Add Timestamp").setCustomId("timestamp").setStyle(ButtonStyle.Secondary),
                new ButtonBuilder().setLabel("Post Embed").setCustomId("post").setStyle(ButtonStyle.Danger),
                new ButtonBuilder().setLabel("Save Embed").setCustomId("save").setStyle(ButtonStyle.Success)
            );

            interaction.reply({ content: name, embeds: [embed], components: [textRow, imageRow, finalRow] });
            return;
        } else if (Subcommand === "post") {
            const name = interaction.options.getString("name");
            const messageid = interaction.options.getString("messageid");

            const savedEmbed = await database.manager.findOne(Embed, { where: { name: name, guild: interaction.guildId } });
            if (!savedEmbed) return interaction.reply({ content: ":x: **That embed name doesn't exist!**", ephemeral: true });

            const embed = new EmbedBuilder()
                .setTitle(savedEmbed.title)
                .setDescription(savedEmbed.description)
                .setColor(savedEmbed.color as ColorResolvable)
                .setFooter({ text: savedEmbed.footerText, iconURL: savedEmbed.footerImage })
                .setThumbnail(savedEmbed.thumbnail)
                .setImage(savedEmbed.largeImage)
                .setAuthor({ name: savedEmbed.authorText, iconURL: savedEmbed.authorImage });
                if (savedEmbed.timestamp) embed.setTimestamp();

            if (messageid) {
                const message = await interaction.channel.messages.fetch(messageid);

                if (!message) return interaction.reply({ content: ":x: **That message doesn't exist!**", ephemeral: true });

                await message.edit({ embeds: [embed] });
                return;
            }

            interaction.channel.send({ embeds: [embed] });
            interaction.reply({ content: ":white_check_mark: **Embed posted!**", ephemeral: true });
        } else if (Subcommand == "delete") {
            const name = interaction.options.getString("name");

            const savedEmbed = await database.manager.findOne(Embed, { where: { name: name, guild: interaction.guildId } });
            if (!savedEmbed) return interaction.reply({ content: ":x: **That embed name doesn't exist!**", ephemeral: true });

            await database.manager.delete(Embed, { name: name });

            await interaction.reply({ content: ":white_check_mark: **Embed deleted!**", ephemeral: true });
        } else if (Subcommand == "list") {
            const embeds = await database.manager.find(Embed, { where: { guild: interaction.guildId } });

            if (!embeds.length) return interaction.reply({ content: ":x: **There are no saved embeds!**", ephemeral: true });

            const embed = new EmbedBuilder()
                .setTitle("Embed List")
                .setDescription(embeds.map((embed) => embed.name).join("\n"));

            interaction.reply({ embeds: [embed] });
        }
    }
}