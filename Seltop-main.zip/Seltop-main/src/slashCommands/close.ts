import { ApplicationCommandOptionType, ChatInputCommandInteraction, GuildTextBasedChannel, PermissionsBitField } from "discord.js";
import config from "../config.js";
import database from "../handlers/databaseHandler.js";
import ClientProfile from "../tables/ClientProfile.js";
import Commission from "../tables/Commission.js";
import Support from "../tables/Support.js";
import VC from "../tables/VC.js";
import * as discordTranscripts from "discord-html-transcripts";

export default {
    name: "close",
    description: "Close the ticket",
    permissions: [],
    options: [{ name: "reason", description: "The reason for closure", type: ApplicationCommandOptionType.String, required: true }],
    function: async function ({ interaction }: { interaction: ChatInputCommandInteraction }) {
        if (!interaction.inCachedGuild() || interaction.channel.isThread()) return;

        const reason = interaction.options.getString("reason");

        const ticket = await database.manager.findOne(Support, { where: { channel: interaction.channel.id } });
        const commission = await database.manager.findOne(Commission, { where: { channel: interaction.channel.id } });

        const fetchAllMessages = async (channel) => {
            let messages = [];
            let lastId;

            // eslint-disable-next-line no-constant-condition
            while (true) {
                const fetched = await channel.messages.fetch({
                    limit: 100,
                    before: lastId
                });

                if (fetched.size === 0) {
                    break;
                }

                messages = messages.concat(Array.from(fetched.values()));
                lastId = fetched.last().id;
            }

            return messages;
        };

        if (ticket) {
            if (!interaction.member.roles.cache.some(role => config.support.staffRoles.includes(role.id))) return await interaction.reply({ content: ":x: **You don't have permission to use this command.**", ephemeral: true });
            
            const messages = (await fetchAllMessages(interaction.channel)).reverse();
    
            const transcript = await discordTranscripts.generateFromMessages(messages, interaction.channel, {
                filename: `${interaction.channel.name}.html`
            });

            const { client } = await import("../index.js");
    
            const transcriptsChannel = await client.channels.fetch(config.support.transcriptsChannel) as GuildTextBasedChannel;
    
            await transcriptsChannel.send({ content: `:white_check_mark: **Transcript for #${interaction.channel.name}**\n\`\`\`Reason: ${reason || "No reason provided."}\`\`\``, files: [transcript] });
            await interaction.reply({ content: ":white_check_mark: **Ticket closed.**" })
            await database.manager.delete(Support, { channel: interaction.channel.id });
            
            await interaction.channel.delete();
        } else if (commission) {
            const departments = [];

            for (const department of config.departments) {
                for (const role of commission.roles) {
                    if (department.specialties.filter((specialty) => specialty.id === role).length > 0) {
                        departments.push(department);
                    }
                }
            }

            if (!interaction.member.roles.cache.has(departments[0].cmRole) && !interaction.member.permissions.has(PermissionsBitField.Flags.Administrator)) return interaction.reply({ content: ":x: **You are not a commission manager!**", ephemeral: true });

            const messages = (await fetchAllMessages(interaction.channel)).reverse();

            const transcript = await discordTranscripts.generateFromMessages(messages, interaction.channel, {
                filename: `${interaction.channel.name}.html`
            });

            const { client } = await import("../index.js");

            const transcriptsChannel = await client.channels.fetch(config.support.transcriptsChannel) as GuildTextBasedChannel;
            const transcriptmsg = await transcriptsChannel.send({ content: `:white_check_mark: **Transcript for #${interaction.channel.name}**\n\`\`\`Reason: ${reason || "No reason provided."}\`\`\``, files: [transcript] });

            await interaction.reply({ content: ":white_check_mark: **Ticket closed.**" });

            const freelancersChannel = await client.channels.fetch(commission.freelancersChannel).catch(() => null);

            if (freelancersChannel) {
                const freelancerMessage = await freelancersChannel.messages.fetch(commission.freelancersMessage).catch(() => null);
                await freelancerMessage?.delete();
            }

            let clientProfile = await database.manager.findOne(ClientProfile, { where: { user: commission.user } });
            if (!clientProfile) {
                clientProfile = await database.manager.create(ClientProfile, { 
                    user: commission.user,
                    pastTickets: "[]",
                    totalSpent: 0
                });
            }

            clientProfile.pastTickets = JSON.stringify([...JSON.parse(clientProfile.pastTickets), {
                id: commission.id,
                amount: commission.paidAmount,
                transcript: transcriptmsg.attachments.first().url
            }]);

            await database.manager.delete(Commission, { channel: interaction.channel.id });

            const commissionVC = await database.manager.find(VC, { where: { commission: commission.channel } });
            for (const vc of commissionVC) {
                const vcChannel = await client.channels.fetch(vc.channel);
                if (vcChannel) await vcChannel.delete();
                await database.manager.delete(VC, { channel: vc.channel });
            }

            await interaction.channel.delete();
        }
    }
}