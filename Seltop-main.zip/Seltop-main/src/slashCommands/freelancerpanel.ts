import { ActionRowBuilder, ButtonBuilder, ChatInputCommandInteraction } from "discord.js";
import { buildButton, buildEmbed } from "../utils/configBuilders.js";

export default {
	name: "freelancerpanel",
	description: "Send the freelancer applications panel",
	permissions: ["Administrator"],
	options: [],
	function: async function ({ interaction }: { interaction: ChatInputCommandInteraction }) {
		const embed = buildEmbed("freelancerPanel");
		const button = buildButton("freelancerapply");
		
		const row = new ActionRowBuilder<ButtonBuilder>().addComponents(
			button
		);

		await interaction.channel.send({ embeds: [embed], components: [row] }).then(async () => {
			await interaction.reply({ content: ":white_check_mark: **Panel Sent!**", ephemeral: true });
		}).catch(async () => {
			await interaction.reply({ content: ":x: **I couldn't send the embed, missing permission to send messages.**", ephemeral: true });
		})
	}
};