import { ActionRowBuilder, ButtonBuilder, ChatInputCommandInteraction } from "discord.js";
import config from "../config.js";
import database from "../handlers/databaseHandler.js";
import Wallet from "../tables/Wallet.js";
import Withdrawal from "../tables/Withdrawal.js";
import FreelancerProfile from "../tables/FreelancerProfile.js";
import { buildButton, buildEmbed } from "../utils/configBuilders.js";
import { pagination, ButtonTypes, ButtonStyles } from "@devraelfreeze/discordjs-pagination";

export default {
    name: "wallet",
    description: "Manage your wallet",
    permissions: [],
    roleRequired: config.commissions.freelancerRole,
    options: [],
    function: async function ({ interaction }: { interaction: ChatInputCommandInteraction }) {
        let wallet = await database.manager.findOne(Wallet, { where: { user: interaction.user.id } });
        if (!wallet) {
            wallet = await database.manager.create(Wallet, {
                user: interaction.user.id,
                amountMade: 0,
                balance: 0,
                commissionsDone: 0,
                transactions: "[]"
            });
        }

        const pendingWithdraws = await database.manager.find(Withdrawal, { where: { user: interaction.user.id, status: "pending" } });
        const profile = await database.manager.findOne(FreelancerProfile, { where: { user: interaction.user.id } });

        if (!profile || !profile.paypal) return interaction.reply({ content: ":x: **You need to set your paypal email first.**", ephemeral: true });

        const pendingAmount = pendingWithdraws.reduce((acc, curr) => acc + curr.amount, 0);

        const walletEmbed = buildEmbed("wallet").addFields([
                { name: "Balance", value: `$${wallet.balance}`, inline: true },
                { name: "Pending Withdraws", value: `$${pendingAmount}`, inline: true },
                { name: "Amount Made", value: `$${wallet.amountMade}`, inline: true },
                { name: "Commissions Done", value: wallet.commissionsDone.toLocaleString(), inline: true },
                { name: "PayPal", value: profile.paypal || "None", inline: true }
            ]);

        const row = new ActionRowBuilder<ButtonBuilder>().addComponents(
            buildButton("withdraw"),
            buildButton("transactions")
        );

        await interaction.reply({ embeds: [walletEmbed], components: [row], ephemeral: true });

        const reply = await interaction.fetchReply();

        const button = await reply.awaitMessageComponent({ time: 180000 }).catch(() => null);

        if (!button) {
            await interaction.editReply({ components: [] });
            return;
        }

        await button.deferUpdate();

        await interaction.editReply({ components: [] });

        if (button.customId === "withdraw") {
            walletEmbed.setDescription("**Withdrawal process**\nPlease select an option from the buttons below.")

            const withdrawRow = new ActionRowBuilder<ButtonBuilder>().addComponents(
                buildButton("withdrawAll"),
                buildButton("withdrawHalf"),
                buildButton("withdrawCustom")
            );

            await interaction.editReply({ embeds: [walletEmbed], components: [withdrawRow] });
        } else {
            const transactions = JSON.parse(wallet.transactions).map(transaction => {
                return {
                    name: transaction.type,
                    value: `$${transaction.amount} - ${transaction.added ? "Added" : "Removed"}`,
                    inline: true
                }
            });

            const embeds = [];

            for (let i = 0; i < transactions.length; i += 10) {
                embeds.push(
                    buildEmbed("transactions")
                    .addFields(transactions.slice(i, i + 10))
                );
            }

            await pagination({
                embeds: embeds, /** Array of embeds objects */
                author: button.member.user,
                interaction: button,
                ephemeral: true,
                time: 40000, /** 40 seconds */
                disableButtons: true, /** Remove buttons after timeout */
                fastSkip: false,
                pageTravel: false,
                buttons: [
                    {
                        type: ButtonTypes.previous,
                        label: 'Previous Page',
                        style: ButtonStyles.Primary,
                        emoji: '⬅️'
                    },
                    {
                        type: ButtonTypes.next,
                        label: 'Next Page',
                        style: ButtonStyles.Success,
                        emoji: '➡️'
                    }
                ]
            });
        }
    }
}