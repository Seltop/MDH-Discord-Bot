import { ApplicationCommandOptionType, ChatInputCommandInteraction } from "discord.js";
import database from "../handlers/databaseHandler.js";
import LevelVC from "../tables/LevelVC.js";
import { buildEmbed } from "../utils/configBuilders.js";
import LevelText from "../tables/LevelText.js";

export default {
    name: "leaderboard",
    description: "Check the leaderboard",
    options: [
        {
            name: "type",
            description: "The type of leaderboard to check",
            type: ApplicationCommandOptionType.String,
            required: true,
            choices: [
                {
                    name: "Voice",
                    value: "vc"
                },
                {
                    name: "Text",
                    value: "text"
                }
            ]
        }
    ],
    permissions: [],
    function: async function({ interaction }: { interaction: ChatInputCommandInteraction }) {
        const type = interaction.options.getString("type", true);

        if (type == "vc") {
            const levels = await database.manager.find(LevelVC, { where: { guildId: interaction.guildId }, order: { level: "DESC", xp: "DESC" }, take: 10 });

            if (!levels.length) return await interaction.reply({ content: ":x: **No voice levels found.**", ephemeral: true });

            const leaderboard = levels.map((level, index) => `${index + 1}. <@${level.user}> - Level ${level.level} (${level.xp} XP)`).join("\n");

            const embed = buildEmbed("leaderboard")
                .setTitle("Voice Leaderboard")
                .setDescription(leaderboard);

            await interaction.reply({ embeds: [embed] });
        } else if (type == "text") {
            const levels = await database.manager.find(LevelText, { where: { guildId: interaction.guildId }, order: { level: "DESC", xp: "DESC" }, take: 10 });

            if (!levels.length) return await interaction.reply({ content: ":x: **No text levels found.**", ephemeral: true });

            const leaderboard = levels.map((level, index) => `${index + 1}. <@${level.user}> - Level ${level.level} (${level.xp} XP)`).join("\n");

            const embed = buildEmbed("leaderboard")
                .setTitle("Text Leaderboard")
                .setDescription(leaderboard);

            await interaction.reply({ embeds: [embed] });
        }
    }
}