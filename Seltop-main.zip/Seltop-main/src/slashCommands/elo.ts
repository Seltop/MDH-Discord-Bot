import { ApplicationCommandOptionType, ChatInputCommandInteraction } from "discord.js";
import database from "../handlers/databaseHandler.js";
import Elo from "../tables/Elo.js";

export default {
    name: "elo",
    description: "Check a user's elo rating",
    options: [{ name: "user", description: "The user to check", type: ApplicationCommandOptionType.User, required: false }],
    function: async function({ interaction }: { interaction: ChatInputCommandInteraction }) {
        const user = interaction.options.getUser("user") || interaction.user;
        const elo = await database.manager.findOne(Elo, { where: { user: user.id } });

        if (!elo) return await interaction.reply({ content: `:x: **${user.tag} does not have an elo rating.**`, ephemeral: true });

        await interaction.reply({ content: `:white_check_mark: **${user.tag} has an elo rating of \`${elo.elo}\`.**`, ephemeral: true });
    }
}