import { ApplicationCommandOptionType, ChatInputCommandInteraction } from "discord.js";
import database from "../handlers/databaseHandler.js";
import FreelancerProfile from "../tables/FreelancerProfile.js";
import FreelancerReview from "../tables/FreelancerReview.js";
import { buildEmbed } from "../utils/configBuilders.js";

export default {
    name: "profile",
    description: "Check someone's profile.",
    permissions: [],
    options: [{ name: "user", description: "The user you want to check their profile", type: ApplicationCommandOptionType.User, required: true }],
    function: async function ({ interaction }: { interaction: ChatInputCommandInteraction }) {
        const user = interaction.options.getUser("user");
        let profile = await database.manager.findOne(FreelancerProfile, { where: { user: user.id } });
        if (!profile) {
            profile = database.manager.create(FreelancerProfile, {
                user: user.id,
                about: "No about set.",
                portfolio: "No portfolio set.",
                timezone: "No timezone set.",
                paypal: "No PayPal set."
            });
            await database.manager.save(profile);
        }

        const reviews = await database.manager.find(FreelancerReview, { where: { user: user.id } });

        const averageStars = reviews.reduce((a, b) => a + b.rating, 0) / reviews.length;

        const embed = buildEmbed("profile").addFields([
            {
                name: "About",
                value: `${profile.about || "No about set."}`,
                inline: true
            },
            {
                name: "Timezone",
                value: `${profile.timezone || "No timezone set."}`,
                inline: true
            },
            {
                name: "Average Stars",
                value: `${averageStars ? `${"⭐".repeat(averageStars)} (${averageStars})` : "No stars yet."}`,
                inline: true
            },
            {
                name: "Portfolio",
                value: `${profile.portfolio || "No portfolio set."}`,
                inline: true
            }
        ]);

        await interaction.reply({ embeds: [embed] });
    }
}