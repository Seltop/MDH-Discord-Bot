import { ApplicationCommandOptionType, ChatInputCommandInteraction } from "discord.js";
import database from "../handlers/databaseHandler.js";
import FreelancerProfile from "../tables/FreelancerProfile.js";

export default {
    name: "getpaypal",
    description: "Get a user's PayPal.",
    permissions: ["Administrator"],
    options: [{ name: "user", description: "The user to get the PayPal of.", type: ApplicationCommandOptionType.User, required: true }],
    function: async function ({ interaction }: { interaction: ChatInputCommandInteraction }) {
        const user = interaction.options.getUser("user");
        const data = await database.manager.findOne(FreelancerProfile, { where: { user: user.id } });
        if (!data) return await interaction.reply({ content: `:x: **${user.tag} has not set their PayPal!**` });
        await interaction.reply({ content: `:white_check_mark: **${user.tag}'s PayPal is: \`${data.paypal}\`**`, ephemeral: true });
    }
}