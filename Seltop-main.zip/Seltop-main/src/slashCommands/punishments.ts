import { ApplicationCommandOptionType, AttachmentBuilder, ChatInputCommandInteraction } from "discord.js";
import database from "../handlers/databaseHandler.js";
import Punishment from "../tables/punishment.js";

export default {
    name: "punishments",
    description: "View a user's punishments",
    options: [
        {
            name: "user",
            description: "The user to view punishments for",
            type: ApplicationCommandOptionType.User,
            required: true
        }
    ],
    permissions: ["ManageServer"],
    function: async function ({ interaction }: { interaction: ChatInputCommandInteraction }) {
        const user = interaction.options.getUser("user", true);
        
        const punishments = await database.manager.find(Punishment, { where: { userId: user.id, guildId: interaction.guildId } });

        if (!punishments.length) return interaction.reply({ content: ":x: **This user has no punishments.**", ephemeral: true });

        const content = punishments.map((punishment, i) => {
            return `\`${i + 1}.\` ${punishment.type} - <t:${Math.round(punishment.date)}> - by <@${punishment.moderatorId}>`
        }).join("\n");

        if (content.length > 2000) return interaction.reply({ content: ":x: **This user has too many punishments to display.**", ephemeral: true });
        else {
            const attachment = new AttachmentBuilder(Buffer.from(content), {
                name: "punishments.txt"
            });

            await interaction.reply({ content: ":white_check_mark: **Here are the user's punishments:**", files: [attachment] });
        }
    }
}