import { ActionRowBuilder, ApplicationCommandOptionType, ButtonBuilder, ButtonStyle, ChatInputCommandInteraction, ColorResolvable, EmbedBuilder, GuildTextBasedChannel } from "discord.js";
import database from "../handlers/databaseHandler.js";
import Suggestion from "../tables/Suggestion.js";
import config from "../config.js";

export default {
    name: "suggest",
    description: "Suggest something for the server",
    cooldown: 60,
    options: [{ name: "suggestion", description: "The suggestion you want to make", type: ApplicationCommandOptionType.String, required: true }],
    function: async function ({ interaction }: { interaction: ChatInputCommandInteraction }) {
        const suggestion = interaction.options.getString("suggestion");
        const channel = await interaction.guild.channels.fetch(config.channels.suggestions).catch(() => null) as GuildTextBasedChannel;

        if (!channel) return interaction.reply({ content: ":x: **The suggestions channel is not set.**", ephemeral: true });

        const embed = new EmbedBuilder()
            .setTitle("New Suggestion")
            .setColor(config.embedscolor as ColorResolvable)
            .setDescription(`\`\`\`${suggestion}\`\`\``)
            .setAuthor({ name: interaction.user.tag, iconURL: interaction.user.displayAvatarURL() })
            .setTimestamp();

        const buttons = new ActionRowBuilder<ButtonBuilder>().addComponents([
            new ButtonBuilder().setLabel("0").setStyle(ButtonStyle.Success).setCustomId("upvote").setEmoji("👍"),
            new ButtonBuilder().setLabel("0").setStyle(ButtonStyle.Primary).setCustomId("difference").setEmoji("#️⃣").setDisabled(true),
            new ButtonBuilder().setLabel("0").setStyle(ButtonStyle.Danger).setCustomId("downvote").setEmoji("👎"),
            new ButtonBuilder().setLabel("Pending").setStyle(ButtonStyle.Secondary).setCustomId("state").setDisabled(true)
        ]);

        const msg = await channel.send({ embeds: [embed], components: [buttons] });

        await interaction.reply({ content: `:white_check_mark: **Suggestion sent!**`, ephemeral: true });

        const suggestionData = database.manager.create(Suggestion, {
            message: msg.id,
            channel: channel.id,
            state: "pending",
            upvotes: "[]",
            downvotes: "[]"
        });

        await database.manager.save(suggestionData);
    }
}