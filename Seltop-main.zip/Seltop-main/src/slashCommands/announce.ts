import { ApplicationCommandOptionType, ChatInputCommandInteraction } from "discord.js";

export default {
    name: "announce",
    description: "Send an announcement",
    permissions: ["ManageMessages"],
    options: [
        { name: "message", description: "The message you want to send", type: ApplicationCommandOptionType.String, required: true }
    ],
    function: async function ({ interaction }:{ interaction: ChatInputCommandInteraction }) {
        const message = interaction.options.getString("message");
        await interaction.channel.send({ content: `${message}\n\n**From:** <@${interaction.user.id}>` });
        await interaction.reply({ content: ":white_check_mark: **Successfully sent the announcement.**", ephemeral: true });
    }
}