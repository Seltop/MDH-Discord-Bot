import { ActionRowBuilder, ApplicationCommandOptionType, ButtonBuilder, ChatInputCommandInteraction } from "discord.js";
import { buildButton, buildEmbed } from "../utils/configBuilders.js";

export default {
    name: "ticketspanel",
    description: "Send the tickets panel",
    permissions: ["Administrator"],
    options: [{ name: "type", description: "The type of the panel", type: ApplicationCommandOptionType.String, required: true, choices: [{ name: "Order", value: "order" }, { name: "Support", value: "support" }] }],
    function: async function ({ interaction }: { interaction: ChatInputCommandInteraction }) {
        const type = interaction.options.getString("type");
        const panelEmbed = buildEmbed(`${type}panel`)

        const row = new ActionRowBuilder<ButtonBuilder>().addComponents(
            buildButton(type)
        );

        await interaction.channel.send({ embeds: [panelEmbed], components: [row] });

        await interaction.reply({ content: ":white_check_mark: **Successfully sent the tickets panel.**", ephemeral: true });
    }
}