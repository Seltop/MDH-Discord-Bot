import { ActionRowBuilder, ButtonBuilder, ChatInputCommandInteraction } from "discord.js";
import { buildButton, buildEmbed } from "../utils/configBuilders.js";

export default {
    name: "panel-all",
    description: "Sends a panel with tickets, commissions & applications",
    options: [],
    permissions: ["Administrator"],
    function: async function({ interaction }: { interaction: ChatInputCommandInteraction }) {
        const panelEmbed = buildEmbed(`allpanel`);
        const row = new ActionRowBuilder<ButtonBuilder>().addComponents(
            buildButton("order"),
            buildButton("support"),
		    buildButton("freelancerapply")
        );

        await interaction.channel.send({ embeds: [panelEmbed], components: [row] });
        await interaction.reply({ content: ":white_check_mark: **Successfully sent the panel.**", ephemeral: true });
    }
}