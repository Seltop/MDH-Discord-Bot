import { ApplicationCommandOptionType, ChatInputCommandInteraction } from "discord.js";
import config from "../config.js";
import database from "../handlers/databaseHandler.js";
import Support from "../tables/Support.js";
import Commission from "../tables/Commission.js";
import { buildEmbed } from "../utils/configBuilders.js";

export default {
    name: "remove",
    description: "Remove a user from the ticket",
    permissions: [],
    options: [{ name: "user", description: "The user you'd like to remove from the ticket.", type: ApplicationCommandOptionType.User, required: true }],
    function: async function ({ interaction }: { interaction: ChatInputCommandInteraction }) {
        if (!interaction.inCachedGuild() || interaction.channel.isThread()) return;

        const user = interaction.options.getUser("user");
        const ticket = await database.manager.findOne(Support, { where: { channel: interaction.channel.id } }) || await database.manager.findOne(Commission, { where: { channel: interaction.channel.id } });
                
        if (!interaction.member.roles.cache.some(role => config.support.staffRoles.includes(role.id))) return await interaction.reply({ content: ":x: **You don't have permission to use this command.**", ephemeral: true });
        if (!ticket) return await interaction.reply({ content: ":x: **This channel isn't a ticket.**", ephemeral: true });

        await interaction.channel.permissionOverwrites.delete(user.id);

        const embed = buildEmbed("userRemoved")

        await interaction.reply({ content: user.toString(), embeds: [embed] });
        ticket.added = JSON.stringify(JSON.parse(ticket.added).filter((u: string) => u !== user.id));
    }
}