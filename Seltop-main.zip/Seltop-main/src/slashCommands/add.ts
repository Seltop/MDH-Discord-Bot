import { ApplicationCommandOptionType, ChatInputCommandInteraction } from "discord.js";
import config from "../config.js";
import database from "../handlers/databaseHandler.js";
import Commission from "../tables/Commission.js";
import Support from "../tables/Support.js";
import { buildEmbed } from "../utils/configBuilders.js";

export default {
    name: "add",
    description: "Add a user to the ticket",
    permissions: [],
    options: [{ name: "user", description: "The user you'd like to add to the ticket.", type: ApplicationCommandOptionType.User, required: true }],
    function: async function({ interaction }: { interaction: ChatInputCommandInteraction }) {
        if (!interaction.inCachedGuild() || interaction.channel.isThread()) return;
        
        const user = interaction.options.getUser("user");
        const ticket = await database.manager.findOne(Support, { where: { channel: interaction.channel.id } }) || await database.manager.findOne(Commission, { where: { channel: interaction.channel.id } });
        
        if (!interaction.member.roles.cache.some(role => config.support.staffRoles.includes(role.id))) return await interaction.reply({ content: ":x: **You don't have permission to use this command.**", ephemeral: true });
        if (!ticket) return await interaction.reply({ content: ":x: **This channel isn't a ticket.**", ephemeral: true });
        if (ticket.added.includes(user.id)) return await interaction.reply({ content: ":x: **This user is already in the ticket.**", ephemeral: true });

        await interaction.channel.permissionOverwrites.edit(user.id, { ViewChannel: true, SendMessages: true });

        const embed = buildEmbed("userAdded")

        await interaction.reply({ content: user.toString(), embeds: [embed] });
        await database.manager.update(Support, { channel: interaction.channel.id }, { added: JSON.stringify([...JSON.parse(ticket.added), user.id]) });
    }
}