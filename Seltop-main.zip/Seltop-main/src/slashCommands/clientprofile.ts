import { ApplicationCommandOptionType, ChatInputCommandInteraction, PermissionsBitField } from "discord.js";
import database from "../handlers/databaseHandler.js";
import ClientProfile from "../tables/ClientProfile.js";
import FreelancerReview from "../tables/FreelancerReview.js";
import { buildEmbed } from "../utils/configBuilders.js";

export default {
    name: "clientprofile",
    description: "Check your client profile.",
    permissions: [],
    options: [{ name: "user", description: "View someone else's status (admin only)", type: ApplicationCommandOptionType.User, required: false }],
    function: async function ({ interaction }: { interaction: ChatInputCommandInteraction }){
        if (!interaction.inCachedGuild()) return;

        const user = interaction.options.getUser("user") || interaction.user;
        if (user.id !== interaction.user.id && !interaction.member.permissions.has(PermissionsBitField.Flags.Administrator)) return interaction.reply({ content: ":x: **You don't have permissions to view someone else's stats.**", ephemeral: true });

        const profile = await database.manager.findOne(ClientProfile, { where: { user: user.id } });
        if (!profile) return await interaction.reply({ content: `:x: **You have not purchased anything yet.**`, ephemeral: true });

        const reviews = await database.manager.find(FreelancerReview, { where: { client: user.id } });

        const embed = buildEmbed("profile").addFields([
            {
                name: "Amount Spent",
                value: `$${profile.totalSpent.toFixed(2) || 0}`,
                inline: true
            },
            {
                name: "Past Tickets Amount",
                value: `${profile.pastTickets.length || 0}`,
                inline: true
            },
            {
                name: "Reviews Given Amount",
                value: `${reviews.length || 0}`,
            }
        ]);

        await interaction.reply({ embeds: [embed], ephemeral: true });
    }
}