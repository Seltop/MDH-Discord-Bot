import { ApplicationCommandOptionType, ChatInputCommandInteraction } from "discord.js";
import database from "../handlers/databaseHandler.js";
import Wallet from "../tables/Wallet.js";
import { buildEmbed } from "../utils/configBuilders.js";

export default {
    name: "addtowallet",
    description: "Add an amount of money to someone's wallet",
    permissions: ["Administrator"],
    options: [{ name: "freelancer", description: "The freelancer to add money to", type: ApplicationCommandOptionType.User, required: true }, { name: "amount", description: "The amount to add to the wallet", type: ApplicationCommandOptionType.Number, min_value: 0, required: true }],
    function: async function({ interaction }: { interaction: ChatInputCommandInteraction }) {
        const freelancer = interaction.options.getUser("freelancer");
        const amount = interaction.options.getNumber("amount");

        let wallet = await database.manager.findOne(Wallet, { where: { user: freelancer.id } });
        if (!wallet) {
            wallet = database.manager.create(Wallet, {
                user: freelancer.id,
                balance: 0,
                transactions: "[]",
                commissionsDone: 0,
                amountMade: 0
            });
        }

        wallet.balance = Number((wallet.balance + amount).toFixed(2));
        wallet.transactions = JSON.stringify([...JSON.parse(wallet.transactions), {
            type: `Added by ${interaction.user.tag}`,
            amount: amount,
            date: Date.now(),
            added: true
        }]);
        wallet.commissionsDone++;
        wallet.amountMade = Number((wallet.amountMade + amount).toFixed(2));

        await database.manager.save(wallet);

        const paymentEmbed = buildEmbed("paymentComplete").addFields([
            {
                name: "Freelancer",
                value: `<@${freelancer.id}>`
            },
            {
                name: "Amount",
                value: `**$${amount.toFixed(2)}**`
            }
        ]);

        await interaction.reply({ embeds: [paymentEmbed] });
        await interaction.user.send({ embeds: [paymentEmbed] });
    }
}