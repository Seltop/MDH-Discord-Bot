import { ApplicationCommandOptionType, ChatInputCommandInteraction } from "discord.js";
import database from "../handlers/databaseHandler.js";
import Elo from "../tables/Elo.js";

export default {
    name: "elo-top",
    description: "Check the elo leaderboard",
    options: [],
    function: async function ({ interaction }: { interaction: ChatInputCommandInteraction }) {
        const elo = await database.manager.find(Elo, { order: { elo: "DESC" }, take: 10 });

        if (!elo.length) return await interaction.reply({ content: ":x: **There are no elo ratings.**", ephemeral: true });

        const eloTop = elo.map((e, i) => `**${i + 1}.** <@${e.user}> - \`${e.elo}\``).join("\n");

        await interaction.reply({ content: `:white_check_mark: **Elo Leaderboard**\n\n${eloTop}`, ephemeral: true });
    }
}