import { ActionRowBuilder, ApplicationCommandOptionType, ButtonBuilder, ButtonStyle, ChatInputCommandInteraction, PermissionsBitField } from "discord.js";
import config from "../config.js";
import database from "../handlers/databaseHandler.js";
import Commission from "../tables/Commission.js";
import Invoice from "../tables/Invoice.js";
import { buildButton, buildEmbed } from "../utils/configBuilders.js";
import { error } from "../utils/logging.js";
import paypalHandler from "../handlers/paypalHandler.js";
import { stripe } from "../handlers/stripeHandler.js";

export default {
    name: "invoice",
    description: "Create an invoice for a commission.",
    options: [{ name: "amount", description: "The amount that's required for the invoice", type: ApplicationCommandOptionType.Number, min_value: 1, required: true }, { name: "email", description: "The client's email", type: ApplicationCommandOptionType.String, required: false }],
    function: async function({ interaction }: { interaction: ChatInputCommandInteraction }) {
        if (!interaction.inCachedGuild()) return;

        const commission = await database.manager.findOne(Commission, { where: { channel: interaction.channel.id } });

        if (!commission) return interaction.reply({ content: ":x: **This commission doesn't exist anymore.**", ephemeral: true });

        const departments = [];

        for (const department of config.departments) {
            for (const role of commission.roles) {
                if (department.specialties.filter((specialty) => specialty.id === role).length > 0) {
                    departments.push(department);
                }
            }
        }

        if (!interaction.member.roles.cache.has(departments[0].cmRole) && !interaction.member.permissions.has(PermissionsBitField.Flags.Administrator)) return interaction.reply({ content: ":x: **You are not a commission manager!**", ephemeral: true });

        const amount = interaction.options.getNumber("amount");

        const choiceButtons = new ActionRowBuilder<ButtonBuilder>().addComponents(
            buildButton("paypalinvoice"),
            buildButton("stripeinvoice")
        );

        const choiceEmbed = buildEmbed("invoiceChoice").addFields([
            {
                name: "Amount",
                value: `$${amount}`
            },
            {
                name: "Commission",
                value: `<#${commission.channel}>`
            }
        ]);

        await interaction.reply({ content: `**Choose your payment method.**`, embeds: [choiceEmbed], components: [choiceButtons] });

        const filter = i => i.user.id === commission.user || i.user.id === commission.freelancer || i.user.id === interaction.user.id;
        const confirmation = await (await interaction.fetchReply()).awaitMessageComponent({ filter, time: 2147483647 }).catch(() => null);

        if (!confirmation) return interaction.editReply({ content: `:x: **You took too long to choose your payment method.**`, embeds: [], components: [] });

        await confirmation.deferUpdate();

        const paymentMethod = confirmation.customId;

        await interaction.editReply({ content: ":white_check_mark: **Generating your invoice...**", components: [], embeds: [] });

        if (paymentMethod == "paypalinvoice") {
            const { client } = await import("../index.js");
    
            const fees = (amount * config.paypal.fees.percentage / 100) + config.paypal.fees.fixed;
    
            await paypalHandler.function(client);
    
            const invoice = await client.paypal.createDraftInvoice({
                detail: {
                    note: `Commission - Ticket (${interaction.channel.id}) - Client (${commission.user || "N/A"}) - Freelancer (${commission.freelancer || "N/A"})`,
                    terms_and_conditions: config.paypal.tos,
                    currency_code: config.paypal.currency,
                    invoice_date: new Date().toISOString().split("T")[0],
                    payment_term: {
                        due_date: new Date(new Date().getTime() + 7 * 24 * 60 * 60 * 1000).toISOString().split("T")[0]
                    },
                    category_code: "DIGITAL_GOODS"
                },
                status: "PAYMENT_PENDING",
                items: [
                    {
                        name: "Commission",
                        quantity: 1,
                        unit_amount: {
                            currency_code: config.paypal.currency,
                            value: Math.round((amount + fees) * 100) / 100
                        },
                        unit_of_measure: "QUANTITY",
                        breakdown: {
                            item_total: {
                                currency_code: config.paypal.currency,
                                value: amount
                            },
                            custom: {
                                amount: {
                                    currency_code: config.paypal.currency,
                                    value: fees
                                },
                                label: "Processing Fees"
                            }
                        }
                    }
                ],
                configuration: {
                    partial_payment: {
                        allow_partial_payment: true,
                        minimum_amount_due: {
                            currency_code: config.paypal.currency,
                            value: (Math.round((amount + fees) * 100) / 100) / 2,
                            breakdown: {
                                item_total: {
                                    currency_code: config.paypal.currency,
                                    value: amount / 2
                                },
                                custom: {
                                    amount: {
                                        currency_code: config.paypal.currency,
                                        value: fees / 2
                                    },
                                    label: "Processing Fees"
                                }
                            }
                        }
                    }
                },
                primary_recipients: [
                    {
                        billing_info: {
                            name: {
                                given_name: commission.user,
                                surname: await client.users.fetch(commission.user).then(u => u.tag),
                            },
                            email_address: interaction.options.getString("email") || config.paypal.toEmail
                        },
                    },
                ]
            }).catch(e => {
                error(e)
                const errorEmbed = buildEmbed("invoiceerror");
                interaction.editReply({ content: null, embeds: [errorEmbed] });
                return null;
            });
    
            if (!invoice) return;
    
            const invoiceDraft = await client.paypal.getInvoiceByLink(invoice);
    
            await client.paypal.sendInvoice(invoiceDraft.id);
    
            const finalInvoice = await client.paypal.getInvoiceByLink(invoice);
    
            const embed = buildEmbed("invoicecreated").setFields([
                { name: "Status", value: `\`${finalInvoice.status}\``, inline: true },
                { name: "ID", value: `\`${finalInvoice.id}\``, inline: true },
                { name: "Invoice Number", value: `\`#${finalInvoice.detail.invoice_number}\``, inline: true },
                { name: "Breakdown", value: `Product: \`$${amount}\`\nFees: \`$${Math.round(((Math.round((amount + fees) * 100) / 100) - amount) * 100) / 100}\`\nTotal: \`$${Math.round((amount + fees) * 100) / 100}\``, inline: true },
                { name: "PayPal Invoice", value: `[Click Here](${finalInvoice.detail.metadata.recipient_view_url})`, inline: true }
            ])
    
            const payButton = new ButtonBuilder().setLabel("Pay Now").setStyle(ButtonStyle.Link).setURL(finalInvoice.detail.metadata.recipient_view_url);
            if (config.buttons.paypalinvoice.emoji) payButton.setEmoji(config.buttons.paypalinvoice.emoji);
    
            const payRow = new ActionRowBuilder<ButtonBuilder>().addComponents(
                payButton
            );
    
            await interaction.editReply({ content: null, embeds: [embed], components: [payRow] });
    
            const msg = await interaction.fetchReply();
    
            await msg.pin();
    
            await database.manager.insert(Invoice, {
                channel: interaction.channel.id,
                id: finalInvoice.id,
                message: msg.id,
                status: finalInvoice.status,
                number: finalInvoice.detail.invoice_number,
                amount: amount,
                fees: Math.round(((Math.round((amount + fees) * 100) / 100) - amount) * 100) / 100,
                total: Math.round((amount + fees) * 100) / 100,
                link: finalInvoice.detail.metadata.recipient_view_url,
                type: "paypal"
            });
        } else if (paymentMethod === "stripeinvoice") {
            const fees = (amount * config.stripe.fees.percentage / 100) + config.stripe.fees.fixed;

            const customer = await stripe.customers.create({
                name: commission.user,
                email: config.stripe.toEmail,
                description: `Discord user ID: ${commission.user}`
            });

            const invoice = await stripe.invoices.create({
                collection_method: "send_invoice",
                customer: customer.id,
                days_until_due: 30
            });

            await stripe.invoiceItems.create({
                customer: customer.id,
                currency: config.stripe.currency,
                amount: Math.round((amount + fees) * 100),
                description: `Commission - Ticket ${interaction.channel.id} - Client ${commission.user} - Freelancer ${commission.freelancer || "N/A"}`,
                invoice: invoice.id
            });


            const finalInvoice = await stripe.invoices.sendInvoice(invoice.id);

            const invoiceData = await stripe.invoices.retrieve(finalInvoice.id);

            const embed = buildEmbed("invoicecreated").setFields([
                { name: "Status", value: `\`${invoiceData.paid ? "PAID" : "UNPAID"}\``, inline: true },
                { name: "ID", value: `\`${invoiceData.id}\``, inline: true },
                { name: "Invoice Number", value: `\`${invoiceData.number}\``, inline: true },
                { name: "Breakdown", value: `Product: \`$${amount}\`\nFees: \`$${Math.round(((Math.round((amount + fees) * 100) / 100) - amount) * 100) / 100}\`\nTotal: \`$${Math.round((amount + fees) * 100) / 100}\``, inline: true },
                { name: "Stripe Invoice", value: `[Click Here](${invoiceData.hosted_invoice_url})`, inline: true }
            ]);

            const payButton = new ButtonBuilder().setLabel("Pay Now").setStyle(ButtonStyle.Link).setURL(invoiceData.hosted_invoice_url);
            if (config.buttons.stripeinvoice.emoji) payButton.setEmoji(config.buttons.stripeinvoice.emoji)
            const payRow = new ActionRowBuilder<ButtonBuilder>().addComponents(
                payButton
            );

            await interaction.editReply({ content: null, embeds: [embed], components: [payRow] });

            const msg = await interaction.fetchReply();

            await msg.pin();

            await database.manager.insert(Invoice, {
                channel: interaction.channel.id,
                id: invoiceData.id,
                message: msg.id,
                status: invoiceData.status,
                number: invoiceData.number,
                amount: amount,
                fees: Math.round(((Math.round((amount + fees) * 100) / 100) - amount) * 100) / 100,
                total: Math.round((amount + fees) * 100) / 100,
                link: invoiceData.hosted_invoice_url,
                type: "stripe"
            });
        }
    }
}