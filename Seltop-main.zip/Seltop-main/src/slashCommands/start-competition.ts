import { ActionRowBuilder, ApplicationCommandOptionType, ButtonBuilder, ChatInputCommandInteraction } from "discord.js";
import database from "../handlers/databaseHandler.js";
import { buildButton, buildEmbed } from "../utils/configBuilders.js";
import Competition from "../tables/Competition.js";

export default {
    name: "start-competition",
    description: "Start a competition",
    options: [
        {
            name: "name",
            description: "The name of the competition",
            type: ApplicationCommandOptionType.String,
            required: true
        },
        {
            name: "description",
            description: "The description of the competition",
            type: ApplicationCommandOptionType.String,
            required: true
        }
    ],
    permissions: ["Administrator"],
    function: async function({ interaction }: { interaction: ChatInputCommandInteraction }) {
        await interaction.deferReply({ ephemeral: true });

        const name = interaction.options.getString("name")!;
        const submissionsDeadline = Date.now() + 864000000;

        const embed = buildEmbed("competitionStarted")
            .setTitle(name)
            .setDescription(interaction.options.getString("description")!)
            .addFields(
                { name: "Submissions Deadline", value: `<t:${Math.round(submissionsDeadline / 1000)}> (<t:${Math.round(submissionsDeadline / 1000)}:R>)` }
            );

        const row = new ActionRowBuilder<ButtonBuilder>().addComponents(
            buildButton("submit")
        );

        const msg = await interaction.channel.send({ embeds: [embed], components: [row] });
        await interaction.editReply({ content: ":white_check_mark: **Competition started!**" });

        await database.manager.insert(Competition, {
            name,
            channel: interaction.channel.id,
            message: msg.id,
            startDate: Date.now(),
            submissionsOpen: true,
            judgingStartDate: submissionsDeadline,
            judgingEndDate: submissionsDeadline + 259200000,
            completed: false
        });
    }
}