import { ActionRowBuilder, ButtonBuilder, ChatInputCommandInteraction } from "discord.js";
import { buildButton, buildEmbed } from "../utils/configBuilders.js";

export default {
    name: "staffpanel",
    description: "Send the staff applications panel",
    permissions: ["Administrator"],
    options: [],
    function: async function ({ interaction }: { interaction: ChatInputCommandInteraction }) {
        const embed = buildEmbed("staffPanel");
        const button = buildButton("staffapply");

        const row = new ActionRowBuilder<ButtonBuilder>().addComponents(
            button
        );

        await interaction.channel.send({ embeds: [embed], components: [row] }).then(async () => {
            await interaction.reply({ content: ":white_check_mark: **Panel Sent!**", ephemeral: true });
        }).catch(async () => {
            await interaction.reply({ content: ":x: **I couldn't send the embed, missing permission to send messages.**", ephemeral: true });
        })
    }
};