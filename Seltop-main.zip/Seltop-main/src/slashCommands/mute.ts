import { ApplicationCommandOptionType, ChatInputCommandInteraction, GuildMember } from "discord.js";
import database from "../handlers/databaseHandler.js";
import Punishment from "../tables/punishment.js";
import ms from "ms";

export default {
    name: "mute",
    description: "Mute a user",
    options: [
        {
            name: "user",
            description: "The user to mute",
            type: ApplicationCommandOptionType.User,
            required: true
        },
        {
            name: "duration",
            description: "The duration of the mute",
            type: ApplicationCommandOptionType.String,
            required: true
        },
        {
            name: "reason",
            description: "The reason for the mute",
            type: ApplicationCommandOptionType.String,
            required: false
        }
    ],
    permissions: ["MuteMembers"],
    function: async function ({ interaction }: { interaction: ChatInputCommandInteraction }) {
        const user = interaction.options.getUser("user", true);
        const reason = interaction.options.getString("reason", false) || "No reason provided";
        const duration = ms(interaction.options.getString("duration", false));

        if (!duration) return interaction.reply({ content: ":x: **You must provide a valid duration.**", ephemeral: true });

        const member: GuildMember = await interaction.guild.members.fetch(user.id).catch(() => null);
        if (!member) return interaction.reply({ content: ":x: **This user is not in the server.**", ephemeral: true });

        member.timeout(duration, reason);

        await interaction.reply({ content: `:white_check_mark: **${user.tag} has been muted.**` });

        await database.manager.insert(Punishment, {
            guildId: interaction.guildId,
            type: "mute",
            userId: user.id,
            reason,
            date: Math.round(Date.now() / 1000),
            moderatorId: interaction.user.id
        });
    }
}