import { ApplicationCommandOptionType, ChatInputCommandInteraction } from "discord.js";
import { getYouTubeChannelId, getYouTubeChannelName } from "../utils/youtube.js";
import database from "../handlers/databaseHandler.js";
import Subscription from "../tables/Subscription.js";

export default {
    name: "follow",
    description: "Follow a user.",
    permissions: ["Administrator"],
    options: [
        { name: "username", description: "The user you'd like to follow", type: ApplicationCommandOptionType.String, required: true }
    ],
    function: async function ({ interaction }: { interaction: ChatInputCommandInteraction }) {
        let username = interaction.options.getString("username");
        let name: string | null = null;

        const cid = await getYouTubeChannelId(username);
        if (cid) username = cid;
        else return interaction.reply({ content: ":x: **Could not find that YouTube channel.**", ephemeral: true });
        name = await getYouTubeChannelName(username);

        await database.manager.insert(Subscription, { user: username, platform: "youtube", live: null, lastVideo: null });

        return interaction.reply({ content: `:white_check_mark: **Successfully followed ${name || username} on YouTube.**`, ephemeral: true });
    }
}