import { ActionRowBuilder, ApplicationCommandOptionType, ChatInputCommandInteraction, StringSelectMenuBuilder } from "discord.js";
import database from "../handlers/databaseHandler.js";
import Schedule from "../tables/Schedule.js";

export default {
    name: "schedule",
    description: "Schedule a post in the future",
    permissions: ["Administrator"],
    options: [
        { name: "create", description: "Create a schedule", type: ApplicationCommandOptionType.Subcommand },
        { name: "delete", description: "Delete a schedule", type: ApplicationCommandOptionType.Subcommand, options: [{ name: "id", description: "The schedule id", type: ApplicationCommandOptionType.String, required: true }] },
        { name: "list", description: "List all schedules", type: ApplicationCommandOptionType.Subcommand }
    ],
    function: async function ({ interaction }: { interaction: ChatInputCommandInteraction }) {
        const subcommand = interaction.options.getSubcommand();

        if (subcommand == "create") {
            const row = new ActionRowBuilder<StringSelectMenuBuilder>().addComponents(
                new StringSelectMenuBuilder().setCustomId("scheduleType").setPlaceholder("Select a type").setOptions([
                    { label: "Embed", value: "embed" },
                    { label: "Message", value: "message" }
                ])
            );
    
            return interaction.reply({ components: [row] });
        } else if (subcommand == "delete") {
            const schedule = await database.manager.findOne(Schedule, { where: { id: interaction.options.getString("id") } });
            if (!schedule) return interaction.reply({ content: ":x: **Invalid schedule id.**", ephemeral: true });

            await database.manager.delete(Schedule, schedule);

            return interaction.reply({ content: ":white_check_mark: **Successfully deleted schedule.**", ephemeral: true });
        } else if (subcommand == "list") {
            const schedules = await database.manager.find(Schedule, { where: { guild: interaction.guildId } });
            if (!schedules.length) return interaction.reply({ content: ":x: **No schedules found.**", ephemeral: true });

            return interaction.reply({ content: schedules.map(schedule => `ID: \`${schedule.id}\` | Name: \`${schedule.name}\` | Type: \`${schedule.type}\` | Time: <t:${Math.round(schedule.date / 1000)}:R>`).join("\n") });
        }
    }
}