import { ApplicationCommandOptionType } from "discord.js";
import database from "../handlers/databaseHandler.js";
import Punishment from "../tables/punishment.js";

export default {
    name: "ban",
    description: "Ban a user",
    options: [
        {
            name: "user",
            description: "The user to ban",
            type: ApplicationCommandOptionType.User,
            required: true
        },
        {
            name: "reason",
            description: "The reason for the ban",
            type: ApplicationCommandOptionType.String,
            required: false
        }
    ],
    permissions: ["BanMembers"],
    function: async function ({ interaction }) {
        const user = interaction.options.getUser("user", true);
        const reason = interaction.options.getString("reason", false) || "No reason provided";

        await interaction.guild.members.ban(user.id, { reason });

        await interaction.reply({ content: `:white_check_mark: **${user.tag} has been banned.**` });

        await database.manager.insert(Punishment, {
            guildId: interaction.guildId,
            type: "ban",
            userId: user.id,
            reason,
            date: Math.round(Date.now() / 1000),
            moderatorId: interaction.user.id
        });
    }
}