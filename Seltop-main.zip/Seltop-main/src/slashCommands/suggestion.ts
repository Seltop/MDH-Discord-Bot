import { ActionRowBuilder, ApplicationCommandOptionType, ButtonBuilder, ButtonStyle, ChatInputCommandInteraction, EmbedBuilder, GuildTextBasedChannel } from "discord.js";
import database from "../handlers/databaseHandler.js";
import Suggestion from "../tables/Suggestion.js";

export default {
    name: "suggestion",
    description: "Approve or deny a suggestion",
    permissions: ["Administrator"],
    options: [{ name: "suggestion", description: "The message id for the suggestion to approve or deny", type: ApplicationCommandOptionType.String, required: true }, { name: "approve", description: "Whether to approve or deny the suggestion", type: ApplicationCommandOptionType.Boolean, required: true }],
    function: async function ({ interaction }: { interaction: ChatInputCommandInteraction }) {
        const suggestion = await database.manager.findOne(Suggestion, { where: { message: interaction.options.getString("suggestion") } });
        if (!suggestion) return interaction.reply({ content: ":x: **That suggestion doesn't exist!**", ephemeral: true });

        if (suggestion.state !== "pending") return interaction.reply({ content: ":x: **That suggestion has already been approved or denied!**", ephemeral: true });
        
        const updateVotes = async (suggestion, message) => {
            const buttons = new ActionRowBuilder().addComponents([
                new ButtonBuilder().setLabel(`${suggestion.upvotes.length}`).setStyle(ButtonStyle.Success).setCustomId("upvote").setEmoji("👍").setDisabled(true),
                new ButtonBuilder().setLabel(`${suggestion.upvotes.length - suggestion.downvotes.length}`).setStyle(ButtonStyle.Primary).setCustomId("difference").setEmoji("#️⃣").setDisabled(true),
                new ButtonBuilder().setLabel(`${suggestion.downvotes.length}`).setStyle(ButtonStyle.Danger).setCustomId("downvote").setEmoji("👎").setDisabled(true),
                new ButtonBuilder().setLabel(`${suggestion.state.charAt(0).toUpperCase() + suggestion.state.toLowerCase().slice(1)}`).setStyle(ButtonStyle.Secondary).setCustomId("state").setDisabled(true)
            ]);
            await message.edit({ components: [buttons] });
        }

        const approve = interaction.options.getBoolean("approve");

        const suggestionsChannel = await interaction.guild.channels.fetch(suggestion.channel).catch(() => null) as GuildTextBasedChannel;
        if (!suggestionsChannel) return interaction.reply({ content: ":x: **The suggestions channel is not set.**", ephemeral: true });

        const msg = await suggestionsChannel.messages.fetch(suggestion.message).catch(() => null);
        if (!msg) return interaction.reply({ content: ":x: **That suggestion doesn't exist!**", ephemeral: true });

        suggestion.state = approve ? "approved" : "denied";
        await database.manager.save(suggestion);

        if (approve) {
            const embed = new EmbedBuilder()
                .setTitle("Suggestion Approved")
                .setDescription(msg.embeds[0].description)
                .setColor(0x00ff00)
                .setAuthor({ name: msg.embeds[0].author.name, iconURL: msg.embeds[0].author.iconURL })
                .setTimestamp();

            await msg.edit({ embeds: [embed] });
            await updateVotes(suggestion, msg);
        } else {
            const embed = new EmbedBuilder()
                .setTitle("Suggestion Denied")
                .setDescription(msg.embeds[0].description)
                .setColor(0xff0000)
                .setAuthor({ name: msg.embeds[0].author.name, iconURL: msg.embeds[0].author.iconURL })
                .setTimestamp();

            await msg.edit({ embeds: [embed] });
            await updateVotes(suggestion, msg);
        }

        interaction.reply({ content: `:white_check_mark: **Suggestion ${approve ? "approved" : "denied"}!**`, ephemeral: true });
    }
}