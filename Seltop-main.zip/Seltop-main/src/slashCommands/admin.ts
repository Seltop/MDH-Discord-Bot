import { ApplicationCommandOptionType, ChatInputCommandInteraction, ColorResolvable, EmbedBuilder } from "discord.js";
import database from "../handlers/databaseHandler.js";
import ClientProfile from "../tables/ClientProfile.js";
import Commission from "../tables/Commission.js";
import FreelancerReview from "../tables/FreelancerReview.js";
import Wallet from "../tables/Wallet.js";
import Withdrawal from "../tables/Withdrawal.js";
import config from "../config.js";
import { ButtonStyles, ButtonTypes, pagination } from "@devraelfreeze/discordjs-pagination";

export default {
    name: "admin",
    description: "Admin commands, shhhhh",
    permissions: ["Administrator"],
    options: [
        { name: "balance", description: "Check someone's wallet balance", type: ApplicationCommandOptionType.Subcommand, options: [{ name: "user", description: "The person to check their wallet balance.", type: ApplicationCommandOptionType.User, required: true }] },
        { name: "transactions", description: "Check someone's transaction history", type: ApplicationCommandOptionType.Subcommand, options: [{ name: "user", description: "The person to check their transactions history.", type: ApplicationCommandOptionType.User, required: true }] },
        { name: "wrequests", description: "Check someone's current withdrawal requests", type: ApplicationCommandOptionType.Subcommand, options: [{ name: "user", description: "The person to check their current withdrawal requests.", type: ApplicationCommandOptionType.User, required: true }] },
        { name: "amountspent", description: "Check how much someone has spent", type: ApplicationCommandOptionType.Subcommand, options: [{ name: "user", description: "The person to check how much they have spent.", type: ApplicationCommandOptionType.User, required: true }] },
        { name: "pasttickets", description: "Check someone's past tickets", type: ApplicationCommandOptionType.Subcommand, options: [{ name: "user", description: "The person to check their past tickets.", type: ApplicationCommandOptionType.User, required: true }] },
        { name: "reviewssent", description: "Check the reviews someone has sent", type: ApplicationCommandOptionType.Subcommand, options: [{ name: "user", description: "The person to check how many reviews they have sent.", type: ApplicationCommandOptionType.User, required: true }] },
        { name: "setfreelancer", description: "Set the freelancer of this commission", type: ApplicationCommandOptionType.Subcommand, options: [{ name: "user", description: "The freelancer you'd like to set", type: ApplicationCommandOptionType.User, required: true }] }
    ],
    function: async function ({ interaction }: { interaction: ChatInputCommandInteraction }) {
        if (!interaction.inCachedGuild() || interaction.channel.isThread()) return;

        const subcommand = interaction.options.getSubcommand();
        const user = interaction.options.getUser("user");

        if (subcommand == "balance") {
            const wallet = await database.manager.findOne(Wallet, { where: { user: user.id } });
            if (!wallet || !wallet.balance) return interaction.reply({ content: ":x: **This user doesn't have a wallet or has no balance.**", ephemeral: true });
            await interaction.reply({ content: `:white_check_mark: **${user.tag}**'s wallet balance is **$${wallet.balance.toLocaleString()}**.`, ephemeral: true });
        } else if (subcommand == "transactions") {
            const wallet = await database.manager.findOne(Wallet, { where: { user: user.id }, relations: ["transactions"] });
            if (!wallet || !wallet.transactions.length) return interaction.reply({ content: ":x: **This user doesn't have any transactions.**", ephemeral: true });
            const transactions = JSON.parse(wallet.transactions).map(transaction => {
                return {
                    name: transaction.type,
                    value: `$${transaction.amount} - ${transaction.added ? "Added" : "Removed"}`,
                    inline: true
                }
            });

            const embeds = [];

            for (let i = 0; i < transactions.length; i += 10) {
                embeds.push(new EmbedBuilder()
                    .setTitle("Transactions")
                    .addFields(transactions.slice(i, i + 10))
                    .setColor(config.embedscolor as ColorResolvable)
                    .setThumbnail(interaction.user.avatarURL())
                    .setTimestamp()
                    .setFooter({ text: interaction.user.id })
                );
            }

            await pagination({
                embeds: embeds, /** Array of embeds objects */
                author: interaction.user,
                interaction: interaction,
                ephemeral: true,
                time: 40000, /** 40 seconds */
                disableButtons: true, /** Remove buttons after timeout */
                fastSkip: false,
                pageTravel: false,
                buttons: [
                    {
                        type: ButtonTypes.previous,
                        label: 'Previous Page',
                        style: ButtonStyles.Primary
                    },
                    {
                        type: ButtonTypes.next,
                        label: 'Next Page',
                        style: ButtonStyles.Success
                    }
                ]
            });
        } else if (subcommand == "wrequests") {
            const requests = await database.manager.find(Withdrawal, { where: { user: user.id } });
            if (!requests.length) return interaction.reply({ content: ":x: **This user doesn't have any withdrawal requests.**", ephemeral: true });

            const embeds = [];

            for (let i = 0; i < requests.length; i += 5) {
                embeds.push(new EmbedBuilder()
                    .setTitle("Withdrawal Requests")
                    .addFields(requests.slice(i, i + 5).map(request => {
                        return {
                            name: `ID: ${request.id}`,
                            value: `Amount: $${request.amount}\nStatus: ${request.status}`
                        }
                    }))
                    .setColor(config.embedscolor as ColorResolvable)
                    .setThumbnail(interaction.user.avatarURL())
                    .setTimestamp()
                    .setFooter({ text: interaction.user.id })
                );
            }

            await pagination({
                embeds: embeds, /** Array of embeds objects */
                author: interaction.user,
                interaction: interaction,
                ephemeral: true,
                time: 40000, /** 40 seconds */
                disableButtons: true, /** Remove buttons after timeout */
                fastSkip: false,
                pageTravel: false,
                buttons: [
                    {
                        type: ButtonTypes.previous,
                        label: 'Previous Page',
                        style: ButtonStyles.Primary
                    },
                    {
                        type: ButtonTypes.next,
                        label: 'Next Page',
                        style: ButtonStyles.Success
                    }
                ]
            });
        } else if (subcommand == "amountspent") {
            const clientProfile = await database.manager.findOne(ClientProfile, { where: { user: user.id } });
            if (!clientProfile) return interaction.reply({ content: ":x: **This user doesn't have a client profile yet.**", ephemeral: true });
            await interaction.reply({ content: `:white_check_mark: **${user.tag}** has spent **$${clientProfile.totalSpent.toLocaleString()}**.`, ephemeral: true });
        } else if (subcommand == "pasttickets") {
            const clientProfile = await database.manager.findOne(ClientProfile, { where: { user: user.id }, relations: ["pastTickets"] });
            if (!clientProfile) return interaction.reply({ content: ":x: **This user doesn't have a client profile yet.**", ephemeral: true });

            const pasttickets = JSON.parse(clientProfile.pastTickets).map(ticket => {
                return {
                    name: `ID: ${ticket.id}`,
                    value: `Amount Paid: $${ticket.amount}\nTranscript: [Click Here](${ticket.transcript})`,
                    inline: true
                }
            });

            const embeds = [];

            for (let i = 0; i < pasttickets.length; i += 5) {
                embeds.push(new EmbedBuilder()
                    .setTitle("Past Tickets")
                    .addFields(pasttickets.slice(i, i + 5))
                    .setColor(config.embedscolor as ColorResolvable)
                    .setThumbnail(interaction.user.avatarURL())
                    .setTimestamp()
                    .setFooter({ text: interaction.user.id })
                );
            }

            await pagination({
                embeds: embeds, /** Array of embeds objects */
                author: interaction.user,
                interaction: interaction,
                ephemeral: true,
                time: 40000, /** 40 seconds */
                disableButtons: true, /** Remove buttons after timeout */
                fastSkip: false,
                pageTravel: false,
                buttons: [
                    {
                        type: ButtonTypes.previous,
                        label: 'Previous Page',
                        style: ButtonStyles.Primary
                    },
                    {
                        type: ButtonTypes.next,
                        label: 'Next Page',
                        style: ButtonStyles.Success
                    }
                ]
            });
        } else if (subcommand == "reviewssent") {
            const reviews = await database.manager.find(FreelancerReview, { where: { client: user.id } });
            if (!reviews.length) return interaction.reply({ content: ":x: **This user doesn't have any reviews.**", ephemeral: true });

            const embeds = [];

            for (let i = 0; i < reviews.length; i += 5) {
                embeds.push(new EmbedBuilder()
                    .setTitle("Reviews")
                    .addFields(reviews.slice(i, i + 5).map(review => {
                        return {
                            name: `Freelancer: <@${review.user}>`,
                            value: `Rating: ${review.rating}/5\nContent: ${review.comment}`
                        }
                    }))
                    .setColor(config.embedscolor as ColorResolvable)
                    .setThumbnail(interaction.user.avatarURL())
                    .setTimestamp()
                    .setFooter({ text: interaction.user.id })
                );
            }

            await pagination({
                embeds: embeds, /** Array of embeds objects */
                author: interaction.user,
                interaction: interaction,
                ephemeral: true,
                time: 40000, /** 40 seconds */
                disableButtons: true, /** Remove buttons after timeout */
                fastSkip: false,
                pageTravel: false,
                buttons: [
                    {
                        type: ButtonTypes.previous,
                        label: 'Previous Page',
                        style: ButtonStyles.Primary
                    },
                    {
                        type: ButtonTypes.next,
                        label: 'Next Page',
                        style: ButtonStyles.Success
                    }
                ]
            }); 
        } else if (subcommand == "setfreelancer") {
            const commission = await database.manager.findOne(Commission, { where: { channel: interaction.channel.id } });

            if (!commission) return interaction.reply({ content: ":x: **This commission doesn't exist anymore.**", ephemeral: true });

            const user = interaction.options.getUser("user");

            commission.freelancer = user.id;

            await database.manager.save(commission);

            await interaction.reply({ content: `:white_check_mark: **Successfully set <@${user.id}> as the freelancer of this commission.**`, ephemeral: true });

            await interaction.channel.permissionOverwrites.edit(user.id, { ViewChannel: true, SendMessages: true });
        }
    }
}