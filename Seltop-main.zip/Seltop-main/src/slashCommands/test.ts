import { ApplicationCommandOptionType, ChatInputCommandInteraction } from "discord.js";

export default {
	name: "test",
	description: "testing",
	permissions: ["Administrator"],
	roleRequired: "", // id here
	cooldown: 0, // in ms
	options: [{ name: "what", description: "you want what?", required: true, type: ApplicationCommandOptionType.String }],
	function: async function ({ interaction }: { interaction: ChatInputCommandInteraction }) {
		console.log(interaction.options.get("what"));
		interaction.reply({ content: `you said: ${interaction.options.getString("what")}` });
	}
};
