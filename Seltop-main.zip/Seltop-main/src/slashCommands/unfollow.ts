import { ApplicationCommandOptionType, ChatInputCommandInteraction } from "discord.js";
import { getYouTubeChannelId, getYouTubeChannelName } from "../utils/youtube.js";
import database from "../handlers/databaseHandler.js";
import Subscription from "../tables/Subscription.js";

export default {
    name: "unfollow",
    description: "Un-follow a user.",
    permissions: ["Administrator"],
    options: [
        { name: "username", description: "The user you'd like to follow", type: ApplicationCommandOptionType.String, required: true }
    ],
    function: async function ({ interaction }: { interaction: ChatInputCommandInteraction }) {
        let username = interaction.options.getString("username");

        let user: string | null = null;

        const cid = await getYouTubeChannelId(username);
        if (cid) {
            user = cid;
            username = await getYouTubeChannelName(cid);
        }
        else return interaction.reply({ content: ":x: **Could not find that YouTube channel.**", ephemeral: true });

        const subscription = await database.manager.findOne(Subscription, { where: { user: user || username, platform: "youtube" } });
        if (!subscription) return interaction.reply({ content: ":x: **You are not following that user.**", ephemeral: true });

        await database.manager.remove(Subscription, subscription);

        return interaction.reply({ content: `:white_check_mark: **Successfully unfollowed ${username} on YouTube.**`, ephemeral: true });
    }
}