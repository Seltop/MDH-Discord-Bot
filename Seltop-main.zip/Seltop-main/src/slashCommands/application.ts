import { ActionRowBuilder, ApplicationCommandOptionType, ChatInputCommandInteraction, ColorResolvable, EmbedBuilder, GuildTextBasedChannel, StringSelectMenuBuilder } from "discord.js";
import config from "../config.js";
import database from "../handlers/databaseHandler.js";
import Application from "../tables/Application.js";
import * as discordTranscripts from "discord-html-transcripts";

export default {
    name: "application",
    description: "Accept or deny an application",
    roleRequired: config.roles.applicationReviewers,
    options: [{ name: "accept", description: "Accept this application.", type: ApplicationCommandOptionType.Subcommand }, { name: "deny", description: "Deny this application.", type: ApplicationCommandOptionType.Subcommand }, { name: "close", description: "Close this application ticket", type: ApplicationCommandOptionType.Subcommand, options: [{ name: "reason", description: "The reason for the closure", type: ApplicationCommandOptionType.String, required: true }] }],
    function: async function ({ interaction }: { interaction: ChatInputCommandInteraction }) {
        const subcommand = interaction.options.getSubcommand();
        const application = await database.manager.findOne(Application, { where: { channel: interaction.channel.id, status: "pending" } });

        if (!application) return await interaction.reply({ content: ":x: **This channel is not an application channel.**", ephemeral: true });

        if (subcommand === "accept") {
            const roleMenu = new StringSelectMenuBuilder().setCustomId("roleselectionaccept").setPlaceholder("Please select 1 role").setMinValues(1).setMaxValues(1).addOptions(
                JSON.parse(application.roles).map((role) => {
                    for (const department of config.departments) {
                        for (const specialty of department.specialties) {
                            if (specialty.id === role) {
                                return { label: specialty.name, value: specialty.id, emoji: specialty.emoji, description: specialty.description };
                            }
                        }
                    }
                    for (const department of config.staffDepartments) {
                        for (const specialty of department.specialties) {
                            if (specialty.id === role) {
                                return { label: specialty.name, value: specialty.id, emoji: specialty.emoji, description: specialty.description };
                            }
                        }
                    }
                })
            );

            await interaction.reply({ content: "**Please select the roles you want to give to this user...**", components: [new ActionRowBuilder<StringSelectMenuBuilder>().addComponents(roleMenu)], ephemeral: true });
        } else if (subcommand == "deny") {
            const embed = new EmbedBuilder()
                .setTitle(config.embeds.applicationDenied.title || null)
                .setDescription(config.embeds.applicationDenied.description || null)
                .setColor(config.embeds.applicationDenied.color as ColorResolvable || null)
                .setFooter({ text: config.embeds.applicationDenied.footer.text || null, iconURL: config.embeds.applicationDenied.footer.iconURL || null })
                .setAuthor({ name: config.embeds.applicationDenied.author.name || null, iconURL: config.embeds.applicationDenied.author.iconURL || null })
                .setImage(config.embeds.applicationDenied.image || null)
                .setThumbnail(config.embeds.applicationDenied.thumbnail || null)
                if (config.embeds.applicationDenied.timestamp) embed.setTimestamp();

            await interaction.reply({ content: `<@${application.user}>`, embeds: [embed] });
        } else if (subcommand == "close") {
            const fetchAllMessages = async (channel) => {
                let messages = [];
                let lastId;

                // eslint-disable-next-line no-constant-condition
                while (true) {
                    const fetched = await channel.messages.fetch({
                        limit: 100,
                        before: lastId
                    });

                    if (fetched.size === 0) {
                        break;
                    }

                    messages = messages.concat(Array.from(fetched.values()));
                    lastId = fetched.last().id;
                }

                return messages;
            };

            const messages = (await fetchAllMessages(interaction.channel)).reverse();

            const transcript = await discordTranscripts.generateFromMessages(messages, interaction.channel, {
                filename: `${interaction.channel.name}.html`
            });

            const transcriptsChannel = await interaction.guild.channels.fetch(config.channels.transcripts) as GuildTextBasedChannel;

            await transcriptsChannel.send({ content: `:white_check_mark: **Transcript for #${interaction.channel.name}**`, files: [transcript] });
            await interaction.reply({ content: ":white_check_mark: **Application closed.**" })
            await interaction.channel.delete();
        }
    }
}