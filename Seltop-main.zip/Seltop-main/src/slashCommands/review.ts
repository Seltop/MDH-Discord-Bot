import { ActionRowBuilder, ButtonBuilder, ChatInputCommandInteraction, PermissionsBitField } from "discord.js";
import config from "../config.js";
import database from "../handlers/databaseHandler.js";
import Commission from "../tables/Commission.js";
import { buildButton, buildEmbed } from "../utils/configBuilders.js";

export default {
    name: "review",
    description: "Start the review process for a commission.",
    options: [],
    function: async function ({ interaction }: { interaction: ChatInputCommandInteraction }) {
        if (!interaction.inCachedGuild() || interaction.channel.isThread()) return;
        // const commission = await Commission.findOne({ channel: interaction.channel.id });
        const commission = await database.manager.findOne(Commission, { where: { channel: interaction.channel.id } });

        if (!commission) return interaction.reply({ content: ":x: **This commission doesn't exist anymore.**", ephemeral: true });

        if (!commission.freelancer) return interaction.reply({ content: ":x: **This commission doesn't have a freelancer yet.**", ephemeral: true });

        const departments = [];

        for (const department of config.departments) {
            for (const role of commission.roles) {
                if (department.specialties.filter((specialty) => specialty.id === role).length > 0) {
                    departments.push(department);
                }
            }
        }

        if (!interaction.member.roles.cache.has(departments[0]?.cmRole) && !interaction.member.permissions.has(PermissionsBitField.Flags.Administrator)) return interaction.reply({ content: ":x: **You are not a commission manager!**", ephemeral: true });

        commission.status = "review";
        await database.manager.save(commission);

        const reviewEmbed = buildEmbed("startReview").addFields([
            {
                name: "Commission",
                value: `<#${commission.channel}>`
            },
            {
                name: "Freelancer",
                value: `<@${commission.freelancer}>`
            }
        ]);

        await interaction.reply({ content: ":white_check_mark: **The review process has started.**", ephemeral: true });

        const reviewRow = new ActionRowBuilder<ButtonBuilder>().addComponents(
            buildButton("startReview")
        );

        await interaction.channel.send({ content: `<@${commission.user}>`, embeds: [reviewEmbed], components: [reviewRow] });
    }
}