import { ApplicationCommandOptionType, ChatInputCommandInteraction } from "discord.js";
import database from "../handlers/databaseHandler.js";
import LevelVC from "../tables/LevelVC.js";
import { buildEmbed } from "../utils/configBuilders.js";
import { getRequiredXP } from "../utils/levelling.js";
import LevelText from "../tables/LevelText.js";

export default {
    name: "level",
    description: "Check a user's level",
    options: [
        {
            name: "type",
            description: "The type of level to check",
            type: ApplicationCommandOptionType.String,
            required: true,
            choices: [
                {
                    name: "Voice",
                    value: "vc"
                },
                {
                    name: "Text",
                    value: "text"
                }
            ]
        },
        {
            name: "user",
            description: "The user to check the level of",
            type: ApplicationCommandOptionType.User,
            required: false
        }
    ],
    permissions: [],
    function: async function({ interaction }: { interaction: ChatInputCommandInteraction }) {
        const type = interaction.options.getString("type", true);
        const user = interaction.options.getUser("user") || interaction.user;

        if (type === "vc") {
            const level = await database.manager.findOne(LevelVC, { where: { user: user.id, guildId: interaction.guildId } });

            if (!level) return await interaction.reply({ content: ":x: **This user has no voice level.**", ephemeral: true });

            const embed = buildEmbed("level")
                .setTitle(`Voice Level for ${user.tag}`)
                .setDescription(`**Level:** ${level.level}\n**XP:** ${level.xp}/${getRequiredXP(level.level + 1)} (${Math.round((level.xp / getRequiredXP(level.level + 1)) * 100)}%)`);

            await interaction.reply({ embeds: [embed] });
        } else if (type === "text") {
            const level = await database.manager.findOne(LevelText, { where: { user: user.id, guildId: interaction.guildId } });

            if (!level) return await interaction.reply({ content: ":x: **This user has no text level.**", ephemeral: true });

            const embed = buildEmbed("level")
                .setTitle(`Text Level for ${user.tag}`)
                .setDescription(`**Level:** ${level.level}\n**XP:** ${level.xp}/${getRequiredXP(level.level + 1)} (${Math.round((level.xp / getRequiredXP(level.level + 1)) * 100)}%)`);

            await interaction.reply({ embeds: [embed] });
        }
    }
}