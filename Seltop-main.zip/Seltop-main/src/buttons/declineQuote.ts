import { ActionRowBuilder, ButtonInteraction, ModalBuilder, PermissionsBitField, TextInputBuilder, TextInputStyle } from "discord.js";
import database from "../handlers/databaseHandler.js";
import Commission from "../tables/Commission.js";
import Quote from "../tables/Quote.js";

export default {
    id: "declineQuote",
    permissions: [],
    function: async function ({ button }: { button: ButtonInteraction }) {
        if (!button.inCachedGuild()) return;

        const quote = await database.manager.findOne(Quote, { where: { id: button.message.id } });
        if (!quote) return button.reply({ content: ":x: **This quote doesn't exist anymore.**", ephemeral: true });
        
        const commission = await database.manager.findOne(Commission, { where: { channel: quote.commission } });
        if (!commission) return button.reply({ content: ":x: **This commission doesn't exist anymore.**", ephemeral: true });

        if (commission.user !== button.user.id && !button.member.permissions.has(PermissionsBitField.Flags.Administrator)) return button.reply({ content: ":x: **You can't decline this quote.**", ephemeral: true });

        const modal = new ModalBuilder().setTitle("Decline Quote").setCustomId("declineQuote").setComponents(
            new ActionRowBuilder<TextInputBuilder>().setComponents(
                new TextInputBuilder().setCustomId("reason").setLabel("Reason").setPlaceholder("The reason for declining this quote.").setMinLength(1).setMaxLength(100).setRequired(false).setStyle(TextInputStyle.Short)
            )
        );

        await button.showModal(modal);
    }
}