import { ActionRowBuilder, ButtonInteraction, ModalBuilder, TextInputBuilder, TextInputStyle } from "discord.js";

export default {
    id: "authorimage",
    permissions: [],
    roleRequired: "",
    function: async function ({ button }: { button: ButtonInteraction }) {
        if (button.message.interaction.user.id !== button.user.id) return button.reply({ content: "**You are not allowed to use another users Button!**", ephemeral: true });
        const modal = new ModalBuilder()
            .setCustomId("authorimage")
            .setTitle("Link the image URL").addComponents(
                new ActionRowBuilder<TextInputBuilder>().addComponents(
                    new TextInputBuilder()
                        .setCustomId("authorimage")
                        .setLabel("Image URL")
                        .setStyle(TextInputStyle.Short)
                        .setMinLength(0)
                        .setMaxLength(4000)
                        .setRequired(true)
                        .setValue(button.message.embeds[0]?.author?.iconURL || "No Image URL")
                )
            );

        await button.showModal(modal);
    }
}