import { ActionRowBuilder, ButtonInteraction, ModalBuilder, TextInputBuilder, TextInputStyle } from "discord.js";

export default {
    id: "footertext",
    permissions: [],
    roleRequired: "",
    function: async function ({ button }: { button: ButtonInteraction }) {
        const modal = new ModalBuilder()
            .setCustomId("footertext")
            .setTitle("Footer Text").addComponents(
                new ActionRowBuilder<TextInputBuilder>().addComponents(
                    new TextInputBuilder()
                        .setCustomId("footertext")
                        .setLabel("Footer Text")
                        .setStyle(TextInputStyle.Short)
                        .setMinLength(0)
                        .setMaxLength(256)
                        .setRequired(true)
                        .setValue(button.message.embeds[0]?.footer?.text || "No Footer Text")
                )
            );

        await button.showModal(modal);
    }
}