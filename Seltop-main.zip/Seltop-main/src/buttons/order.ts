import { ActionRowBuilder, ButtonInteraction, StringSelectMenuBuilder } from "discord.js";
import { error } from "../utils/logging.js";
import config from "../config.js";

export default {
    id: "order",
    permissions: [],
    function: async function ({ button }: { button: ButtonInteraction }) {
        const roleSelection = new ActionRowBuilder<StringSelectMenuBuilder>().addComponents(
            new StringSelectMenuBuilder().setCustomId("departmentselection").setPlaceholder("Select a department").setMinValues(1).setMaxValues(1).addOptions(
                config.departments.map((department) => ({ label: department.name, value: department.id, emoji: department.emoji, description: department.description }))
            )
        );

        await button.reply({ content: "**Please select the departments you want to commission...**", components: [roleSelection], ephemeral: true }).catch(error);
    }
}