import { ActionRowBuilder, ButtonInteraction, ModalBuilder, TextInputBuilder, TextInputStyle } from "discord.js"

export default {
    id: "withdrawCustom",
    function: async function ({ button }: { button: ButtonInteraction }) {
        const modal = new ModalBuilder().addComponents(
            new ActionRowBuilder<TextInputBuilder>().addComponents(
                new TextInputBuilder().setCustomId("withdrawCustomAmount").setLabel("Amount").setPlaceholder("Enter the amount you want to withdraw.").setMinLength(1).setMaxLength(10).setStyle(TextInputStyle.Short).setRequired(true)
            )
        ).setCustomId("withdrawCustomModal").setTitle("Withdrawal Request")

        await button.showModal(modal);
    }
}