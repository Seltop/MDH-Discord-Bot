import { ActionRowBuilder, ButtonBuilder, ButtonInteraction, ButtonStyle, EmbedBuilder } from "discord.js";

export default {
    id: "timestamp",
    permissions: [],
    roleRequired: "",
    function: async function ({ button }: { button: ButtonInteraction }) {
        if(button.message.interaction.user.id !== button.user.id) return button.reply({ content: "**Your not allowed to use another users Button!**", ephemeral: true });
        const oldComponents: any[] = button.message.components;
        if (oldComponents[2]?.components[0]?.data?.label == "Add Timestamp") {
            const embed = new EmbedBuilder()
                .setTitle(button.message.embeds[0]?.title || null)
                .setColor(button.message.embeds[0]?.color || null)
                .setDescription(button.message.embeds[0]?.description || null)
                .setAuthor({ name: button.message.embeds[0]?.author?.name || null, iconURL: button.message.embeds[0]?.author?.iconURL || null })
                .setTimestamp(Date.now() || null)
                .setFooter({ text: button.message.embeds[0]?.footer?.text || null, iconURL: button.message.embeds[0]?.footer?.iconURL || null })
                .setThumbnail(button.message.embeds[0]?.thumbnail?.url || null)
                .setImage(button.message.embeds[0]?.image?.url || null)
            oldComponents.pop();
            const finalRow = new ActionRowBuilder<ButtonBuilder>().addComponents(
                new ButtonBuilder().setLabel("Remove Timestamp").setCustomId("timestamp").setStyle(ButtonStyle.Secondary),
                new ButtonBuilder().setLabel("Post Embed").setCustomId("post").setStyle(ButtonStyle.Danger),
                new ButtonBuilder().setLabel("Save Embed").setCustomId("save").setStyle(ButtonStyle.Success)
            );
            oldComponents.push(finalRow);
            await button.message.edit({ embeds: [embed], components: oldComponents });
            await button.deferUpdate();
        } else if (oldComponents[2]?.components[0]?.data?.label == "Remove Timestamp") {
            const embed = new EmbedBuilder()
                .setTitle(button.message.embeds[0]?.title || null)
                .setColor(button.message.embeds[0]?.color || null)
                .setDescription(button.message.embeds[0]?.description || null)
                .setAuthor({ name: button.message.embeds[0]?.author?.name || null, iconURL: button.message.embeds[0]?.author?.iconURL || null })
                .setTimestamp(null)
                .setFooter({ text: button.message.embeds[0]?.footer?.text || null, iconURL: button.message.embeds[0]?.footer?.iconURL || null })
                .setThumbnail(button.message.embeds[0]?.thumbnail?.url || null)
                .setImage(button.message.embeds[0]?.image?.url || null)
            oldComponents.pop();
            const finalRow = new ActionRowBuilder<ButtonBuilder>().addComponents(
                new ButtonBuilder().setLabel("Remove Timestamp").setCustomId("timestamp").setStyle(ButtonStyle.Secondary),
                new ButtonBuilder().setLabel("Post Embed").setCustomId("post").setStyle(ButtonStyle.Danger),
                new ButtonBuilder().setLabel("Save Embed").setCustomId("save").setStyle(ButtonStyle.Success)
            );
            oldComponents.push(finalRow);
            await button.message.edit({ embeds: [embed], components: oldComponents });
            await button.deferUpdate();
        }
    }
}