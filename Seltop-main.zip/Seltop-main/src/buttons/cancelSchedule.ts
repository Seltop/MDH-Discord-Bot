import database from "../handlers/databaseHandler.js";
import Schedule from "../tables/Schedule.js";
import { ButtonInteraction } from "discord.js";

export default {
    id: "cancelSchedule",
    function: async function({ button }: { button: ButtonInteraction }) {
        const schedule = await database.manager.findOne(Schedule, { where: { id: button.message.id } });
        if (!schedule) return button.reply({ content: ":x: **Could not find that schedule.**", ephemeral: true });

        await database.manager.delete(Schedule, { id: button.message.id });

        await button.deferUpdate();
        await button.message.edit({ content: ":white_check_mark: **Schedule cancelled!**", components: [] });
    }
}