import { ActionRowBuilder, ButtonInteraction, StringSelectMenuBuilder } from "discord.js";
import { error } from "../utils/logging.js";
import config from "../config.js";

export default {
    id: "staffapply",
    permissions: [],
    function: async function ({ button }: { button: ButtonInteraction }) {
        const roleSelection = new ActionRowBuilder<StringSelectMenuBuilder>().addComponents(
            new StringSelectMenuBuilder().setCustomId("applicationstaffdepartmentselection").setPlaceholder("Select a department").setMinValues(1).setMaxValues(1).addOptions(
                config.staffDepartments.map((department) => ({ label: department.name, value: department.id, emoji: department.emoji, description: department.description }))
            )
        );

        await button.reply({ content: "**Please select the departments you want to apply for...**", components: [roleSelection], ephemeral: true }).catch(error);
    }
}