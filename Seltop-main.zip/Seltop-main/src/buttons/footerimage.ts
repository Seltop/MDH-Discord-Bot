import { ActionRowBuilder, ButtonInteraction, ModalBuilder, TextInputBuilder, TextInputStyle } from "discord.js";

export default {
    id: "footerimage",
    permissions: [],
    roleRequired: "",
    function: async function ({ button }: { button: ButtonInteraction }) {
        const modal = new ModalBuilder()
            .setCustomId("footerimage")
            .setTitle("Link the image URL").addComponents(
                new ActionRowBuilder<TextInputBuilder>().addComponents(
                    new TextInputBuilder()
                        .setCustomId("footerimage")
                        .setLabel("Image URL")
                        .setStyle(TextInputStyle.Short)
                        .setMinLength(0)
                        .setMaxLength(4000)
                        .setRequired(true)
                        .setValue(button.message.embeds[0]?.footer?.iconURL || "No Footer Image")
                )
            );

        await button.showModal(modal);
    }
}