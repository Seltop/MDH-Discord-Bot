import { ButtonInteraction, EmbedBuilder, Message } from "discord.js";
import database from "../handlers/databaseHandler.js";
import Embed from "../tables/Embed.js";

export default {
    id: "save",
    permissions: [],
    function: async function ({ button }: { button: ButtonInteraction }) {
        if (button.message.interaction.user.id !== button.user.id) return button.reply({ content: "**You are not allowed to use another users Button!**", ephemeral: true });

        const embed = new EmbedBuilder()
            .setTitle(button.message.embeds[0]?.title == "Embed Builder" ? null : button.message.embeds[0]?.title)
            .setColor(button.message.embeds[0]?.color || null)
            .setDescription(button.message.embeds[0]?.description == "Welcome to the **interactive embed builder**.\nUse the buttons below to build the embed, when you're done click **Post Embed**!" ? null : button.message.embeds[0]?.description)
            .setAuthor({ name: button.message.embeds[0]?.author?.name || null, iconURL: button.message.embeds[0]?.author?.iconURL || null })
            .setTimestamp(button.message.embeds[0]?.timestamp ? Date.now() : null)
            .setFooter({ text: button.message.embeds[0]?.footer?.text || null, iconURL: button.message.embeds[0]?.footer?.iconURL || null })
            .setThumbnail(button.message.embeds[0]?.thumbnail?.url || null)
            .setImage(button.message.embeds[0]?.image?.url || null);

        const askForName = async () => {
            if (button.message.content) {
                await button.reply({ content: "**Saving the embed...**" });
                return button.message.content;
            }

            await button.reply({ content: "**Please enter a name for the embed...**" });

            const name = await button.channel.awaitMessages({ filter: m => m.author.id === button.user.id, time: 2147483647, max: 1 }).catch(() => {
                button.reply({ content: "**Timed out!**", ephemeral: true });
                return null;
            });

            if (!name) return;

            const exists = await database.manager.findOne(Embed, { where: { name: name.first().content } });
            if (exists)  {
                await button.channel.send({ content: "**This name already exists!**" });
                return await askForName();
            }

            return name.first().content;
        };

        const name = await askForName();

        setTimeout(async () => {
            await button.deleteReply();
        }, 5000)

        if (await database.manager.findOne(Embed, { where: { name: name } })) {
            await database.manager.delete(Embed, { name: name });
        }

        const edited = await button.message.edit({ embeds: [embed], components: [] }).catch(e => {
            if (e) button.channel.send({ content: "**Error:** " + e.message });
            return null;
        });

        if (!edited) return;
        
        await database.manager.insert(Embed, {
            guild: button.guildId,
            name: name,
            title: button.message.embeds[0]?.title == "Embed Builder" ? null : button.message.embeds[0]?.title,
            description: button.message.embeds[0]?.description == "Welcome to the **interactive embed builder**.\nUse the buttons below to build the embed, when you're done click **Post Embed**!" ? null : button.message.embeds[0]?.description,
            authorText: button.message.embeds[0]?.author?.name || null,
            authorImage: button.message.embeds[0]?.author?.iconURL || null,
            color: `#${button.message.embeds[0]?.color?.toString(16) }` || null,
            footerImage: button.message.embeds[0]?.footer?.iconURL || null,
            footerText: button.message.embeds[0]?.footer?.text || null,
            thumbnail: button.message.embeds[0]?.thumbnail?.url || null,
            largeImage: button.message.embeds[0]?.image?.url || null,
            timestamp: button.message.embeds[0]?.timestamp ? true : false
        }).then(async () => {
            const msg= await button.channel.send({ content: "**Embed saved!**" }) as Message;
            setTimeout(async () => {
                await msg.delete();
            }, 5000);
        }).catch(e => {
            if (e) button.channel.send({ content: "**Error:** " + e.message });
        });
    }
}