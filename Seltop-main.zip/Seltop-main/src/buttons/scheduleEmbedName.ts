import { ActionRowBuilder, ButtonInteraction, ModalBuilder, TextInputBuilder, TextInputStyle } from "discord.js";

export default {
    id: "scheduleEmbedName",
    function: async function ({ button }: { button: ButtonInteraction }) {
        const modal = new ModalBuilder().setTitle("Schedule Embed Embed").setCustomId("scheduleEmbedName").setComponents(
            new ActionRowBuilder<TextInputBuilder>().addComponents(
                new TextInputBuilder().setCustomId("scheduleEmbedName").setLabel("Embed name").setMaxLength(100).setStyle(TextInputStyle.Short).setRequired(true)
            )
        );

        await button.showModal(modal);
    }
}