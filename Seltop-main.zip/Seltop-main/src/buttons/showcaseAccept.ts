import { AttachmentBuilder, ButtonInteraction, GuildTextBasedChannel } from "discord.js";
import config from "../config.js";
import { buildEmbed } from "../utils/configBuilders.js";
import database from "../handlers/databaseHandler.js";
import Showcase from "../tables/Showcase.js";

export default {
    id: "showcaseAccept",
    function: async function ({ button }: { button: ButtonInteraction }) {
        await button.reply({ content: ":white_check_mark: **Please send an image in the channel after this message.**", ephemeral: true });
        
        const msg = await button.channel.awaitMessages({ filter: m => m.author.id == button.user.id, max: 1, time: 2147483647 });

        const image = msg.first().attachments.first();

        if (!image) return button.reply({ content: ":x: **Please send an image.**", ephemeral: true });

        // make a buffer from the image
        const arrbuffer = await fetch(image.url).then(res => res.arrayBuffer());

        function toBuffer(arrayBuffer) {
            const buffer = Buffer.alloc(arrayBuffer.byteLength);
            const view = new Uint8Array(arrayBuffer);
            for (let i = 0; i < buffer.length; ++i) {
                buffer[i] = view[i];
            }
            return buffer;
        }

        const buffer = toBuffer(arrbuffer);

        const attachment = new AttachmentBuilder(buffer, {
            name: "showcase.png",
            description: "showcase.png"
        });

        const { client } = await import("../index.js");

        const showcaseChannel = await client.channels.fetch(config.commissions.showcaseChannel).catch(() => null) as GuildTextBasedChannel;
        if (!showcaseChannel) return button.editReply({ content: ":x: **The showcase channel doesn't exist anymore.**" });

        const showcaseEmbed = buildEmbed("showcase").setAuthor({
            name: button.user.username,
            iconURL: button.user.displayAvatarURL()
        }).setImage("attachment://showcase.png");

        await showcaseChannel.send({ content: `<@${button.user.id}>`, embeds: [showcaseEmbed], files: [attachment] });

        await button.followUp({ content: ":white_check_mark: **Your showcase has been sent.**", ephemeral: true });

        await button.message.delete();

        await database.manager.insert(Showcase, {
            message: button.message.id,
            user: button.user.id
        });
    }
}