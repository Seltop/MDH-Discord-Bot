import { ActionRowBuilder, ButtonInteraction, ModalBuilder, TextInputBuilder, TextInputStyle } from "discord.js";

export default {
    id: "thumbnail",
    permissions: [],
    roleRequired: "",
    function: async function ({ button }: { button: ButtonInteraction }) {
        const modal = new ModalBuilder()
            .setCustomId("thumbnail")
            .setTitle("Link the image URL").addComponents(
                new ActionRowBuilder<TextInputBuilder>().addComponents(
                    new TextInputBuilder()
                        .setCustomId("thumbnail")
                        .setLabel("Image URL")
                        .setStyle(TextInputStyle.Short)
                        .setMinLength(0)
                        .setMaxLength(4000)
                        .setRequired(true)
                        .setValue(button.message.embeds[0]?.thumbnail?.url || "No Thumbnail")
                )
            );

        await button.showModal(modal);
    }
}