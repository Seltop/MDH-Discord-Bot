import { ButtonInteraction, PermissionsBitField } from "discord.js";
import database from "../handlers/databaseHandler.js";
import Giveaway from "../tables/giveaway.js";
import { endGiveaway } from "../utils/giveaway.js";

export default {
    id: "endGiveaway",
    function: async function ({ button }: { button: ButtonInteraction }) {
        if (!button.inCachedGuild()) return;
        if (!button.member.permissions.has(PermissionsBitField.Flags.ManageGuild)) return await button.reply({ content: ":x: **You don't have the `Manage Server` permission.**", ephemeral: true });

        const giveaway = await database.manager.findOne(Giveaway, { where: { message: button.message.id } });
        if (!giveaway || giveaway.ended) return await button.reply({ content: ":x: **This giveaway no longer exists.**", ephemeral: true });

        await button.reply({ content: ":white_check_mark: **Successfully ended the giveaway.**", ephemeral: true });
        return await endGiveaway({ giveaway: giveaway });
    }
}