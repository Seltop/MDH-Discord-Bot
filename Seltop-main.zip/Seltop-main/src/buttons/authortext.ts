import { ActionRowBuilder, ButtonInteraction, ModalBuilder, TextInputBuilder, TextInputStyle } from "discord.js";

export default {
    id: "authortext",
    permissions: [],
    roleRequired: "",
    function: async function ({ button }: { button: ButtonInteraction }) {
        if (button.message.interaction.user.id !== button.user.id) return button.reply({ content: "**You are not allowed to use another users Button!**", ephemeral: true });
        const modal = new ModalBuilder()
            .setCustomId("authortext")
            .setTitle("Author Text").addComponents(
                new ActionRowBuilder<TextInputBuilder>().addComponents(
                    new TextInputBuilder()
                        .setCustomId("authortext")
                        .setLabel("Author Text")
                        .setStyle(TextInputStyle.Short)
                        .setMinLength(0)
                        .setMaxLength(256)
                        .setRequired(true)
                        .setValue(button.message.embeds[0]?.author?.name || "No Author Text")
                )
            );

        await button.showModal(modal);
    }
}