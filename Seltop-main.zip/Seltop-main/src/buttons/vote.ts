import { ButtonInteraction } from "discord.js";
import database from "../handlers/databaseHandler.js";
import Submission from "../tables/Submission.js";
import config from "../config.js";
import Vote from "../tables/Vote.js";
import Competition from "../tables/Competition.js";

export default {
    id: "vote",
    roleRequired: config.roles.competitionJudges,
    function: async function({ button }: { button: ButtonInteraction }) {
        await button.deferReply({ ephemeral: true });

        const submission = await database.manager.findOne(Submission, { where: { message: button.message.id } });
        if (!submission) return await button.editReply({ content: ":x: **This submission does not exist.**" });
        
        const competition = await database.manager.findOne(Competition, { where: { id: submission.competition } });
        if (!competition) return await button.editReply({ content: ":x: **This competition does not exist.**" });

        if (competition.submissionsOpen) return await button.editReply({ content: ":x: **Submissions are still open for this competition.**" });

        const voteAmount = parseInt(button.customId.replace("vote", ""));

        const alreadyVoted = await database.manager.findOne(Vote, { where: { user: button.user.id, submission: submission.id } });

        if (alreadyVoted) {
            await database.manager.update(Vote, { id: alreadyVoted.id }, { amount: voteAmount });

            return await button.editReply({ content: ":white_check_mark: **Vote updated!**" });
        }

        await database.manager.insert(Vote, { user: button.user.id, submission: submission.id, amount: voteAmount });

        await button.editReply({ content: ":white_check_mark: **Vote submitted!**" });
    }
}