import { ButtonInteraction, EmbedBuilder, GuildTextBasedChannel } from "discord.js";

export default {
    id: "post",
    permissions: [],
    roleRequired: "",
    function: async function ({ button }: { button: ButtonInteraction }) {
        if(button.message.interaction.user.id !== button.user.id) return button.reply({ content: "**Your not allowed to use another users Button!**", ephemeral: true });
        const oldComponents = button.message.components;
        const embed = new EmbedBuilder()
            .setTitle(button.message.embeds[0]?.title == "Embed Builder" ? null : button.message.embeds[0]?.title)
            .setColor(button.message.embeds[0]?.color || null)
            .setDescription(button.message.embeds[0]?.description == "Welcome to the **interactive embed builder**.\nUse the buttons below to build the embed, when you're done click **Post Embed**!" ? null : button.message.embeds[0]?.description)
            .setAuthor({ name: button.message.embeds[0]?.author?.name || null, iconURL: button.message.embeds[0]?.author?.iconURL || null })
            .setTimestamp(button.message.embeds[0]?.timestamp ? Date.now() : null)
            .setFooter({ text: button.message.embeds[0]?.footer?.text || null, iconURL: button.message.embeds[0]?.footer?.iconURL || null })
            .setThumbnail(button.message.embeds[0]?.thumbnail?.url || null)
            .setImage(button.message.embeds[0]?.image?.url || null);

        const edited = await button.message.edit({ embeds: [embed], components: [] }).catch(e => {
            if (e) button.channel.send({ content: "**Error:** " + e.message });
        });

        if (!edited) return;

        await button.reply({ content: "**Please mention the channel to post to...**" });
        const msgs = await button.channel.awaitMessages({ filter: m => m.author.id === button.user.id, max: 1, time: 2147483647 }).catch(() => {
            button.reply({ content: "**Timed out!**", ephemeral: true });
            return;
        });
        if (!msgs) return;
        if (!msgs.size) return button.channel.send({ content: "**Timed out!**" });
        const msg = msgs.first();
        const interactionReply = await button.fetchReply();
        await interactionReply.delete();
        const channel = msg.mentions.channels.first() as GuildTextBasedChannel;
        if (!channel) return button.channel.send({ content: "**Invalid channel!**" });
        await msg.delete();
        await button.message.edit({ components: oldComponents });
        const sent = await channel.send({ embeds: [embed] }).catch(e => {
            if (e) button.channel.send({ content: "**Error:** " + e.message});
        });
        if (!sent) return;
        await button.channel.send({ content: "**Embed posted!**" });
        await button.message.delete();
    }
}