import { ActionRowBuilder, ButtonInteraction, ModalBuilder, TextInputBuilder, TextInputStyle } from "discord.js";
import database from "../handlers/databaseHandler.js";
import Commission from "../tables/Commission.js";

export default {
    id: "startReview",
    function: async function ({ button }: { button: ButtonInteraction }) {
        const commission = await database.manager.findOne(Commission, { where: { channel: button.channel.id } });
        
        if (!commission) return await button.reply({ content: ":x: **This commission doesn't exist anymore.**", ephemeral: true });

        if (button.user.id !== commission.user) return await button.reply({ content: ":x: **You are not the commissioner!**", ephemeral: true });

        const modal = new ModalBuilder().setTitle("Review").setCustomId("review").addComponents(
            new ActionRowBuilder<TextInputBuilder>().addComponents(
                new TextInputBuilder().setLabel("Freelancer Stars").setPlaceholder("Stars given to the freelancer. (1-5)").setMinLength(1).setMaxLength(1).setRequired(true).setStyle(TextInputStyle.Short).setCustomId("freelancerStars")
            ),
            new ActionRowBuilder<TextInputBuilder>().addComponents(
                new TextInputBuilder().setLabel("Freelancer Review").setPlaceholder("Review given to the freelancer.").setMinLength(1).setMaxLength(1000).setRequired(false).setStyle(TextInputStyle.Paragraph).setCustomId("freelancerReview")
            )
        );

        await button.showModal(modal);
    }
}