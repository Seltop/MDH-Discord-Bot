import { ButtonInteraction } from "discord.js";
import database from "../handlers/databaseHandler.js";
import Giveaway from "../tables/giveaway.js";
import JoinedGiveaway from "../tables/joinedGiveaways.js";

export default {
    id: "joinGiveaway",
    function: async function({ button }: { button: ButtonInteraction }) {
        if (!button.inCachedGuild()) return;

        const giveaway = await database.manager.findOne(Giveaway, { where: { message: button.message.id } });
        if (!giveaway) return button.reply({ content: ":x: **This giveaway doesn't exist anymore.**", ephemeral: true });

        if (giveaway.requiredRole) {
            if (!button.member.roles.cache.has(giveaway.requiredRole)) return button.reply({ content: ":x: **You don't have the required role to enter this giveaway.**", ephemeral: true });
        }

        const joinedGiveaway = await database.manager.findOne(JoinedGiveaway, { where: { giveaway: button.message.id, user: button.user.id } });

        if (joinedGiveaway) {
            await database.manager.delete(JoinedGiveaway, { giveaway: button.message.id, user: button.user.id });
            button.reply({ content: ":white_check_mark: **You have been removed from the giveaway.**", ephemeral: true });
        } else {
            await database.manager.insert(JoinedGiveaway, { giveaway: button.message.id, user: button.user.id });
            button.reply({ content: ":white_check_mark: **You have been added to the giveaway.**", ephemeral: true });
        }

        const totaLJoins = await database.manager.count(JoinedGiveaway, { where: { giveaway: button.message.id } });

        const embed = button.message.embeds[0];
        embed.fields[2].value = "> " + totaLJoins;

        button.message.edit({ embeds: [embed] });
    }
}