import { ButtonInteraction } from "discord.js";
import config from "../config.js";
import database from "../handlers/databaseHandler.js";
import { buildEmbed } from "../utils/configBuilders.js";
import Commission from "../tables/Commission.js";
import Quote from "../tables/Quote.js";

export default {
    id: "acceptQuote",
    permissions: [],
    function: async function ({ button }: { button: ButtonInteraction }) {
        const commission = await database.manager.findOne(Commission, { where: { channel: button.channel.id } });

        if (!commission) return button.reply({ content: ":x: **This commission doesn't exist anymore.**", ephemeral: true });
        if (commission.freelancer) return button.reply({ content: ":x: **This commission has already been accepted.**", ephemeral: true });

        const quote = await database.manager.findOne(Quote, { where: { id: button.message.id } });

        if (!quote) return button.reply({ content: ":x: **This quote doesn't exist anymore.**", ephemeral: true });

        await database.manager.update(Commission, { channel: button.channel.id }, { freelancer: quote.freelancer });
        
        const departments = [];

        for (const department of config.departments) {
            for (const role of commission.roles) {
                if (department.specialties.filter((specialty) => specialty.id === role).length > 0) {
                    departments.push(department);
                }
            }
        }

        const { client } = await import("../index.js");

        const freelancersChannel = await client.channels.fetch(commission.freelancersChannel).catch(() => null);

        if (freelancersChannel) {
            const freelancerMessage = await freelancersChannel.messages.fetch(commission.freelancersMessage).catch(() => null);
            await freelancerMessage.delete().catch(() => null);
        }

        commission.freelancer = quote.freelancer;
        await database.manager.save(commission);
        
        const quoteAcceptedDM = buildEmbed("quoteAcceptedDM").setFields([
            { name: "Commission", value: `<#${commission.channel}>`, inline: true },
            { name: "Amount", value: `$${quote.price}`, inline: true },
            { name: "Timeframe", value: quote.timeframe, inline: true },
            { name: "Comment", value: quote.comment || "None", inline: true }
        ]);

        const quoteAcceptedTicket = buildEmbed("quoteAcceptedTicket").setFields([
            { name: "Amount", value: `$${quote.price}`, inline: true },
            { name: "Timeframe", value: quote.timeframe, inline: true },
            { name: "Comment", value: quote.comment || "None", inline: true }
        ]);

        if (button.channel.isThread()) return button.reply({ content: ":x: **The commission channel is a thread, what..?**", ephemeral: true });
        await button.channel.permissionOverwrites.edit(quote.freelancer, { ViewChannel: true, SendMessages: true });

        const freelancer = await button.guild.members.fetch(quote.freelancer);

        await button.reply({ content: `<@${commission.freelancer}> <@${commission.user}>`, embeds: [quoteAcceptedTicket] });
        await freelancer.send({ embeds: [quoteAcceptedDM] }).catch(() => null);

        await button.message.delete();
    }
}