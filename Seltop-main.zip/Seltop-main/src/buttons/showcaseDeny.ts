import { ButtonInteraction } from "discord.js";

export default {
    id: "showcaseDeny",
    function: async function ({ button }: { button: ButtonInteraction }) {
        await button.deferUpdate();
        await button.editReply({ content: ":white_check_mark: **This showcase has been denied.**" });
        await button.message.delete();
    }
}