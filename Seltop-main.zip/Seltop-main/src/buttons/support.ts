import { ActionRowBuilder, ButtonInteraction, ModalBuilder, TextInputBuilder, TextInputStyle } from "discord.js"
import config from "../config.js";

export default {
    id: "support",
    function: async function ({ button }: { button: ButtonInteraction }) {
        const modal = new ModalBuilder().setTitle("Support").setCustomId("support").setComponents(
            config.support.questions.slice(0, 5).map((question, i) => {
                return new ActionRowBuilder<TextInputBuilder>().addComponents(
                    new TextInputBuilder().setCustomId(`question-${i}`).setLabel(question.question).setPlaceholder(question.placeholder || question.question).setMinLength(1).setRequired(question.required || false).setStyle(question.short ? TextInputStyle.Short : TextInputStyle.Paragraph)
                )
            })
        );

        await button.showModal(modal);
    }
}