import { ActionRowBuilder, ButtonInteraction } from "discord.js";
import database from "../handlers/databaseHandler.js";
import Commission from "../tables/Commission.js";
import VCRequest from "../tables/VCRequest.js";
import { buildButton, buildEmbed } from "../utils/configBuilders.js";

export default {
    id: "vcfreelancer",
    function: async function ({ button }: { button: ButtonInteraction }) {
        const commission = await database.manager.findOne(Commission, { where: { freelancersMessage: button.message.id } });
        const vcRequestEmbed = buildEmbed("vcRequest").addFields([
            { name: "User", value: `<@${button.user.id}>`, inline: true }
        ]);

        if (!commission) return button.reply({ content: ":x: **This commission doesn't exist.**", ephemeral: true });

        const vcRow = new ActionRowBuilder().addComponents(
            buildButton("vcaccept"),
            buildButton("vcdecline")
        );

        const { client } = await import("../index.js");

        const commissionChannel = await client.channels.fetch(commission.channel).catch(() => null);
        if (!commissionChannel) return button.reply({ content: ":x: **This commission channel doesn't exist.**", ephemeral: true });

        await commissionChannel.send({ content: `<@${commission.user}>`, embeds: [vcRequestEmbed], components: [vcRow] });

        await button.reply({ content: ":white_check_mark: **Sent the VC request to the client.**", ephemeral: true });

        await database.manager.insert(VCRequest, {
            user: button.user.id,
            client: commission.user,
            commission: commission.channel,
            guild: button.guild.id
        });
    }
}