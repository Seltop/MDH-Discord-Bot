import { ActionRowBuilder, ButtonBuilder, ButtonInteraction, ButtonStyle } from "discord.js";
// import { suggestions } from "../database/schemas.js";
import database from "../handlers/databaseHandler.js";
import Suggestion from "../tables/Suggestion.js";

export default {
    id: "downvote",
    function: async function ({ button }: { button: ButtonInteraction }) {
        // const suggestion = await suggestions.findOne({ message: button.message.id });
        const suggestion = await database.manager.findOne(Suggestion, { where: { message: button.message.id } });
        if (!suggestion) return button.reply({ content: ":x: **That suggestion doesn't exist!**", ephemeral: true });

        if (suggestion.state !== "pending") return await button.deferUpdate();

        const updateVotes = async () => {
            const buttons = new ActionRowBuilder<ButtonBuilder>().addComponents([
                new ButtonBuilder().setLabel(`${suggestion.upvotes.length}`).setStyle(ButtonStyle.Success).setCustomId("upvote").setEmoji("👍"),
                new ButtonBuilder().setLabel(`${suggestion.upvotes.length - suggestion.downvotes.length}`).setStyle(ButtonStyle.Primary).setCustomId("difference").setEmoji("#️⃣").setDisabled(true),
                new ButtonBuilder().setLabel(`${suggestion.downvotes.length}`).setStyle(ButtonStyle.Danger).setCustomId("downvote").setEmoji("👎"),
                new ButtonBuilder().setLabel(`${suggestion.state.charAt(0).toUpperCase() + suggestion.state.toLowerCase().slice(1)}`).setStyle(ButtonStyle.Secondary).setCustomId("state").setDisabled(true)
            ]);
            await button.message.edit({ components: [buttons] });
        }

        if (suggestion.downvotes.includes(button.user.id)) {
            suggestion.downvotes = JSON.stringify(JSON.parse(suggestion.downvotes).filter((u) => u !== button.user.id));
            await database.manager.save(suggestion);
            await button.deferUpdate();
            await updateVotes();
        } else if (suggestion.upvotes.includes(button.user.id)) {
            suggestion.upvotes = JSON.stringify(JSON.parse(suggestion.upvotes).filter((u) => u !== button.user.id));
            suggestion.downvotes = JSON.stringify(JSON.parse(suggestion.downvotes).concat(button.user.id));
            await database.manager.save(suggestion);
            await button.deferUpdate();
            await updateVotes();
        } else {
            suggestion.downvotes = JSON.stringify(JSON.parse(suggestion.downvotes).concat(button.user.id));
            await database.manager.save(suggestion);
            await button.deferUpdate();
            await updateVotes();
        }
    }
}