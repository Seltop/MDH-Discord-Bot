import { ActionRowBuilder, ButtonInteraction, ModalBuilder, TextInputBuilder } from "discord.js";
import database from "../handlers/databaseHandler.js";
import Counteroffer from "../tables/Counteroffer.js";
import Commission from "../tables/Commission.js";

export default {
    id: "declineCounter",
    permissions: [],
    function: async function ({ button }: { button: ButtonInteraction }) {
        const counteroffer = await database.manager.findOne(Counteroffer, { where: { id: button.message.id } });
        if (!counteroffer) return button.reply({ content: ":x: **This counteroffer doesn't exist anymore.**", ephemeral: true });
        
        const commission = await database.manager.findOne(Commission, { where: { channel: counteroffer.commission } });
        if (!commission) return button.reply({ content: ":x: **This commission doesn't exist anymore.**", ephemeral: true });

        if (commission.user !== button.user.id) return button.reply({ content: ":x: **You can't decline this quote.**", ephemeral: true });

        const modal = new ModalBuilder().setTitle("Decline Counteroffer").setCustomId("declineCounter").setComponents(
            new ActionRowBuilder<TextInputBuilder>().setComponents(
                new TextInputBuilder().setCustomId("reason").setLabel("Reason").setPlaceholder("The reason for declining this counteroffer.").setMinLength(1).setMaxLength(100).setRequired(false)
            )
        );

        await button.showModal(modal);
    }
}