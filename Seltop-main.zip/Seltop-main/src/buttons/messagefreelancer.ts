import { ActionRowBuilder, ButtonInteraction, ModalBuilder, TextInputBuilder, TextInputStyle } from "discord.js"
import database from "../handlers/databaseHandler.js"
import Commission from "../tables/Commission.js";

export default {
    id: "messagefreelancer",
    function: async function ({ button }: { button: ButtonInteraction }) {
        if (!button.inCachedGuild()) return;

        const commission = await database.manager.findOne(Commission, { where: { freelancersMessage: button.message.id } });

        if (!commission) {
            await button.reply({ content: ":x: **This commission doesn't exist anymore.**", ephemeral: true });
            await button.message.delete();
            return;
        }

        const requiredRoles = JSON.parse(commission.roles);

        if (!requiredRoles.some(role => button.member.roles.cache.has(role))) return await button.reply({ content: ":x: **You don't have the required roles to quote this commission.**", ephemeral: true });

        const modal = new ModalBuilder().setTitle("Send a message to the client").setCustomId("messagefreelancer").addComponents(
            new ActionRowBuilder<TextInputBuilder>().addComponents(
                new TextInputBuilder().setCustomId("messagefreelancer").setLabel("Message").setPlaceholder("Message here").setMaxLength(2000).setMinLength(1).setStyle(TextInputStyle.Paragraph).setRequired(true)
            )
        );

        await button.showModal(modal);
    }
}