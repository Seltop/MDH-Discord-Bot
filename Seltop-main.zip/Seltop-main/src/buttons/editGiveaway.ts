import { ActionRowBuilder, ButtonInteraction, PermissionsBitField, StringSelectMenuBuilder } from "discord.js";
import database from "../handlers/databaseHandler.js";
import Giveaway from "../tables/giveaway.js";

export default {
    id: "editGiveaway",
    function: async function({ button }: { button: ButtonInteraction }) {
        if (!button.inCachedGuild()) return;
        if (!button.member.permissions.has(PermissionsBitField.Flags.ManageGuild)) return await button.reply({ content: ":x: **You don't have the `Manage Server` permission.**", ephemeral: true });

        const giveaway = await database.manager.findOne(Giveaway, { where: { message: button.message.id } });
        if (!giveaway || giveaway.ended) return await button.reply({ content: ":x: **This giveaway no longer exists.**", ephemeral: true });

        const row = new ActionRowBuilder<StringSelectMenuBuilder>().addComponents(
            new StringSelectMenuBuilder().setCustomId("editGiveaway").setPlaceholder("Select an option").setMaxValues(1).addOptions([
                {
                    label: "Prize",
                    value: `prize-${button.message.id}`,
                    description: "Change the giveaway prize",
                    emoji: "🎁"
                },
                {
                    label: "Winners",
                    value: `winners-${button.message.id}`,
                    description: "Change the amount of winners",
                    emoji: "🏆"
                },
                {
                    label: "Length",
                    value: `length-${button.message.id}`,
                    description: "Change the giveaway length",
                    emoji: "⏱️"
                },
                {
                    label: "Requirement",
                    value: `requirement-${button.message.id}`,
                    description: "Change the giveaway requirement",
                    emoji: "🔑"
                }
            ])
        );

        await button.reply({ content: `${button.message.content}\n**Please choose an item to edit...**`, ephemeral: true, components: [row] });
    }
}