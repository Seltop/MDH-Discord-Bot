import { ButtonInteraction } from "discord.js";
import config from "../config.js";
import database from "../handlers/databaseHandler.js";
import Submission from "../tables/Submission.js";
import Vote from "../tables/Vote.js";

export default {
    id: "viewVotes",
    roleRequired: config.roles.competitionJudges,
    function: async function({ button }: { button: ButtonInteraction }) {
        await button.deferReply({ ephemeral: true });

        const submission = await database.manager.findOne(Submission, { where: { message: button.message.id } });
        if (!submission) return await button.editReply({ content: ":x: **This submission does not exist.**" });

        const votes = await database.manager.find(Vote, { where: { submission: submission.id } });
        if (!votes.length) return await button.editReply({ content: ":x: **No votes found.**" });

        const voteAmounts = votes.map(vote => vote.amount);
        const totalVotes = voteAmounts.reduce((a, b) => a + b);
        const averageVotes = totalVotes / votes.length;

        await button.editReply({ content: `:white_check_mark: **Total Votes:** ${totalVotes}\n:bar_chart: **Average Vote:** ${averageVotes.toFixed(2)}\n${votes.map((vote) => `**<@${vote.user}>:** ${vote.amount}`).join("\n")}` });
    }
}