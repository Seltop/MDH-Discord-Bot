import { ButtonInteraction } from "discord.js";
import config from "../config.js";
import { buildEmbed } from "../utils/configBuilders.js";
import database from "../handlers/databaseHandler.js";
import VCRequest from "../tables/VCRequest.js";

export default {
    id: "vcdecline",
    function: async function ({ button }: { button: ButtonInteraction }) {
        const vcreq = await database.manager.findOne(VCRequest, { where: { commission: button.channel.id } });
        if (!vcreq) return button.reply({ content: ":x: **This VC request doesn't exist.**", ephemeral: true });

        const fetchedCategories = [];

        const { client } = await import("../index.js");

        for (const category of config.vc.categories) {
            const fetchedCategory = await client.channels.fetch(category).catch(() => null);
            if (!fetchedCategory) continue;

            fetchedCategories.push(fetchedCategory);
        }

        let parent;

        for (const category of fetchedCategories) {
            if (category.children.size >= 50) continue;
            parent = category;
            break;
        }

        if (!parent) return button.reply({ content: ":x: **There are no available VC categories.**", ephemeral: true });

        const vcDeclinedEmbed = buildEmbed("vcDeclinedTicket");

        await button.update({ embeds: [vcDeclinedEmbed], components: [] });

        const freelancer = await button.guild.members.fetch(vcreq.user).catch(() => null);
        if (!freelancer) return;

        const vcDeclinedDMEmbed = buildEmbed("vcDeclined");

        await freelancer.send({ embeds: [vcDeclinedDMEmbed] });
    }
}