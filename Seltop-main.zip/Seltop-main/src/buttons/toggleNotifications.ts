import { ButtonInteraction } from "discord.js";
import database from "../handlers/databaseHandler.js";
import Commission from "../tables/Commission.js";
import Notifications from "../tables/Notifications.js";

export default {
    id: "toggleNotifications",
    function: async function ({ button }: { button: ButtonInteraction }) {
        const commission = await database.manager.findOne(Commission, { where: { freelancersMessage: button.message.id } });
        if (!commission) return button.reply({ content: ":x: **This commission doesn't exist.**", ephemeral: true });

        const notificationDB = await database.manager.findOne(Notifications, { where: { user: button.user.id, commission: commission.id } });

        if (notificationDB) {
            await database.manager.delete(Notifications, { user: button.user.id, commission: commission.id });

            return button.reply({ content: ":white_check_mark: **Notifications disabled.**", ephemeral: true });
        } else {
            await database.manager.insert(Notifications, { user: button.user.id, commission: commission.id });

            return button.reply({ content: ":white_check_mark: **Notifications enabled.**", ephemeral: true });
        }
    }
}