import { ActionRowBuilder, ButtonInteraction, ModalBuilder, TextInputBuilder, TextInputStyle } from "discord.js";

export default {
    id: "color",
    permissions: [],
    roleRequired: "",
    function: async function ({ button }: { button: ButtonInteraction }) {
        const modal = new ModalBuilder()
            .setCustomId("color")
            .setTitle("Color").addComponents(
                new ActionRowBuilder<TextInputBuilder>().addComponents(
                    new TextInputBuilder()
                        .setCustomId("color")
                        .setLabel("Color")
                        .setStyle(TextInputStyle.Short)
                        .setMinLength(0)
                        .setMaxLength(256)
                        .setRequired(true)
                        .setValue(button.message.embeds[0]?.color.toString(16) || "#000000")
                )
            );

        await button.showModal(modal);
    }
}