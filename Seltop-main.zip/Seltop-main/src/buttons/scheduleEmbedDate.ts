import { ActionRowBuilder, ButtonInteraction, ModalBuilder, TextInputBuilder, TextInputStyle } from "discord.js";
import database from "../handlers/databaseHandler.js";
import Schedule from "../tables/Schedule.js";

export default {
    id: "scheduleEmbedDate",
    function: async function({ button }: { button: ButtonInteraction }) {
        const schedule = await database.manager.findOne(Schedule, { where: { id: button.message.id } });
        if (!schedule) return button.reply({ content: ":x: **Could not find that schedule.**", ephemeral: true });

        const modal = new ModalBuilder().setTitle("Schedule Embed Date").setCustomId("scheduleEmbedDate").setComponents(
            new ActionRowBuilder<TextInputBuilder>().addComponents(
                new TextInputBuilder().setLabel("Date").setCustomId("scheduleEmbedDate").setPlaceholder("YYYY-MM-DD").setRequired(true).setStyle(TextInputStyle.Short)
            ),
            new ActionRowBuilder<TextInputBuilder>().addComponents(
                new TextInputBuilder().setLabel("Time").setCustomId("scheduleEmbedTime").setPlaceholder("HH:MM").setRequired(true).setStyle(TextInputStyle.Short)
            ),
            new ActionRowBuilder<TextInputBuilder>().addComponents(
                new TextInputBuilder().setLabel("UTC Offset").setCustomId("scheduleEmbedUTC").setPlaceholder("+0").setRequired(true).setStyle(TextInputStyle.Short)
            )
        );

        await button.showModal(modal);
    }
}