import { ButtonInteraction, ChannelType, PermissionsBitField } from "discord.js";
import config from "../config.js";
import { buildEmbed } from "../utils/configBuilders.js";
import database from "../handlers/databaseHandler.js";
import VCRequest from "../tables/VCRequest.js";
import VC from "../tables/VC.js";

export default {
    id: "vcaccept",
    function: async function ({ button }: { button: ButtonInteraction }) {
        const vcreq = await database.manager.findOne(VCRequest, { where: { commission: button.channel.id } });
        if (!vcreq) return button.reply({ content: ":x: **This VC request doesn't exist.**", ephemeral: true });

        const fetchedCategories = [];

        const { client } = await import("../index.js");

        for (const category of config.vc.categories) {
            const fetchedCategory = await client.channels.fetch(category).catch(() => null);
            if (!fetchedCategory) continue;

            fetchedCategories.push(fetchedCategory);
        }

        let parent;

        for (const category of fetchedCategories) {
            if (category.children.size >= 50) continue;
            parent = category;
            break;
        }

        if (!parent) return button.reply({ content: ":x: **There are no available VC categories.**", ephemeral: true });

        const channel = await button.guild.channels.create({
            name: `${button.user.username}'s VC`,
            type: ChannelType.GuildVoice,
            parent: parent.id,
            permissionOverwrites: [
                {
                    id: button.user.id,
                    allow: [PermissionsBitField.Flags.ViewChannel, PermissionsBitField.Flags.Connect, PermissionsBitField.Flags.Speak]
                },
                {
                    id: vcreq.user,
                    allow: [PermissionsBitField.Flags.ViewChannel, PermissionsBitField.Flags.Connect, PermissionsBitField.Flags.Speak]
                },
                {
                    id: button.guild.id,
                    deny: [PermissionsBitField.Flags.ViewChannel, PermissionsBitField.Flags.Connect, PermissionsBitField.Flags.Speak]
                },
                ...config.vc.roles.map(role => ({
                    id: role,
                    allow: [PermissionsBitField.Flags.ViewChannel, PermissionsBitField.Flags.Connect, PermissionsBitField.Flags.Speak]
                }))
            ]
        });

        const vcCreatedEmbed = buildEmbed("vcCreated").addFields([
            { name: "Channel", value: `<#${channel.id}>`, inline: true }
        ]);

        await button.update({ embeds: [vcCreatedEmbed], components: [] });

        const freelancer = await button.guild.members.fetch(vcreq.user).catch(() => null);
        if (!freelancer) return;

        const vcCreatedDMEmbed = buildEmbed("vcAccepted").addFields([
            { name: "Channel", value: `<#${channel.id}>`, inline: true }
        ]);

        await freelancer.send({ embeds: [vcCreatedDMEmbed] });

        await database.manager.insert(VC, {
            channel: channel.id,
            commission: vcreq.commission,
            user: button.user.id,
            client: vcreq.user,
            guild: button.guild.id
        });
    }
}