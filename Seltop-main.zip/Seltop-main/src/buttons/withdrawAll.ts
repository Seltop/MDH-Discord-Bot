import { ActionRowBuilder, ButtonInteraction } from "discord.js";
import Wallet from "../tables/Wallet.js";
import FreelancerProfile from "../tables/FreelancerProfile.js";
import Withdrawal from "../tables/Withdrawal.js";
import database from "../handlers/databaseHandler.js";
import config from "../config.js";
import { buildButton, buildEmbed } from "../utils/configBuilders.js";

export default {
    id: "withdrawAll",
    function: async function ({ button }: { button: ButtonInteraction }) {
        const wallet = await database.manager.findOne(Wallet, { where: { user: button.user.id } });
        if (!wallet) return button.reply({ content: ":x: **An error occured while fetching your wallet.**", ephemeral: true });

        if (!(wallet.balance > 0)) return button.reply({ content: ":x: **You don't have any money to withdraw.**", ephemeral: true });

        const profile = await database.manager.findOne(FreelancerProfile, { where: { user: button.user.id } });
        if (!profile || !profile.paypal) return button.reply({ content: ":x: **You need to set your PayPal account first.**", ephemeral: true });

        const embed = buildEmbed("withdrawalRequest").addFields([
            { name: "User", value: `<@${button.user.id}>`, inline: true },
            { name: "Amount", value: `$${wallet.balance.toLocaleString()}`, inline: true },
            { name: "Date", value: `<t:${Math.round(Date.now() / 1000)}>`, inline: true },
            { name: "PayPal", value: profile.paypal || "None", inline: true },
            { name: "Preferred Payment Method", value: profile.paymentMethod || "PayPal", inline: true }
        ]);

        const { client } = await import("../index.js");
        
        const requestsChannel = await client.channels.fetch(config.wallet.withdrawRequestsChannel).catch(() => null);
        if (!requestsChannel) return button.reply({ content: ":x: **An error occured while fetching the withdrawal requests channel.**", ephemeral: true });

        const row = new ActionRowBuilder().addComponents(
            buildButton("WithdrawalRequestApprove"),
            buildButton("WithdrawalRequestDeny")
        );

        const requestMsg = await requestsChannel.send({ embeds: [embed], components: [row] });

        await database.manager.insert(Withdrawal, {
            id: requestMsg.id,
            user: button.user.id,
            amount: wallet.balance,
            status: "pending",
            date: new Date()
        });

        await button.update({ components: [] });
        await button.followUp({ content: ":white_check_mark: **Your withdrawal request has been sent.**", ephemeral: true });

        await button.user.send({ content: `:white_check_mark: **Your withdrawal request has been sent.**\n**Amount:** $${wallet.balance.toLocaleString()}` }).catch(() => null);
    }
}