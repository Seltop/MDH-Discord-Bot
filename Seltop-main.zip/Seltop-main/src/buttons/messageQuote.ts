import { ActionRowBuilder, ButtonInteraction, ModalBuilder, TextInputBuilder, TextInputStyle } from "discord.js"

export default {
    id: "messageQuote",
    function: async function ({ button }: { button: ButtonInteraction }) {
        const modal = new ModalBuilder().setTitle("Send a message to the freelancer").setCustomId("messageQuote").addComponents(
            new ActionRowBuilder<TextInputBuilder>().addComponents(
                new TextInputBuilder().setCustomId("messageQuote").setLabel("Message").setPlaceholder("Message here").setMaxLength(2000).setMinLength(1).setStyle(TextInputStyle.Paragraph).setRequired(true)
            )
        );

        await button.showModal(modal);
    }
}