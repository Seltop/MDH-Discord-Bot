import { ActionRowBuilder, ButtonInteraction, ModalBuilder, TextInputBuilder, TextInputStyle } from "discord.js";
import database from "../handlers/databaseHandler.js";
import Commission from "../tables/Commission.js";

export default {
    id: "quote",
    permissions: [],
    function: async function ({ button }: { button: ButtonInteraction }) {
        if (!button.inCachedGuild()) return;

        const commission = await database.manager.findOne(Commission, { where: { freelancersMessage: button.message.id } });
        
        if (!commission) {
            await button.reply({ content: ":x: **This commission doesn't exist anymore.**", ephemeral: true });
            await button.message.delete();
            return;
        }

        const requiredRoles = JSON.parse(commission.roles);

        if (!requiredRoles.some(role => button.member.roles.cache.has(role))) return await button.reply({ content: ":x: **You don't have the required roles to quote this commission.**", ephemeral: true });

        const quoteModal = new ModalBuilder().setTitle("Quote").setCustomId("quote").addComponents(
            new ActionRowBuilder<TextInputBuilder>().addComponents(
                new TextInputBuilder().setCustomId("amount").setLabel("Amount").setPlaceholder("Quote amount here. (Only numbers)").setRequired(true).setStyle(TextInputStyle.Short)
            ),
            new ActionRowBuilder<TextInputBuilder>().addComponents(
                new TextInputBuilder().setCustomId("timeframe").setLabel("Timeframe").setPlaceholder("Quote expected timeframe here.").setRequired(true).setStyle(TextInputStyle.Short)
            ),
            new ActionRowBuilder<TextInputBuilder>().addComponents(
                new TextInputBuilder().setCustomId("comment").setLabel("Comment").setPlaceholder("Quote comment here. (Optional)").setRequired(false).setStyle(TextInputStyle.Paragraph)
            )
        )

        await button.showModal(quoteModal);
    }
}