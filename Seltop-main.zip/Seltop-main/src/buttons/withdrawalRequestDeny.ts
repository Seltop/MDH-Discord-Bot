import { ButtonInteraction } from "discord.js";
import Withdrawal from "../tables/Withdrawal.js";
import database from "../handlers/databaseHandler.js";
import { buildEmbed } from "../utils/configBuilders.js";

export default {
    id: "WithdrawalRequestDeny",
    function: async function ({ button }: { button: ButtonInteraction }) {
        const request = await database.manager.findOne(Withdrawal, { where: { id: button.message.id } });

        if (!request) return button.reply({ content: ":x: **An error occured while fetching the withdrawal request.**", ephemeral: true });

        if (request.status !== "pending") return button.reply({ content: ":x: **This request has already been reviewed.**", ephemeral: true });

        await database.manager.update(Withdrawal, { id: button.message.id }, { status: "denied" });

        await button.reply({ content: ":white_check_mark: **The withdrawal request has been denied.**", ephemeral: true });

        await button.message.edit({ components: [], content: ":x: **Denied.**" });

        const member = await button.guild.members.fetch(request.user).catch(() => null);

        if (!member) return;

        const embed = buildEmbed("withdrawalDenied").addFields([
            {
                name: "Amount",
                value: `$${request.amount.toLocaleString()}`,
                inline: true
            },
            {
                name: "Date",
                value: `<t:${Math.round(Date.now() / 1000)}>`,
                inline: true
            }
        ]);

        await member.send({ embeds: [embed] }).catch(() => null);
    }
}