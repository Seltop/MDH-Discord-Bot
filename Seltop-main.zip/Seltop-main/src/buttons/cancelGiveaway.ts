import { ButtonInteraction, PermissionsBitField } from "discord.js";
import Giveaway from "../tables/giveaway.js";
import database from "../handlers/databaseHandler.js";

export default {
    id: "cancelGiveaway",
    function: async function({ button }: { button: ButtonInteraction }) {
        if (!button.inCachedGuild()) return;
        if (!button.member.permissions.has(PermissionsBitField.Flags.ManageGuild)) return await button.reply({ content: ":x: **You don't have the `Manage Server` permission.**", ephemeral: true });

        const giveaway = await database.manager.findOne(Giveaway, { where: { message: button.message.id } });
        if (!giveaway || giveaway.ended) return await button.reply({ content: ":x: **This giveaway no longer exists.**", ephemeral: true });

        await database.manager.delete(Giveaway, { message: button.message.id });
        await button.reply({ content: ":white_check_mark: **Successfully cancelled the giveaway.**", ephemeral: true });
        await button.message.delete();
    }
}