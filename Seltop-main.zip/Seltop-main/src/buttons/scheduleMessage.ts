import { ActionRowBuilder, ButtonInteraction, ModalBuilder, TextInputBuilder, TextInputStyle } from "discord.js";

export default {
    id: "scheduleMessage",
    function: async function ({ button }: { button: ButtonInteraction }) {
        const modal = new ModalBuilder().setTitle("Schedule Message").setCustomId("scheduleMessage").setComponents(
            new ActionRowBuilder<TextInputBuilder>().addComponents(
                new TextInputBuilder().setCustomId("scheduleMessage").setLabel("Message").setMaxLength(2000).setStyle(TextInputStyle.Paragraph).setRequired(true)
            )
        );

        await button.showModal(modal);
    }
}