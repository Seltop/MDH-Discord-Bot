import { ButtonInteraction } from "discord.js";
import database from "../handlers/databaseHandler.js";
import Schedule from "../tables/Schedule.js";

export default {
    id: "confirmSchedule",
    function: async function({ button }: { button: ButtonInteraction }) {
        const schedule = await database.manager.findOne(Schedule, { where: { id: button.message.id } });
        if (!schedule) return button.reply({ content: ":x: **Could not find that schedule.**", ephemeral: true });

        schedule.active = true;
        schedule.lastModified = Date.now();
        await database.manager.save(schedule);

        await button.deferUpdate();
        await button.message.edit({ content: ":white_check_mark: **Schedule confirmed!**", components: [] });
    }
}