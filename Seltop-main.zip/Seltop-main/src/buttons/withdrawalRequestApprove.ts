import { ButtonInteraction } from "discord.js";
import Withdrawal from "../tables/Withdrawal.js";
import Wallet from "../tables/Wallet.js";
import database from "../handlers/databaseHandler.js";
import { buildEmbed } from "../utils/configBuilders.js";

export default {
    id: "WithdrawalRequestApprove",
    function: async function ({ button }: { button: ButtonInteraction }) {
        const request = await database.manager.findOne(Withdrawal, { where: { id: button.message.id } });

        if (!request) return button.reply({ content: ":x: **An error occured while fetching the withdrawal request.**", ephemeral: true });

        if (request.status !== "pending") return button.reply({ content: ":x: **This request has already been reviewed.**", ephemeral: true });

        const wallet = await database.manager.findOne(Wallet, { where: { user: request.user } });
        if (!wallet) return button.reply({ content: ":x: **An error occured while fetching the user's wallet.**", ephemeral: true });

        if (wallet.balance < request.amount) return button.reply({ content: `:x: **The user doesn't have enough money to withdraw.**`, ephemeral: true });

        wallet.balance -= request.amount;

        await database.manager.update(Withdrawal, { id: button.message.id }, { status: "approved" });

        await button.reply({ content: ":white_check_mark: **The withdrawal request has been approved.**", ephemeral: true });

        await button.message.edit({ components: [], content: ":white_check_mark: **Approved.**" });

        wallet.transactions = JSON.stringify([...JSON.parse(wallet.transactions), {
            type: `Withdrawal - ${request.amount.toLocaleString()}`,
            amount: request.amount,
            date: Date.now(),
            added: false
        }]);

        await database.manager.save(wallet);

        const member = await button.guild.members.fetch(request.user).catch(() => null);
        
        if (!member) return;

        const embed = buildEmbed("withdrawalAccepted").addFields([
            {
                name: "Amount",
                value: `$${request.amount.toLocaleString()}`,
                inline: true
            },
            {
                name: "Date",
                value: `<t:${Math.round(Date.now() / 1000)}>`,
                inline: true
            }
        ]);

        await member.send({ embeds: [embed] }).catch(() => null);
    }
}