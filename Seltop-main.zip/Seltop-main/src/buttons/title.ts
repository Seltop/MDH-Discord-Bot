import { ActionRowBuilder, ButtonInteraction, ModalBuilder, TextInputBuilder, TextInputStyle } from "discord.js";

export default {
    id: "title",
    permissions: [],
    roleRequired: "",
    function: async function ({ button }: { button: ButtonInteraction }) {
        const modal = new ModalBuilder()
            .setCustomId("title")
            .setTitle("Title").addComponents(
                new ActionRowBuilder<TextInputBuilder>().addComponents(
                    new TextInputBuilder()
                        .setCustomId("title")
                        .setLabel("Title")
                        .setStyle(TextInputStyle.Short)
                        .setMinLength(0)
                        .setMaxLength(256)
                        .setRequired(true)
                        .setValue(button.message.embeds[0]?.title || "No Title")
                )
            );

        await button.showModal(modal);
    }
}