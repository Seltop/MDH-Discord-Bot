import { ActionRowBuilder, AttachmentBuilder, ButtonBuilder, ButtonInteraction, GuildTextBasedChannel, Message } from "discord.js";
import database from "../handlers/databaseHandler.js";
import Competition from "../tables/Competition.js";
import Submission from "../tables/Submission.js";
import axios from "axios";
import config from "../config.js";
import { buildButton, buildEmbed } from "../utils/configBuilders.js";

export default {
    id: "submit",
    function: async function({ button }: { button: ButtonInteraction }) {
        await button.deferReply({ ephemeral: true });

        const competition = await database.manager.findOne(Competition, { where: { message: button.message.id } });

        if (!competition) return await button.editReply({ content: ":x: **This competition does not exist.**" });
        if (!competition.submissionsOpen) return await button.editReply({ content: ":x: **Submissions are closed for this competition.**" });

        const msg: Message = await button.user.send({ content: "**Please send your submission message...**" }).catch(async () => {
            await button.editReply({ content: ":x: **I cannot DM you.**" });
            return null;
        });

        if (!msg) return;
        await button.editReply({ content: ":white_check_mark: **Please check your DMs to continue!**" });

        const submissionMessage = await msg.channel.awaitMessages({ filter: m => m.author.id === button.user.id, max: 1, time: 120000, errors: ["time"] }).catch(async () => {
            await msg.edit({ content: ":x: **Submission timed out.**" });
            return null;
        });

        if (!submissionMessage) return;

        const image = submissionMessage.first()?.attachments.first()?.url;
        const message = submissionMessage.first()?.content;

        if (!image) return await msg.channel.send({ content: ":x: **Please attach an image to your submission, click on the submit button again to continue.**" });
        if (!message) return await msg.channel.send({ content: ":x: **Please send a message with your submission, click on the submit button again to continue.**" });

        const attachment = await axios.default.get(image, { responseType: "arraybuffer" }).catch(async () => {
            await msg.channel.send({ content: ":x: **An error occurred while fetching the image.**" });
            return null;
        });

        if (!attachment) return;
        
        const submissionsChannel = button.guild?.channels.cache.get(config.channels.submissions) as GuildTextBasedChannel;

        if (!submissionsChannel) return await msg.channel.send({ content: ":x: **Submissions channel not found.**" });
        
        const discAttachment = new AttachmentBuilder(attachment.data, { name: "submission.png" });

        const embed = buildEmbed("submission")
            .setTitle(competition.name)
            .setDescription(message)
            .setImage("attachment://submission.png")
            .setAuthor({ name: button.user.username, iconURL: button.user.displayAvatarURL() })

        const row = new ActionRowBuilder<ButtonBuilder>().addComponents(
            buildButton("vote1"),
            buildButton("vote2"),
            buildButton("vote4"),
            buildButton("vote6"),
            buildButton("vote8")
        );

        const viewVotes = new ActionRowBuilder<ButtonBuilder>().addComponents(
            buildButton("viewVotes")
        );

        const submissionMsg = await submissionsChannel.send({ embeds: [embed], components: [row, viewVotes], files: [discAttachment] });

        await database.manager.insert(Submission, {
            competition: competition.id,
            user: button.user.id,
            message: submissionMsg.id,
            submissionDate: Date.now()
        });

        await msg.channel.send({ content: ":white_check_mark: **Submission sent!**" });
    }
}