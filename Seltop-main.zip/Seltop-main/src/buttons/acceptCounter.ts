import { ButtonInteraction, GuildTextBasedChannel } from "discord.js";
import config from "../config.js";
import database from "../handlers/databaseHandler.js";
import { buildEmbed } from "../utils/configBuilders.js";
import Counteroffer from "../tables/Counteroffer.js";
import Commission from "../tables/Commission.js";
import Quote from "../tables/Quote.js";

export default {
    id: "acceptCounter",
    function: async function({ button }: { button: ButtonInteraction }) {
        const counteroffer = await database.manager.findOne(Counteroffer, { where: { msg: button.message.id } })
        if (!counteroffer) return button.reply({ content: ":x: ***This counteroffer doesn't exist anymore.**", ephemeral: true });

        const commission = await database.manager.findOne(Commission, { where: { channel: counteroffer.commission } });
        if (!commission) return button.reply({ content: ":x: ***This commission doesn't exist anymore.**", ephemeral: true });

        const quote = await database.manager.findOne(Quote, { where: { id: counteroffer.quote } });
        if (!quote) return button.reply({ content: ":x: ***This quote doesn't exist anymore.**", ephemeral: true });

        const departments = [];

        for (const department of config.departments) {
            for (const role of commission.roles) {
                if (department.specialties.filter((specialty) => specialty.id === role).length > 0) {
                    departments.push(department);
                }
            }
        }

        const { client } = await import("../index.js");

        const freelancersChannel = await client.channels.fetch(departments[0].freelancerChannel).catch(() => null) as GuildTextBasedChannel;
        if (!freelancersChannel) return button.reply({ content: ":x: ***The freelancers channel doesn't exist anymore.**", ephemeral: true });
        
        const freelancerMessage = await freelancersChannel.messages.fetch(commission.freelancersMessage).catch(() => null);
        await freelancerMessage?.delete().catch(() => null);

        commission.freelancer = counteroffer.freelancer;
        await database.manager.save(commission);

        const commissionChannel = await client.channels.fetch(commission.channel).catch(() => null) as GuildTextBasedChannel;
        if (!commissionChannel) return button.reply({ content: ":x: ***The commission channel doesn't exist anymore.**", ephemeral: true });
        if (commissionChannel.isThread()) return button.reply({ content: ":x: ***The commission channel is a thread, what..?**", ephemeral: true });

        await commissionChannel.permissionOverwrites.edit(counteroffer.freelancer, { ViewChannel: true, SendMessages: true });

        const counterofferAccepted = buildEmbed("counterofferAccepted").setFields([
            { name: "Amount", value: `$${counteroffer.price}`, inline: true },
            { name: "Timeframe", value: quote.timeframe, inline: true },
            { name: "Comment", value: quote.comment || "None", inline: true }
        ]);

        await commissionChannel.send({ content: `<@${commission.freelancer}> <@${commission.user}>`, embeds: [counterofferAccepted] });

        await button.message.edit({ embeds: [counterofferAccepted], components: [] });
    }
}