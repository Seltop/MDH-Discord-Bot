import { ActionRowBuilder, ButtonInteraction, ModalBuilder, TextInputBuilder, TextInputStyle } from "discord.js";

export default {
    id: "description",
    permissions: [],
    roleRequired: "",
    function: async function ({ button }: { button: ButtonInteraction }) {
        const modal = new ModalBuilder()
            .setCustomId("description")
            .setTitle("Description").addComponents(
                new ActionRowBuilder<TextInputBuilder>().addComponents(
                    new TextInputBuilder()
                        .setCustomId("description")
                        .setLabel("Description")
                        .setStyle(TextInputStyle.Paragraph)
                        .setMinLength(0)
                        .setMaxLength(4000)
                        .setRequired(true)
                        .setValue(button.message.embeds[0]?.description || "No Description")
                )
            );

        await button.showModal(modal);
    }
}