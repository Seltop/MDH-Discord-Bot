import { ActionRowBuilder, ButtonInteraction, ModalBuilder, TextInputBuilder, TextInputStyle } from "discord.js"

export default {
    id: "counteroffer",
    function: async function({ button }: { button: ButtonInteraction }) {
        const modal = new ModalBuilder().setTitle("Counteroffer").setCustomId("counteroffer").addComponents(
            new ActionRowBuilder<TextInputBuilder>().addComponents(
                new TextInputBuilder().setCustomId("counteroffer").setLabel("Counteroffer").setPlaceholder("Counteroffer here (Number only)").setMaxLength(2000).setMinLength(1).setStyle(TextInputStyle.Short).setRequired(true)
            )
        );

        await button.showModal(modal);
    }
}