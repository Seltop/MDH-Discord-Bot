import { ChannelType, ColorResolvable, EmbedBuilder, ModalSubmitInteraction, PermissionsBitField } from "discord.js";
import config from "../config.js";
import Application from "../tables/Application.js";
import database from "../handlers/databaseHandler.js";

export default {
    id: "freelancerapply",
    function: async function ({ interaction }: { interaction: ModalSubmitInteraction }) {
        const answers = [];

        for (let i=0; i<5; i++) {
            const question = config.freelancerQuestions[i];
            if (!question) break;
            const answer = interaction.fields.getTextInputValue(`question-${i}`)
            answers.push({ question: question.question, answer: answer });
        }

        let application;
        const applications = await database.manager.find(Application, { where: { user: interaction.user.id, guild: interaction.guild.id, status: "answering" } });

        for (const app of applications) {
            if (!application) application = app;
            if (app.createdAt > application.createdAt) application = app;
        }

        if (!application) return await interaction.reply({ content: ":x: **You don't have an application in progress.**", ephemeral: true });

        const departments = [];

        for (const department of config.departments) {
            for (const role of application.roles) {
                if (department.specialties.filter((specialty) => specialty.id === role).length > 0) {
                    departments.push(department);
                }
            }
        }

        const channel = await interaction.guild.channels.create({
            name: `application-${interaction.user.username}`,
            type: ChannelType.GuildText,
            parent: departments[0].applicationsCategory,
            permissionOverwrites: [
                {
                    id: interaction.guild.roles.everyone.id,
                    deny: [PermissionsBitField.Flags.ViewChannel]
                },
                {
                    id: interaction.user.id,
                    allow: [PermissionsBitField.Flags.ViewChannel]
                },
                {
                    id: config.roles.applicationReviewers,
                    allow: [PermissionsBitField.Flags.ViewChannel]
                }
            ],
            topic: `Application for ${interaction.user.username}#${interaction.user.discriminator}`
        });

        const applicationCreatedEmbed = new EmbedBuilder()
            .setTitle(config.embeds.applicationCreated.title || null)
            .setDescription(config.embeds.applicationCreated.description || null)
            .setColor(config.embeds.applicationCreated.color as ColorResolvable || null)
            .setAuthor({ name: config.embeds.applicationCreated.author.name || null, iconURL: config.embeds.applicationCreated.author.iconURL || null })
            .setFooter({ text: config.embeds.applicationCreated.footer.text || null, iconURL: config.embeds.applicationCreated.footer.iconURL || null })
            .setImage(config.embeds.applicationCreated.image || null)
            .setThumbnail(config.embeds.applicationCreated.thumbnail || null)
            if (config.embeds.applicationCreated.timestamp) applicationCreatedEmbed.setTimestamp()

        await interaction.reply({ content: `<#${channel.id}>`, embeds: [applicationCreatedEmbed], ephemeral: true });

        const applicationEmbed = new EmbedBuilder()
            .setTitle(config.embeds.applicationSent.title || null)
            .setDescription(config.embeds.applicationSent.description || null)
            .setColor(config.embeds.applicationSent.color as ColorResolvable || null)
            .setAuthor({ name: config.embeds.applicationSent.author.name || null, iconURL: config.embeds.applicationSent.author.iconURL || null })
            .setFooter({ text: config.embeds.applicationSent.footer.text || null, iconURL: config.embeds.applicationSent.footer.iconURL || null })
            .setImage(config.embeds.applicationSent.image || null)
            .setThumbnail(config.embeds.applicationSent.thumbnail || null)
            .setFields(
                {
                    name: "Roles",
                    value: application.roles.map(role => `<@&${role}>`).join(", ")
                },
                ...answers.map(answer => {
                    return {
                        name: answer.question,
                        value: answer.answer
                    }
                })
            )
            if (config.embeds.applicationSent.timestamp) applicationEmbed.setTimestamp()

        await channel.send({ embeds: [applicationEmbed] });

        application.answers = answers;
        application.channel = channel.id;
        application.status = "pending";

        await application.save();
    }
}
