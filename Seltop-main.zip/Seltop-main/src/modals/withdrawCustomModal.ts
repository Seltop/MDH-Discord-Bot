import { ActionRowBuilder, ModalSubmitInteraction } from "discord.js";
import FreelancerProfile from "../tables/FreelancerProfile.js";
import Wallet from "../tables/Wallet.js";
import Withdrawal from "../tables/Withdrawal.js";
import database from "../handlers/databaseHandler.js";
import config from "../config.js";
import { buildButton, buildEmbed } from "../utils/configBuilders.js";

export default {
    id: "withdrawCustomModal",
    function: async function ({ interaction }: { interaction: ModalSubmitInteraction }) {
        const amount = Number(interaction.fields.getTextInputValue("withdrawCustomAmount"));
        if (isNaN(amount) || amount < 1) return interaction.reply({ content: ":x: **The amount must be a valid number.**", ephemeral: true });

        const wallet = await database.manager.findOne(Wallet, { where: { user: interaction.user.id } });
        if (!wallet) return interaction.reply({ content: ":x: **An error occured while fetching your wallet.**", ephemeral: true });

        if (wallet.balance < amount) return interaction.reply({ content: ":x: **You don't have enough balance to withdraw this amount.**", ephemeral: true });

        const profile = await database.manager.findOne(FreelancerProfile, { where: { user: interaction.user.id } });
        if (!profile || !profile.paypal) return interaction.reply({ content: ":x: **You need to set your PayPal account first.**", ephemeral: true });
        
        const embed = buildEmbed("withdrawalRequest").addFields([
            { name: "User", value: `<@${interaction.user.id}>`, inline: true },
            { name: "Amount", value: `$${amount.toLocaleString()}`, inline: true },
            { name: "Date", value: `<t:${Math.round(Date.now() / 1000)}>`, inline: true },
            { name: "PayPal", value: profile.paypal || "None", inline: true },
            { name: "Preferred Payment Method", value: profile.paymentMethod || "PayPal", inline: true }
        ]);

        const { client } = await import("../index.js");

        const requestsChannel = await client.channels.fetch(config.wallet.withdrawRequestsChannel).catch(() => null);
        if (!requestsChannel) return interaction.reply({ content: ":x: **An error occured while fetching the withdrawal requests channel.**", ephemeral: true });

        const row = new ActionRowBuilder().addComponents(
            buildButton("WithdrawalRequestApprove"),
            buildButton("WithdrawalRequestDeny")
        );

        const requestMsg = await requestsChannel.send({ embeds: [embed], components: [row] });

        await database.manager.insert(Withdrawal, {
            id: requestMsg.id,
            user: interaction.user.id,
            amount: amount,
            status: "pending",
            date: Date.now()
        });

        await interaction.editReply({ components: [] });
        await interaction.followUp({ content: ":white_check_mark: **Your withdrawal request has been sent.**", ephemeral: true });

        await interaction.user.send({ content: `:white_check_mark: **Your withdrawal request has been sent.**\n**Amount:** $${amount.toLocaleString()}` }).catch(() => null);
    }
}