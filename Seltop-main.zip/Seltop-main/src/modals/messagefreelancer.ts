import { ActionRowBuilder, ChannelType, ModalSubmitInteraction } from "discord.js";
import Commission from "../tables/Commission.js";
import Message from "../tables/Message.js";
import Notifications from "../tables/Notifications.js";
import database from "../handlers/databaseHandler.js";
import { buildButton, buildEmbed } from "../utils/configBuilders.js";

export default {
    id: "messagefreelancer",
    function: async function({ interaction }: { interaction: ModalSubmitInteraction }) {
        const messageInput = interaction.fields.getTextInputValue("messagefreelancer");

        const commission = await database.manager.findOne(Commission, { where: { freelancersMessage: interaction.message.id } });
        if (!commission) return interaction.reply({ content: ":x: **This commission doesn't exist.**", ephemeral: true });

        const embed = buildEmbed("message")
            .setDescription(`\`\`\`${messageInput}\`\`\``)
            .setAuthor({ name: interaction.user.username, iconURL: interaction.user.avatarURL() });

        const replyRow = new ActionRowBuilder().addComponents(
            buildButton("reply")
        );

        const { client } = await import("../index.js");

        const commissionChannel = await client.channels.fetch(commission.channel).catch(() => null);
        if (!commissionChannel) return interaction.reply({ content: ":x: **This commission channel doesn't exist.**", ephemeral: true });

        const msg = await commissionChannel.send({ content: `<@${commission.user}>`, embeds: [embed], components: [replyRow] });

        await interaction.reply({ content: ":white_check_mark: **Message sent.**", embeds: [embed], ephemeral: true });

        if (interaction.channel.type !== ChannelType.GuildText) return;
        const commissionThread = await interaction.channel.threads.fetch(commission.thread).catch(() => null);

        if (commissionThread) await commissionThread.send({ embeds: [embed] });

        await database.manager.insert(Message, {
            id: msg.id,
            source: interaction.user.id,
            destination: commission.channel,
            message: messageInput,
            threadChannel: JSON.stringify({
                channel: interaction.channel.id,
                thread: commission.thread
            })
        });

        await database.manager.find(Notifications, { where: { commission: commission.id } }).then(async notifications => {
            for (const notification of notifications) {
                const user = await interaction.guild.members.fetch(notification.user).catch(() => null);
                if (!user) continue;

                await user.send({ content: `:bell: **A new message has been posted in <#${commission.thread}>**`, embeds: [embed] }).catch(() => null);
            }
        });
    }
}