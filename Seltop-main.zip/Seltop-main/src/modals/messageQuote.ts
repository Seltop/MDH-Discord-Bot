import { ActionRowBuilder, ModalSubmitInteraction } from "discord.js";
import Quote from "../tables/Quote.js";
import Message from "../tables/Message.js";
import database from "../handlers/databaseHandler.js";
import { buildButton, buildEmbed } from "../utils/configBuilders.js";

export default {
    id: "messageQuote",
    function: async function({ interaction }: { interaction: ModalSubmitInteraction }) {
        const messageInput = interaction.fields.getTextInputValue("messageQuote");

        const quote = await database.manager.findOne(Quote, { where: { id: interaction.message.id } });
        if (!quote) return interaction.reply({ content: ":x: **This quote doesn't exist.**", ephemeral: true });

        const embed = buildEmbed("message")
            .setDescription(`\`\`\`${messageInput}\`\`\``)
            .setAuthor({ name: interaction.user.username, iconURL: interaction.user.avatarURL() });

        const freelancer = await interaction.guild.members.fetch(quote.freelancer).catch(() => null);
        if (!freelancer) return interaction.reply({ content: ":x: **This freelancer doesn't exist.**", ephemeral: true });

        const replyRow = new ActionRowBuilder().addComponents(
            buildButton("reply")
        );

        const msg = await freelancer.send({ embeds: [embed], components: [replyRow] });
        
        await interaction.reply({ content: ":white_check_mark: **Message sent.**", embeds: [embed] });

        await database.manager.insert(Message, {
            id: msg.id,
            source: interaction.channel.id,
            destination: quote.freelancer,
            guild: interaction.guild.id,
            message: messageInput
        });
    }
}