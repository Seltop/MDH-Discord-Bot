import { ActionRowBuilder, ButtonBuilder, GuildTextBasedChannel, ModalSubmitInteraction } from "discord.js";
import Commission from "../tables/Commission.js";
import FreelancerProfile from "../tables/FreelancerProfile.js";
import Quote from "../tables/Quote.js";
import database from "../handlers/databaseHandler.js";
import { buildButton, buildEmbed } from "../utils/configBuilders.js";
import config from "../config.js";

export default {
    id: "quote",
    function: async function ({ interaction }: { interaction: ModalSubmitInteraction }) {
        const commission = await database.manager.findOne(Commission, { where: { freelancersMessage: interaction.message.id } });
        
        if (!commission) return interaction.reply({ content: ":x: **This commission doesn't exist anymore.**", ephemeral: true });

        if (!config.debugMode && interaction.user.id == commission.user) return interaction.reply({ content: ":x: **You can't quote your own commission.**", ephemeral: true });

        const profile = await database.manager.findOne(FreelancerProfile, { where: { user: interaction.user.id } });
        if (!profile || !profile?.portfolio) return interaction.reply({ content: ":x: **You don't have a portfolio set.**", ephemeral: true });

        const amount = interaction.fields.getTextInputValue("amount");
        const timeframe = interaction.fields.getTextInputValue("timeframe");
        const comment = interaction.fields.getTextInputValue("comment");
        
        if (isNaN(Number(amount)) || !parseInt(amount)) return interaction.reply({ content: ":x: **Please enter a valid amount.**", ephemeral: true });

        const quoteEmbed = buildEmbed("quote").setAuthor({
            name: interaction.user.username,
            iconURL: interaction.user.displayAvatarURL()
        }).setFields([
            { name: "Amount", value: `$${amount}`, inline: true },
            { name: "Timeframe", value: timeframe, inline: true },
            { name: "Comment", value: comment || "None", inline: true },
            { name: "Portfolio", value: profile.portfolio, inline: true }
        ]);

        const quoteRow = new ActionRowBuilder<ButtonBuilder>().setComponents(
            buildButton("acceptQuote"),
            buildButton("declineQuote"),
            buildButton("messageQuote"),
            buildButton("counteroffer")
        );

        const { client } = await import("../index.js");

        const commissionChannel = await client.channels.fetch(commission.channel) as GuildTextBasedChannel;
        const msg = await commissionChannel.send({ content: `<@${commission.user}>`, embeds: [quoteEmbed], components: [quoteRow] });

        await interaction.reply({ content: ":white_check_mark: **Your quote has been sent.**", ephemeral: true });

        await database.manager.insert(Quote, {
            id: msg.id,
            commission: commission.channel,
            comment: comment,
            price: Number(amount),
            guild: interaction.guild.id,
            freelancer: interaction.user.id,
            timeframe: timeframe
        });
    }
}