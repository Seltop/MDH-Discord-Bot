import { EmbedBuilder, ModalSubmitInteraction } from "discord.js";

export default {
    id: "authortext",
    function: async function ({ interaction }: { interaction: ModalSubmitInteraction }) {
        const embed = new EmbedBuilder()
            .setTitle(interaction.message.embeds[0]?.title || null)
            .setColor(interaction.message.embeds[0]?.color || null)
            .setDescription(interaction.message.embeds[0]?.description || null)
            .setAuthor({ name: interaction.fields.getTextInputValue("authortext") == "N/A" ? null : interaction.fields.getTextInputValue("authortext") || null, iconURL: interaction.message.embeds[0]?.author?.iconURL || null })
            .setTimestamp(interaction.message.embeds[0]?.timestamp ? Date.now() : null)
            .setFooter({ text: interaction.message.embeds[0]?.footer?.text || null, iconURL: interaction.message.embeds[0]?.footer?.iconURL || null })
            .setThumbnail(interaction.message.embeds[0]?.thumbnail?.url || null)
            .setImage(interaction.message.embeds[0]?.image?.url || null);
        interaction.message.edit({ embeds: [embed] }).catch(() => { });
        interaction.reply({ content: "**Author Text has been set!**", ephemeral: true });
    }
}