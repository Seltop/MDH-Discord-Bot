import { ActionRowBuilder, ButtonBuilder, GuildTextBasedChannel, ModalSubmitInteraction } from "discord.js";
import config from "../config.js";
import Commission from "../tables/Commission.js";
import FreelancerReview from "../tables/FreelancerReview.js";
import Wallet from "../tables/Wallet.js";
import database from "../handlers/databaseHandler.js";
import { buildButton, buildEmbed } from "../utils/configBuilders.js";
import { error } from "../utils/logging.js";

export default {
    id: "review",
    function: async function ({ interaction }: { interaction: ModalSubmitInteraction }) {
        if (!interaction.inCachedGuild() || interaction.channel.isThread()) return;

        const freelancerStars = Number(interaction.fields.getTextInputValue("freelancerStars"));
        const freelancerReview = interaction.fields.getTextInputValue("freelancerReview") || "No comment was given.";

        if (isNaN(freelancerStars)) return interaction.reply({ content: `:x: **Stars must be a number!**`, ephemeral: true });
        if (freelancerStars > 5 || freelancerStars < 1) return interaction.reply({ content: `:x: **Freelancer Stars must be between 1 and 5!**`, ephemeral: true });

        const commission = await database.manager.findOne(Commission, { where: { channel: interaction.channel.id } });
        if (!commission) return interaction.reply({ content: `:x: **This commission doesn't exist!**`, ephemeral: true });

        const freelancer = await interaction.guild.members.fetch(commission.freelancer).catch(() => null);
        if (!freelancer) return interaction.reply({ content: `:x: **This freelancer doesn't exist!**`, ephemeral: true });

        await interaction.reply({ content: `:white_check_mark: **Your review has been sent!**`, ephemeral: true });

        const doneEmbed = buildEmbed("reviewComplete");

        await interaction.message.edit({ embeds: [doneEmbed], components: [] });

        const embed = buildEmbed("newReview").addFields([
            {
                name: "Freelancer",
                value: `<@${freelancer.id}>`
            },
            {
                name: "Client",
                value: `<@${commission.user}>`
            },
            {
                name: "Freelancer Stars",
                value: `**${freelancerStars}/5 ${"⭐".repeat(freelancerStars)}**`
            },
            {
                name: "Role(s)",
                value: JSON.parse(commission.roles).map(r => `<@&${r}>`).join(", ")
            },
            {
                name: "Freelancer Review",
                value: `\`\`\`${freelancerReview}\`\`\``
            }
        ]);

        const { client } = await import("../index.js");
        
        const reviewsChannel = await client.channels.fetch(config.commissions.reviewsChannel).catch(() => null) as GuildTextBasedChannel;
        if (!reviewsChannel) error("Reviews channel doesn't exist!");
      
        await reviewsChannel.send({ embeds: [embed] });

        await database.manager.insert(FreelancerReview, {
            user: freelancer.id,
            client: commission.user,
            rating: freelancerStars,
            comment: freelancerReview,
            commission: commission.channel,
            guild: interaction.guild.id
        });

        await interaction.channel.permissionOverwrites.edit(interaction.user.id, { ViewChannel: false });

        if (commission.paidAmount) {
            const paymentEmbed = buildEmbed("paymentComplete").addFields([
                {
                    name: "Freelancer",
                    value: `<@${freelancer.id}>`
                },
                {
                    name: "Amount",
                    value: `**$${(commission.paidAmount * config.wallet.freelancerCut).toFixed(2)}**`
                }
            ]);

            let wallet = await database.manager.findOne(Wallet, { where: { user: freelancer.id } });
            if (!wallet) {
                wallet = database.manager.create(Wallet, {
                    user: freelancer.id,
                    balance: 0,
                    transactions: "[]",
                    commissionsDone: 0,
                    amountMade: 0
                });
            }
            wallet.balance = Number((wallet.balance + commission.paidAmount * config.wallet.freelancerCut).toFixed(2));
            wallet.transactions = JSON.stringify([...JSON.parse(wallet.transactions), {
                type: `Commission - ${commission.channel}`,
                amount: (commission.paidAmount * config.wallet.freelancerCut).toFixed(2),
                date: Date.now(),
                added: true
            }]);
            wallet.commissionsDone++;
            wallet.amountMade = Number((wallet.amountMade + commission.paidAmount * config.wallet.freelancerCut).toFixed(2));

            await interaction.channel.send({ embeds: [paymentEmbed] });
            await interaction.user.send({ embeds: [paymentEmbed] });
            await database.manager.save(wallet);

            commission.paidToWallet = true;
            await database.manager.save(commission);
        }

        const showcaseRow = new ActionRowBuilder<ButtonBuilder>().addComponents(
            buildButton("showcaseAccept"),
            buildButton("showcaseDeny")
        )

        await interaction.channel.send({ content: `<@${freelancer.id}>`, embeds: [buildEmbed("askShowcase")], components: [showcaseRow] });
        await interaction.channel.setParent(config.commissions.completedCategory);
    }
}