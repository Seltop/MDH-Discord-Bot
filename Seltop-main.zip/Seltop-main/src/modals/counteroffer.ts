import { ActionRowBuilder, ModalSubmitInteraction } from "discord.js";
import Counteroffer from "../tables/Counteroffer.js";
import Quote from "../tables/Quote.js";
import database from "../handlers/databaseHandler.js";
import { buildButton, buildEmbed } from "../utils/configBuilders.js";

export default {
    id: "counteroffer",
    function: async function({ interaction }: { interaction: ModalSubmitInteraction }) {
        const counterofferInput = interaction.fields.getTextInputValue("counteroffer");

        const quote = await database.manager.findOne(Quote, { where: { id: interaction.message.id } });
        if (!quote) return interaction.reply({ content: ":x: ***This quote doesn't exist anymore.**", ephemeral: true });

        if (isNaN(Number(counterofferInput))) return interaction.reply({ content: ":x: ***Please enter a valid number.**", ephemeral: true });

        const freelancer = await interaction.guild.members.fetch(quote.freelancer).catch(() => null);
        if (!freelancer) return interaction.reply({ content: ":x: ***This freelancer doesn't exist anymore.**", ephemeral: true });

        const counterofferEmbed = buildEmbed("counteroffer")
            .setDescription(`**${interaction.user.tag}** has sent a counteroffer to **${freelancer.user.tag}**.`)
            .addFields([
                { name: "Commission", value: `#${interaction.channel.name}` },
                { name: "Price", value: `$${counterofferInput}` }
            ]);

        await interaction.reply({ content: "**Sent counter-offer.**", embeds: [counterofferEmbed] });

        const counterRow = new ActionRowBuilder().addComponents(
            buildButton("acceptCounter"),
            buildButton("declineCounter")
        );

        const msg = await freelancer.send({ embeds: [counterofferEmbed], components: [counterRow] });

        await database.manager.insert(Counteroffer, {
            id: msg.id,
            freelancer: quote.freelancer,
            guild: interaction.guild.id,
            commission: interaction.channel.id,
            price: Number(counterofferInput),
            msg: msg.id,
            quote: quote.id
        });
    }
}