import { ChannelType, GuildTextBasedChannel, ModalSubmitInteraction, PermissionsBitField } from "discord.js";
import config from "../config.js";
import { buildEmbed } from "../utils/configBuilders.js";
// import { Support } from "../database/schemas.js";
import Support from "../tables/Support.js";
import database from "../handlers/databaseHandler.js";

export default {
    id: "support",
    function: async function ({ interaction }: { interaction: ModalSubmitInteraction }) {
        const answers = [];

        for (let i = 0; i<5 ; i++) {
            const question = config.support.questions[i];
            if (!question) break;
            const answer = interaction.fields.getTextInputValue(`question-${i}`);

            answers.push({ question: question.question, answer: answer });
        }

        const fetchedCategories = [];

        const { client } = await import("../index.js");

        for (const category of config.support.categories) {
            const fetchedCategory = await client.channels.fetch(category);

            fetchedCategories.push(fetchedCategory);
        }

        let parent;

        for (const category of fetchedCategories) {
            if (category.children.cache.size < 50) {
                parent = category;
                break;
            }
        }

        const supportEmbed = buildEmbed("support");
        supportEmbed.setFields(answers.map(answer => {
            return { name: answer.question, value: answer.answer, inline: config.embeds.support.inline }
        }));

        const channel = await interaction.guild.channels.create({
            name: `support-${interaction.user.username}`,
            type: ChannelType.GuildText,
            parent: parent,
            permissionOverwrites: [
                {
                    id: interaction.user.id,
                    allow: [PermissionsBitField.Flags.ViewChannel, PermissionsBitField.Flags.SendMessages]
                },
                {
                    id: interaction.guild.roles.everyone.id,
                    deny: [PermissionsBitField.Flags.ViewChannel]
                },
                ...config.support.staffRoles.map(role => {
                    return {
                        id: role,
                        allow: [PermissionsBitField.Flags.ViewChannel, PermissionsBitField.Flags.SendMessages]
                    }
                })
            ]
        }).catch(async () => {
            return await interaction.reply({ content: ":x: **Failed to create a ticket.**", ephemeral: true });
        }) as GuildTextBasedChannel;

        if (!channel) return;

        await channel.send({ content: `<@${interaction.user.id}>${config.support.pingRoles.length ? ` ${config.support.pingRoles.map(r => `<@&${r}>`)}` : ""}`, embeds: [supportEmbed] });

        const openedEmbed = buildEmbed("ticketOpened");
        await interaction.reply({ content: channel.toString(), embeds: [openedEmbed], ephemeral: true });

        await database.manager.insert(Support, {
            user: interaction.user.id,
            channel: channel.id,
            guild: interaction.guild.id,
            added: "[]"
        });
    }
}