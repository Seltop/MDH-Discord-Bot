import { ActionRowBuilder, ButtonBuilder, ModalSubmitInteraction } from "discord.js";
import database from "../handlers/databaseHandler.js";
import Schedule from "../tables/Schedule.js";
import { buildButton } from "../utils/configBuilders.js";

export default {
    id: "scheduleMessage",
    function: async function({ interaction }: { interaction: ModalSubmitInteraction }) {
        const message = interaction.fields.getTextInputValue("scheduleMessage");
        
        await database.manager.insert(Schedule, {
            id: interaction.message.id,
            guild: interaction.guild.id,
            name: message,
            type: "message",
            message: message
        });

        await interaction.deferUpdate();

        const row = new ActionRowBuilder<ButtonBuilder>().addComponents(
            buildButton("scheduleEmbedDate")
        );

        await interaction.message.edit({ content: "**Great! Now let's select a time and date for this :)**", components: [row] })
    }
}