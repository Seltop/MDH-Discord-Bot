import { ModalSubmitInteraction } from "discord.js";
import Commission from "../tables/Commission.js";
import Quote from "../tables/Quote.js";
import database from "../handlers/databaseHandler.js";
import { buildEmbed } from "../utils/configBuilders.js";

export default {
    id: "declineQuote",
    function: async function ({ interaction }: { interaction: ModalSubmitInteraction }) {
        const quote = await database.manager.findOne(Quote, { where: { id: interaction.message.id } });
        if (!quote) return interaction.reply({ content: ":x: **This quote doesn't exist anymore.**", ephemeral: true });
        
        const commission = await database.manager.findOne(Commission, { where: { channel: quote.commission } });
        if (!commission) return interaction.reply({ content: ":x: **This commission doesn't exist anymore.**", ephemeral: true });

        const reason = interaction.fields.getTextInputValue("reason") || "No reason provided.";

        const quoteDeclinedDM = buildEmbed("quoteDeclinedDM").setFields([
            { name: "Reason", value: reason },
            { name: "Amount", value: `$${quote.price}`, inline: true },
            { name: "Timeframe", value: quote.timeframe || "None", inline: true },
            { name: "Comment", value: quote.comment || "None", inline: true }
        ]);

        const quoteDeclined = buildEmbed("quoteDeclinedTicket").setFields([
            { name: "Reason", value: reason },
            { name: "Amount", value: `$${quote.price}`, inline: true },
            { name: "Timeframe", value: quote.timeframe || "None", inline: true },
            { name: "Comment", value: quote.comment || "None", inline: true }
        ]);

        const freelancer = await interaction.guild.members.fetch(quote.freelancer);

        await interaction.reply({ content: ":white_check_mark: **The quote has been declined.**", embeds: [quoteDeclined], ephemeral: true });
        await freelancer.send({ embeds: [quoteDeclinedDM] }).catch(() => null);
        await interaction.message.delete();
    }
}