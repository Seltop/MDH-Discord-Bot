import { EmbedBuilder, ModalSubmitInteraction } from "discord.js";

export default {
    id: "footerimage",
    function: async function ({ interaction }: { interaction: ModalSubmitInteraction }) {
        const embed = new EmbedBuilder()
            .setTitle(interaction.message.embeds[0]?.title || null)
            .setColor(interaction.message.embeds[0]?.color || null)
            .setDescription(interaction.message.embeds[0]?.description || null)
            .setAuthor({ name: interaction.message.embeds[0]?.author?.name || null, iconURL: interaction.message.embeds[0]?.author?.iconURL || null })
            .setTimestamp(interaction.message.embeds[0]?.timestamp ? Date.now() : null)
            .setFooter({ text: interaction.message.embeds[0]?.footer?.text || null, iconURL: interaction.fields.getTextInputValue("footerimage") == "N/A" ? null : interaction.fields.getTextInputValue("footerimage") || null })
            .setThumbnail(interaction.message.embeds[0]?.thumbnail?.url || null)
            .setImage(interaction.message.embeds[0]?.image?.url || null);
        interaction.message.edit({ embeds: [embed] }).catch(() => { });
        interaction.reply({ content: "**Footer Image has been set!**", ephemeral: true });
    }
}