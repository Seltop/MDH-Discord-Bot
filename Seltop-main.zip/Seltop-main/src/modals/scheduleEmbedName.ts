import { ActionRowBuilder, ButtonBuilder, ModalSubmitInteraction } from "discord.js";
import database from "../handlers/databaseHandler.js";
import Embed from "../tables/Embed.js";
import Schedule from "../tables/Schedule.js";
import { buildButton } from "../utils/configBuilders.js";

export default {
    id: "scheduleEmbedName",
    function: async function({ interaction }: { interaction: ModalSubmitInteraction }) {
        const embedName = interaction.fields.getTextInputValue("scheduleEmbedName");
        const embed = await database.manager.findOne(Embed, { where: { name: embedName } });

        if (!embed) return interaction.reply({ content: ":x: **Could not find that embed.**", ephemeral: true });

        await database.manager.insert(Schedule, {
            id: interaction.message.id,
            guild: interaction.guild.id,
            name: embedName,
            type: "embed",
            embed: embed.name
        });

        await interaction.deferUpdate();

        const row = new ActionRowBuilder<ButtonBuilder>().addComponents(
            buildButton("scheduleEmbedDate")
        );

        await interaction.message.edit({ content: "**Great! Now let's select a time and date for this :)**", components: [row] })
    }
}