import { ChannelType, ModalSubmitInteraction, PermissionsBitField } from "discord.js";
import config from "../config.js";
import Application from "../tables/Application.js";
import database from "../handlers/databaseHandler.js";
import { buildEmbed } from "../utils/configBuilders.js";

export default {
    id: "staffapply",
    function: async function ({ interaction }: { interaction: ModalSubmitInteraction }) {
        const answers = [];

        for (let i = 0; i < 5; i++) {
            const question = config.staffQuestions[i];
            if (!question) break;
            const answer = interaction.fields.getTextInputValue(`question-${i}`)
            answers.push({ question: question.question, answer: answer });
        }

        let application;
        const applications = await database.manager.find(Application, { where: { user: interaction.user.id, guild: interaction.guild.id, status: "answering" } });

        for (const app of applications) {
            if (!application) application = app;
            if (app.createdAt > application.createdAt) application = app;
        }

        if (!application) return await interaction.reply({ content: ":x: **You don't have an application in progress.**", ephemeral: true });

        const departments = [];

        for (const department of config.staffDepartments) {
            for (const role of application.roles) {
                if (department.specialties.filter((specialty) => specialty.id === role).length > 0) {
                    departments.push(department);
                }
            }
        }

        const channel = await interaction.guild.channels.create({
            name: `application-${interaction.user.username}`,
            type: ChannelType.GuildText,
            parent: departments[0].category,
            permissionOverwrites: [
                {
                    id: interaction.guild.roles.everyone.id,
                    deny: [PermissionsBitField.Flags.ViewChannel]
                },
                {
                    id: interaction.user.id,
                    allow: [PermissionsBitField.Flags.ViewChannel]
                },
                {
                    id: config.roles.applicationReviewers,
                    allow: [PermissionsBitField.Flags.ViewChannel]
                }
            ],
            topic: `Application for ${interaction.user.username}#${interaction.user.discriminator}`
        });

        const applicationCreatedEmbed = buildEmbed("applicationCreated");

        await interaction.reply({ content: `<#${channel.id}>`, embeds: [applicationCreatedEmbed], ephemeral: true });

        const applicationEmbed = buildEmbed("applicationSent")
            .setFields(
                {
                    name: "Roles",
                    value: application.roles.map(role => `<@&${role}>`).join(", ")
                },
                ...answers.map(answer => {
                    return {
                        name: answer.question,
                        value: answer.answer
                    }
                })
            );

        await channel.send({ embeds: [applicationEmbed] });

        application.answers = answers;
        application.channel = channel.id;
        application.status = "pending";

        await application.save();
    }
}
