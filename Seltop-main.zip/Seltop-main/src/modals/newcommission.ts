import { ActionRowBuilder, ButtonBuilder, ChannelType, GuildTextBasedChannel, ModalSubmitInteraction, PermissionsBitField } from "discord.js";
import config from "../config.js";
import Commission from "../tables/Commission.js";
import database from "../handlers/databaseHandler.js";
import { buildButton, buildEmbed } from "../utils/configBuilders.js";

export default {
    id: "newcommission",
    function: async function ({ interaction }: { interaction: ModalSubmitInteraction }) {

        let commission;
        const commissions = await database.manager.find(Commission, { where: { user: interaction.user.id, guild: interaction.guild.id, status: "answering" } });

        for (const comm of commissions) {
            if (!commission) commission = comm;
            if (comm.createdAt > commission.createdAt) commission = comm;
        }

        if (!commission) return interaction.reply({ content: ":x: **This commission doesn't exist.**", ephemeral: true });
        
        const departments = [];

        for (const department of config.departments) {
            for (const role of commission.roles) {
                if (department.specialties.filter((specialty) => specialty.id === role).length > 0) {
                    departments.push(department);
                }
            }
        }

        const rolesFromDepartments = [];

        rolesFromDepartments.push(...departments[0].specialties.filter((specialty) => commission.roles.includes(specialty.id)));

        const answers = [];

        const specialty = departments[0].specialties.filter((specialty) => commission.roles.includes(specialty.id))[0];

        const questions = specialty.questions || departments[0].questions;

        for (let i = 0; i < 5; i++) {
            const question = questions[i];
            if (!question) break;
            const answer = interaction.fields.getTextInputValue(`question-${i}`) || "No answer provided.";
            answers.push({ question: question.question, answer: answer });
        }
        
        commission.answers = answers;
        commission.status = "pending";

        await commission.save();

        const { client } = await import("../index.js");

        const channel = await interaction.guild.channels.create({
            name: `order-${interaction.user.username}`,
            type: ChannelType.GuildText,
            parent: departments[0].category,
            permissionOverwrites: [
                {
                    id: interaction.guild.roles.everyone.id,
                    deny: [PermissionsBitField.Flags.ViewChannel]
                },
                {
                    id: interaction.user.id,
                    allow: [PermissionsBitField.Flags.ViewChannel]
                },
                ...config.commissions.staffRoles.map((role) => ({ id: role, allow: [PermissionsBitField.Flags.ViewChannel] }))
            ],
            topic: `Commission for ${interaction.user.username}#${interaction.user.discriminator}`
        });

        commission.channel = channel.id;

        await commission.save();

        const commissionCreated = buildEmbed("commissionCreated");

        await interaction.reply({ content: `<#${channel.id}>`, embeds: [commissionCreated], ephemeral: true });

        const commissionEmbed = buildEmbed("commission").setFields([
            { name: "Roles", value: commission.roles.map((role) => `<@&${role}>`).join(", ") },
            ...commission.answers.map((answer) => ({ name: answer.question, value: answer.answer }))
        ]);

        await channel.send({ content: `<@${interaction.user.id}>`, embeds: [commissionEmbed] });

        const specialties = departments[0].specialties.filter((specialty) => commission.roles.includes(specialty.id));
        const freelancersChannel = await client.channels.fetch(specialties[0].commissionsChannel || departments[0].freelancerChannel) as GuildTextBasedChannel;
        
        const freelancerEmbed = buildEmbed("newCommissionFreelancers").setFields([
            { name: "Roles", value: commission.roles.map((role) => `<@&${role}>`).join(", ") },
            ...commission.answers.map((answer) => ({ name: answer.question, value: answer.answer }))
        ]);

        const freelancerRow = new ActionRowBuilder<ButtonBuilder>().addComponents(
            buildButton("quote"),
            buildButton("toggleNotifications"),
            buildButton("messagefreelancer"),
            buildButton("vcfreelancer")
        );

        const freelancerMessage = await freelancersChannel.send({ content: `<@&${rolesFromDepartments.map(r => r.id).join("> <@&")}>`, embeds: [freelancerEmbed], components: [freelancerRow] });

        // create a thread with the freelancermessage
        const thread = await freelancerMessage.startThread({
            name: `quote-${interaction.user.username}`,
            autoArchiveDuration: 1440,
            reason: "Commission thread"
        });

        commission.freelancersMessage = freelancerMessage.id;
        // commission.cmMessage = commissionManagerMessage.id;
        commission.thread = thread.id;
        commission.freelancersChannel = freelancersChannel.id;

        await commission.save();
    }
}
