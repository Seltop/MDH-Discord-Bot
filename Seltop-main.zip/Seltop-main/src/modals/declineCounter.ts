import { GuildTextBasedChannel, ModalSubmitInteraction } from "discord.js";
import Commission from "../tables/Commission.js";
import Counteroffer from "../tables/Counteroffer.js";
import database from "../handlers/databaseHandler.js";
import { buildEmbed } from "../utils/configBuilders.js";

export default {
    id: "declineCounter",
    function: async function ({ interaction }: { interaction: ModalSubmitInteraction }) {
        const counteroffer = await database.manager.findOne(Counteroffer, { where: { id: interaction.message.id } });
        if (!counteroffer) return interaction.reply({ content: ":x: **This quote doesn't exist anymore.**", ephemeral: true });
        
        const commission = await database.manager.findOne(Commission, { where: { channel: counteroffer.commission } });
        if (!commission) return interaction.reply({ content: ":x: **This commission doesn't exist anymore.**", ephemeral: true });

        const reason = interaction.fields.getTextInputValue("reason") || "No reason provided.";

        const counterDeclined = buildEmbed("counterofferDeclined").setFields([
            { name: "Reason", value: reason },
            { name: "Amount", value: `$${counteroffer.price}`, inline: true }
        ]);

        await interaction.reply({ content: ":white_check_mark: **The counteroffer has been declined.**", ephemeral: true });
        await interaction.message.edit({ embeds: [counterDeclined], components: [] });

        const { client } = await import("../index.js");

        const commissionChannel = await client.channels.fetch(commission.channel).catch(() => null) as GuildTextBasedChannel;
        if (!commissionChannel) return;

        await commissionChannel.send({ content: `:x: **The counteroffer has been declined.**`, embeds: [counterDeclined] });
    }
}