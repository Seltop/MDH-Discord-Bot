import { ActionRowBuilder, ChannelSelectMenuBuilder, ChannelType, ModalSubmitInteraction } from "discord.js";
import database from "../handlers/databaseHandler.js";
import Schedule from "../tables/Schedule.js";

export default {
    id: "scheduleEmbedDate",
    function: async function({ interaction }: { interaction: ModalSubmitInteraction }) {
        const schedule = await database.manager.findOne(Schedule, { where: { id: interaction.message.id } });
        if (!schedule) return interaction.reply({ content: ":x: **Could not find that schedule.**", ephemeral: true });

        const inputDate = interaction.fields.getTextInputValue("scheduleEmbedDate");
        const inputTime = interaction.fields.getTextInputValue("scheduleEmbedTime");
        const inputUTC = interaction.fields.getTextInputValue("scheduleEmbedUTC");

        const dateRegex = /(?<year>\d{4})-(?<month>\d{1,2})-(?<day>\d{1,2})/g;
        const timeRegex = /(?<hour>\d{1,2}):(?<minute>\d{1,2})/g;
        const utcRegex = /(?<offset>[+-]\d{1,2})/g;

        const dateMatch = dateRegex.exec(inputDate);
        const timeMatch = timeRegex.exec(inputTime);
        const utcMatch = utcRegex.exec(inputUTC);
        const utcNumber = parseInt(utcMatch?.groups.offset);
        const utcPorN = utcMatch.groups.offset[0];

        if (!dateMatch || !timeMatch || !utcMatch) return interaction.reply({ content: ":x: **Invalid date, please make sure to follow this format:**\n**Date:** \`YYYY-MM-DD\`\n**Time:** \`HH:MM\`\n**UTC Offset:** \`+0\`", ephemeral: true });

        const { year, month, day } = dateMatch.groups
        const { hour, minute } = timeMatch.groups

        const formattedDate = `${year}-${month.padStart(2, "0")}-${day.padStart(2, "0")}T${hour.padStart(2, "0")}:${minute.padStart(2, "0")}:00${utcPorN}${utcNumber.toString().padStart(2, "0").padEnd(4, "0")}`;

        // const formattedDate = `${dateMatch.groups.year}-${dateMatch.groups.month.padStart(2, "0")}-${dateMatch.groups.day.padStart(2, "0")}T${timeMatch.groups.hour.padStart(2, "0")}:${timeMatch.groups.minute.padStart(2, "0")}:00${utcPorN}${utcNumber.toString().padStart(2, "0").padEnd(4, "0")}`;

        const date = new Date(formattedDate);
        if (isNaN(date.getTime())) return interaction.reply({ content: `**The date you have entered is invalid, please double check your input.\n\nDate:** \`${formattedDate}\`**\n\nIf you are sure that the date is correct, please contact the bot developer.**`, ephemeral: true });
        if (date.getTime() < Date.now()) return interaction.reply({ content: ":x: **The date you have entered is in the past, please enter a future date.**", ephemeral: true });

        schedule.date = date.getTime();
        schedule.lastModified = Date.now();
        await database.manager.save(schedule);

        await interaction.reply({ content: `:white_check_mark: **Date set to <t:${Math.round(date.getTime() / 1000)}>, now let's choose a channel!**`, ephemeral: true });

        const row = new ActionRowBuilder<ChannelSelectMenuBuilder>().addComponents(
            new ChannelSelectMenuBuilder().setCustomId("scheduleEmbedChannel").setPlaceholder("Select a channel").setChannelTypes(ChannelType.GuildText)
        );

        await interaction.message.edit({ content: `**Choose a channel to send the embed to.**`, components: [row] });
    }
}