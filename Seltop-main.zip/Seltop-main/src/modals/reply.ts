import { ActionRowBuilder, ModalSubmitInteraction } from "discord.js";
import Commission from "../tables/Commission.js";
import Message from "../tables/Message.js";
import Notifications from "../tables/Notifications.js";
import database from "../handlers/databaseHandler.js";
import { buildButton, buildEmbed } from "../utils/configBuilders.js";

export default {
    id: "reply",
    function: async function ({ interaction }: { interaction: ModalSubmitInteraction }) {
        const { client } = await import("../index.js");
        
        const response = interaction.fields.getTextInputValue("reply");
        
        const msgDB = await database.manager.findOne(Message, { where: { id: interaction.message.id } });
        if (!msgDB) return interaction.reply({ content: ":x: **This message doesn't exist.**", ephemeral: true });

        let src;

        if (msgDB.guild) src = await client.channels.fetch(msgDB.source).catch(() => null);
        else src = await client.users.fetch(msgDB.source).catch(() => null);

        if (!src) return interaction.reply({ content: ":x: **This sender no longer exists.**", ephemeral: true });

        const commission = await database.manager.findOne(Commission, { where: { channel: msgDB.destination } });

        if (!commission) return interaction.reply({ content: ":x: **This commission no longer exists.**", ephemeral: true });

        const embed = buildEmbed("message")
            .setDescription(`\`\`\`${msgDB.message}\`\`\`\n\`\`\`${response}\`\`\``)
            .setAuthor({ name: interaction.user.username, iconURL: interaction.user.avatarURL() });

        const replyRow = new ActionRowBuilder().addComponents(
            buildButton("reply")
        );

        const msg = await src.send({ content: commission ? `<@${commission.user}>` : null, embeds: [embed], components: [replyRow] });
        await interaction.reply({ content: ":white_check_mark: **Message sent.**", embeds: [embed] });
        
        await database.manager.insert(Message, {
            id: msg.id,
            source: msgDB.destination,
            destination: msgDB.source,
            guild: interaction.guild?.id || null,
            message: response,
            threadChannel: msgDB.threadChannel || null
        });

        if (msgDB.threadChannel) {
            const channel = await client.channels.fetch(JSON.parse(msgDB.threadChannel).channel).catch(() => null);
            if (!channel) return;
            
            const thread = await channel.threads.fetch(JSON.parse(msgDB.threadChannel).thread).catch(() => null);
            if (!thread) return;

            await thread.send({ embeds: [embed] });
        }

        await database.manager.find(Notifications, { where: { commission: commission.id } }).then(async notifications => {
            for (const notification of notifications) {
                const user = await interaction.guild.members.fetch(notification.user).catch(() => null);
                if (!user) continue;

                await user.send({ content: `:bell: **A new message has been posted in <#${commission.thread}>**`, embeds: [embed] }).catch(() => null);
            }
        });
    }
}