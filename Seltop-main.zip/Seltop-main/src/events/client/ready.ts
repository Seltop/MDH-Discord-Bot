import config from "../../config.js";
import colors from "colors";
import path from "path";
import { fileURLToPath } from 'url';
import { log, error } from "../../utils/logging.js";
import { client } from "../../index.js";
import { readdirSync, statSync } from "fs";
import { REST } from "@discordjs/rest";
import { Routes } from "discord-api-types/v10";
import { convertURLs } from "../../utils/windowsUrlConvertor.js";
import { getYouTubeChannelName, youtube } from "../../utils/youtube.js";
import database from "../../handlers/databaseHandler.js";
import Subscription from "../../tables/Subscription.js";
import { ColorResolvable, EmbedBuilder, GuildTextBasedChannel, ChannelType, VoiceChannel, Guild, ActionRowBuilder, StringSelectMenuBuilder, StringSelectMenuOptionBuilder } from "discord.js";
import Schedule from "../../tables/Schedule.js";
import Embed from "../../tables/Embed.js";
import { endGiveaway } from "../../utils/giveaway.js";
import Giveaway from "../../tables/giveaway.js";
import Invoice from "../../tables/Invoice.js";
import Commission from "../../tables/Commission.js";
import { buildEmbed } from "../../utils/configBuilders.js";
import ClientProfile from "../../tables/ClientProfile.js";
import { stripe } from "../../handlers/stripeHandler.js";
import { addXP } from "../../utils/levelling.js";
import Competition from "../../tables/Competition.js";
import Submission from "../../tables/Submission.js";
import Vote from "../../tables/Vote.js";
import PublicVoting from "../../tables/PublicVoting.js";
import PublicVote from "../../tables/PublicVote.js";
import { endCompetition } from "../../utils/endCompetition.js";

interface Command {
	name: string;
	description: string;
	type?: number;
	options: any[]; // You can replace "any" with the correct type for options
}

export default {
	name: "ready",
	description: "client ready event",
	once: false,
	function: async function () {
		log(`Logged in as ${colors.red(client.user!.tag)}`);

		const __filename = fileURLToPath(import.meta.url);
		const __dirname = path.dirname(__filename);

		const commands: Command[] = [];

		const registerDir = async (dirName: string) => {
			const COMMAND_DIR = path.resolve(__dirname, `../../${dirName}`);
			const readDir = async (dir: string) => {
				const files = readdirSync(dir);
				for await (const file of files) {
					if (statSync(`${dir}/${file}`).isDirectory()) await readDir(`${dir}/${file}`);
					else {
						const fileToImport = process.platform === "win32" ? `${convertURLs(dir)}/${file}` : `${dir}/${file}`;
						const command = (await import(fileToImport)).default;
						if (command?.name) {
							commands.push({
								name: command.name,
								type: command.type,
								description: command.description || null,
								options: command.options || null
							});
							log(`${dir}/${file} has been registered!`);
						} else {
							error(`${dir}/${file} has no name!`);
						}
					}
				}
			};
			await readDir(COMMAND_DIR);
		};

		await registerDir("slashCommands");
		await registerDir("contextMenus");

		const rest = new REST({ version: '10' }).setToken(config.token);
		rest
			.put(Routes.applicationCommands(client.user!.id), { body: commands })
			.then(() => log('Commands have been registered successfully!'))
			.catch((err) => console.log(err));

		const checkYouTube = async () => {
			const youtubers = await database.manager.find(Subscription, { where: { platform: "youtube" } });

			for (const youtuber of youtubers) {
				const videos = await youtube.search.list({
				// @ts-ignore
					channelId: youtuber.user,
					part: "snippet",
					maxResults: 1,
					order: "date",
					type: "video",
				});

				// @ts-ignore
				if (videos.data.items.length === 0) {
					continue;
				}

				// @ts-ignore
				const videoId = videos.data.items[0].id.videoId;
				if (youtuber.lastVideo === videoId) {
					continue;
				}

				await database.manager.update(Subscription, { user: youtuber.user }, { lastVideo: videoId });
				const channelTitle = await getYouTubeChannelName(youtuber.user);
				const videoUrl = `https://youtube.com/watch?v=${videoId}`;
				const message = `:red_circle: **${channelTitle} just uploaded a new video!**\n${videoUrl}`;

				const channel = await client.channels.fetch(config.youtube.channel) as GuildTextBasedChannel;
				await channel.send({ content: message });
			}
		};

		checkYouTube();
		setInterval(checkYouTube, config.youtube.interval);

		const checkScheduledPosts = async () => {
			const schedules = await database.manager.find(Schedule);

			for (const schedule of schedules) {
				if (schedule.active) {
					if (schedule.type === "message") {
						const channel = await client.channels.fetch(schedule.channel).catch(() => null) as GuildTextBasedChannel;
						if (channel) await channel.send({ content: schedule.message });
					} else if (schedule.type === "embed") {
						const channel = await client.channels.fetch(schedule.channel).catch(() => null) as GuildTextBasedChannel;
						const savedEmbed = await database.manager.findOne(Embed, { where: { name: schedule.embed, guild: schedule.guild } });
						if (!savedEmbed) continue;

						const embed = new EmbedBuilder()
							.setTitle(savedEmbed.title)
							.setDescription(savedEmbed.description)
							.setColor(savedEmbed.color as ColorResolvable)
							.setFooter({ text: savedEmbed.footerText, iconURL: savedEmbed.footerImage })
							.setThumbnail(savedEmbed.thumbnail)
							.setImage(savedEmbed.largeImage)
							.setAuthor({ name: savedEmbed.authorText, iconURL: savedEmbed.authorImage });
						if (savedEmbed.timestamp) embed.setTimestamp();

						if(channel) await channel.send({ embeds: [embed] });
					}

					await database.manager.update(Schedule, { id: schedule.id }, { active: false });
				}
			}
		};

		checkScheduledPosts();
		setInterval(checkScheduledPosts, 60000);

		setInterval(async () => {
			const giveaways = await database.manager.find(Giveaway, { where: { ended: false } });
			giveaways.forEach(async (giveaway) => {
				if (giveaway.endsAt <= new Date().getTime()) {
					await endGiveaway({ giveaway: giveaway });
				}
			});
		}, 5000);

		const checkInvoices = async () => {
			const paypalInvoices = await database.manager.find(Invoice, { where: { type: "paypal" } });
			for await (const i of paypalInvoices) {
				const invoice = await client.paypal.getInvoiceByID(i.id).catch(() => null);
				if (!invoice) continue;
				if (i.status === invoice.status) continue;
				i.status = invoice.status;
				await database.manager.save(i);
				const channel = await client.channels.fetch(i.channel).catch(() => null) as GuildTextBasedChannel;
				if (!channel) continue;
				const message = await channel.messages.fetch(i.message);
				if (!message) continue;
				const embed = buildEmbed("invoicecreated").setFields([
					{ name: "Status", value: `\`${invoice.status}\``, inline: true },
					{ name: "ID", value: `\`${invoice.id}\``, inline: true },
					{ name: "Invoice Number", value: `\`#${invoice.detail.invoice_number}\``, inline: true },
					{ name: "Breakdown", value: `Product: \`$${i.amount}\`\nFees: \`$${i.fees}\`\nTotal: \`$${i.total}\``, inline: true },
					{ name: "PayPal Invoice", value: `[Click Here](${invoice.detail.metadata.recipient_view_url})`, inline: true }
				]);

				await message.edit({ content: null, embeds: [embed] });
				if (invoice.status === "PAID") {
					const commission = await database.manager.findOne(Commission, { where: { channel: i.channel } });
					if (!commission) continue;
					const embed = buildEmbed("invoicePaid")
					if (!commission.paidAmount) commission.paidAmount = 0;
					commission.paidAmount += i.amount;
					await database.manager.save(commission);
					await message.channel.send({ content: `**${commission.freelancer ? `<@${commission.freelancer}> ` : ""}Invoice status has been updated to \`${invoice.status}\`**`, embeds: [embed] });

					const guild = await client.guilds.fetch(commission.guild).catch(() => null);
					if (!guild) continue;

					const member = await guild.members.fetch(commission.user).catch(() => null);
					if (!member) continue;

					member.roles?.add(config.roles.client).catch(() => null);

					let clientProfile = await database.manager.findOne(ClientProfile, { where: { user: commission.user } });
					if (!clientProfile) clientProfile = database.manager.create(ClientProfile, { user: commission.user, pastTickets: "[]", totalSpent: 0 });
					
					clientProfile.totalSpent += i.amount;
					await database.manager.save(clientProfile);

					const clientMember = await channel.guild.members.fetch(commission.user);
					if (clientMember) {
						for await (const rank of config.clientRanks) {
							const role = channel.guild.roles.cache.get(rank.roleId);
							if (role && clientMember.roles.cache.has(role.id)) {
								await clientMember.roles.remove(role);
							}
						}

						// loop through config.clientRanks and find the highest one they can get and give it to them, it's mapped like this [{ roleId: "id", amount: 1000 }]
						let highestRole = null;

						for (let i = 0; i < config.clientRanks.length; i++) {
							const rank = config.clientRanks[i];
							if (clientProfile.totalSpent >= rank.amountRequired) {
								highestRole = rank;
							} else {
								// Since the array is sorted in ascending order of amountRequired,
								// we can break the loop if the client's amountSpent is less than the current rank
								break;
							}
						}

						if (highestRole) {
							const role = channel.guild.roles.cache.get(highestRole.roleId);
							if (role) {
								clientMember.roles.add(role);
							}
						}
					}
				}
			}

			const stripeInvoices = await database.manager.find(Invoice, { where: { type: "stripe" } });

			for await (const i of stripeInvoices) {
				const invoice = await stripe.invoices.retrieve(i.id);
				if (!invoice) continue;
				if (!invoice.paid) continue;
				if (invoice.paid && i.status === "PAID") continue;

				i.status = "PAID";
				await database.manager.save(i);

				const channel = await client.channels.fetch(i.channel) as GuildTextBasedChannel;
				if (!channel) continue;

				const message = await channel.messages.fetch(i.message);
				if (!message) continue;

				const embed = buildEmbed("invoicecreated").setFields([
					{ name: "Status", value: `\`${invoice.status}\``, inline: true },
					{ name: "ID", value: `\`${invoice.id}\``, inline: true },
					{ name: "Invoice Number", value: `\`#${invoice.number}\``, inline: true },
					{ name: "Breakdown", value: `Product: \`$${i.amount}\`\nFees: \`$${i.fees}\`\nTotal: \`$${i.total}\``, inline: true },
					{ name: "Stripe Invoice", value: `[Click Here](${i.link})`, inline: true }
				]);

				await message.edit({ content: null, embeds: [embed], components: [] });

				const commission = await database.manager.findOne(Commission, { where: { channel: i.channel } });
				if (!commission) continue;

				const paidEmbed = buildEmbed("invoicePaid");
				if (!commission.paidAmount) commission.paidAmount = 0;
				commission.paidAmount += i.amount;
				await database.manager.save(commission);

				let clientProfile = await database.manager.findOne(ClientProfile, { where: { user: commission.user } });
				if (!clientProfile) clientProfile = database.manager.create(ClientProfile, { user: commission.user, pastTickets: "[]", totalSpent: 0 });
				
				clientProfile.totalSpent += i.amount;
				await database.manager.save(clientProfile);

				const clientMember = await channel.guild.members.fetch(commission.user);
				if (clientMember) {
					for await (const rank of config.clientRanks) {
						const role = channel.guild.roles.cache.get(rank.roleId);
						if (role && clientMember.roles.cache.has(role.id)) {
							await clientMember.roles.remove(role);
						}
					}

					// loop through config.clientRanks and find the highest one they can get and give it to them, it's mapped like this [{ roleId: "id", amount: 1000 }]
					let highestRole = null;

					for (let i = 0; i < config.clientRanks.length; i++) {
						const rank = config.clientRanks[i];
						if (clientProfile.totalSpent >= rank.amountRequired) {
							highestRole = rank;
						} else {
							// Since the array is sorted in ascending order of amountRequired,
							// we can break the loop if the client's amountSpent is less than the current rank
							break;
						}
					}

					if (highestRole) {
						const role = channel.guild.roles.cache.get(highestRole.roleId);
						if (role) {
							clientMember.roles.add(role);
						}
					}
				}

				await message.reply({ content: `**${commission.freelancer ? `<@${commission.freelancer}> ` : ""}Invoice status has been updated to \`${invoice.status}\`**`, embeds: [paidEmbed] });

				const member = await channel.guild.members.fetch(commission.user);
				if (!member) continue;
				member.roles.add(config.roles.client);
			}
		};

		await checkInvoices();

		setInterval(async () => {
			await checkInvoices();
		}, 10000);

		const checkVCLevels = async () => {
			const guild: Guild = await client.guilds.fetch(config.guildId).catch(() => null);
			if (!guild) return;

			const allChannels = await guild.channels.fetch();
			const channels = allChannels.filter((c) => c.type === ChannelType.GuildVoice);

			channels.forEach(async (channel: VoiceChannel) => {
				channel.members.forEach(async (member) => {
					if (member.voice.selfDeaf || member.voice.selfMute) return;
					const xp = Math.floor(Math.random() * 10) + 15;
					await addXP(member.id, guild.id, xp, false, true);
				});
			})
		}

		await checkVCLevels();
		setInterval(checkVCLevels, 60000);

		const checkCompetitions = async () => {
			const openComps = await database.manager.find(Competition, { where: { submissionsOpen: true } });

			for await (const competition of openComps) {
				if (competition.judgingStartDate > Date.now()) continue
				competition.submissionsOpen = false;
				await database.manager.save(competition);

				const channel = await client.channels.fetch(competition.channel) as GuildTextBasedChannel;
				const message = await channel.messages.fetch(competition.message).catch(() => null);

				if (message) await message.edit({ content: ":x: **Submissions are now closed for this competition.**", components: [] });

				const submissionsChannel = await client.channels.fetch(config.channels.submissions) as GuildTextBasedChannel;

				await submissionsChannel.send({ content: `:tada: **Submissions are now closed for the competition \`${competition.name}\`!**\n**The judgement process can now begin!**\n**Judement time ends on <t:${Math.round(competition.judgingEndDate / 1000)}> (<t:${Math.round(competition.judgingEndDate / 1000)}:R>)**\n<@&${config.roles.competitionJudges}>` });
			}

			const closedComps = await database.manager.find(Competition, { where: { submissionsOpen: false } });

			
			for await (const competition of closedComps) {
				if (competition.completed) continue;
				if (competition.judgingEndDate > Date.now()) continue;

				const scores = [];

				const submissions = await database.manager.find(Submission, { where: { competition: competition.id } });

				for await (const submission of submissions) {
					const votes = await database.manager.find(Vote, { where: { submission: submission.id } });
					const voteAmounts = votes.map(vote => vote.amount);
					const totalVotes = voteAmounts.reduce((a, b) => a + b);
					const averageVotes = totalVotes / votes.length;

					scores.push({ submission: submission.id, score: averageVotes });
				}

				scores.sort((a, b) => b.score - a.score);
	
				const winner = scores[0];
				const tied = scores.filter((s) => s.score === winner.score);

				if (tied.length > 1) {
					const alreadyVoted = await database.manager.findOne(PublicVoting, { where: { competition: competition.id } });
					if (alreadyVoted) continue;

					const voteDeadline = Date.now() + 86400000;

					const publicVotingEmbed = buildEmbed("publicVote")
						.setTitle(competition.name)
						.setDescription(`There was a tie between ${tied.length} submissions! Please vote for the submission you think should win!`)
						.addFields([
							{ name: "Time remaining", value: `<t:${Math.round(voteDeadline / 1000)}> (<t:${Math.round(voteDeadline / 1000)}:R>)` }
						]);

					const publicVotingRow = new ActionRowBuilder<StringSelectMenuBuilder>().addComponents(
						new StringSelectMenuBuilder()
							.setCustomId("publicVote")
							.setPlaceholder("Select a submission")
							.addOptions(tied.map((t) => new StringSelectMenuOptionBuilder().setLabel(`Vote for the submission ID: ${t.submission} - Votes: 0`).setValue(t.submission.toString())))
					);

					const tiesChannel = await client.channels.fetch(config.channels.ties) as GuildTextBasedChannel;

					const publicVotingMessage = await tiesChannel.send({ embeds: [publicVotingEmbed], components: [publicVotingRow] });

					const submissionsChannel = await client.channels.fetch(config.channels.submissions) as GuildTextBasedChannel;
					
					for (const submission of submissions) {
						const message = await submissionsChannel.messages.fetch(submission.message);
					
						const embed = message.embeds[0];
						if (!embed) continue;

						await tiesChannel.send({ content: `**Submission ID:** ${submission.id}`, embeds: [embed] });
					}

					await database.manager.insert(PublicVoting, {
						competition: competition.id,
						message: publicVotingMessage.id,
						channel: publicVotingMessage.channel.id,
						endsAt: voteDeadline
					});
				} else {
					const sortedScores = scores.sort((a, b) => b.score - a.score);
					await endCompetition(competition, sortedScores);
				}
			}

			const publicVotes = await database.manager.find(PublicVoting);

			for (const vote of publicVotes) {
				if (vote.endsAt > Date.now()) continue;

				const publicVotes = await database.manager.find(PublicVote, { where: { competition: vote.competition } });
				const submissions = await database.manager.find(Submission, { where: { competition: vote.competition } });

				const voteCounts = submissions.map((s) => {
					const votes = publicVotes.filter((v) => v.submission === s.id);
					return { submission: s.id, votes: votes.length };
				});

				const channel = await client.channels.fetch(vote.channel) as GuildTextBasedChannel;
				const message = await channel.messages.fetch(vote.message);

				await message.edit({ content: ":x: **Public voting has ended!**", components: [] });
				await channel.send({ content: `:tada: **Public voting has ended**\n**Votes:\n${voteCounts.map((v) => `Submission ID: ${v.submission} - Votes: ${v.votes}`).join("\n")}**` }); 

				const competition = await database.manager.findOne(Competition, { where: { id: vote.competition } });
				if (competition.completed) {
					await database.manager.delete(PublicVoting, { competition: vote.competition });
					continue;
				}
				
				const scores = [];

				for await (const submission of submissions) {
					const votes = await database.manager.find(Vote, { where: { submission: submission.id } });
					const voteAmounts = votes.map(vote => vote.amount);
					const totalVotes = voteAmounts.reduce((a, b) => a + b);
					const averageVotes = totalVotes / votes.length;

					const publicV = publicVotes.filter((v) => v.submission == submission.id)?.length || 0;

					scores.push({ submission: submission.id, score: averageVotes, public: publicV });
				}

				const sortedScores = scores.sort((a, b) => {
					if (a.public > b.public) return -1;
					if (a.public < b.public) return 1;
					if (a.score > b.score) return -1;
					if (a.score < b.score) return 1;
					return 0;
				});

				await endCompetition(competition, sortedScores);
				await database.manager.delete(PublicVoting, { competition: vote.competition });
			}
		};

		await checkCompetitions();
		setInterval(checkCompetitions, 60000);
	},
} as any;
