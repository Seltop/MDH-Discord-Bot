import { Message } from "discord.js";
import { addXP } from "../../utils/levelling.js";

export default {
    name: "messageCreate",
    once: false,
    function: async function(message: Message) {
        if (message.author.bot) return;
        if (!message.guild) return;

        const xp = Math.floor(Math.random() * 10) + 15;
        await addXP(message.author.id, message.guild.id, xp, true, false)
    }
}