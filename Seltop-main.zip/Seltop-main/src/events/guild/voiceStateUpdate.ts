import { VoiceState } from "discord.js";
import Commission from "../../tables/Commission.js";
import VC from "../../tables/VC.js";
import database from "../../handlers/databaseHandler.js";
import { buildEmbed } from "../../utils/configBuilders.js";

export default {
    name: "voiceStateUpdate",
    once: false,
    function: async function (oldState: VoiceState, newState: VoiceState) {
        if (!oldState) return;
        if (oldState.channelId === newState.channelId) return;

        const vcDB = await database.manager.findOne(VC, { where: { channel: oldState.channelId } });
        if (!vcDB) return;

        const { client } = await import("../../index.js");

        const vcChannel = await client.channels.fetch(oldState.channelId).catch(() => null);
        if (!vcChannel) return;

        if (vcChannel.members.size === 0) {
            await vcChannel.delete();

            const commission = await database.manager.findOne(Commission, { where: { channel: vcDB.commission } });
            if (commission) {
                const voiceDeletedEmbed = buildEmbed("voiceDeleted");

                const channel = await client.channels.fetch(commission.channel).catch(() => null);

                await channel.send({ embeds: [voiceDeletedEmbed] });

                const guild = await client.guilds.fetch(commission.guild).catch(() => null);
                if (!guild) return;

                const freelancer = await guild.members.fetch(vcDB.user).catch(() => null);

                if (freelancer) {
                    const voiceDeletedDMEmbed = buildEmbed("voiceDeletedDM");

                    await freelancer.send({ embeds: [voiceDeletedDMEmbed] });
                }
            }

            await database.manager.delete(VC, { channel: oldState.channelId });
        }
    }
}