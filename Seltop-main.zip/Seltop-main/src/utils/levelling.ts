import LevelText from "../tables/LevelText.js";
import LevelVC from "../tables/LevelVC.js";
import database from "../handlers/databaseHandler.js";
import { client } from "../index.js";
import config from "../config.js";
import { GuildTextBasedChannel } from "discord.js";

export function getRequiredXP(level: number) {
    return 5 * (level ** 2) + 50 * level + 100;
}

export async function addXP(userId: string, guildId: string, xp: number, levelText: boolean = false, levelVC: boolean = false) {
    if (levelText) {
        const levelTextData = await database.manager.findOne(LevelText, { where: { user: userId, guildId } });

        if (levelTextData) {
            levelTextData.xp = levelTextData.xp + xp;
            
            const requiredXP = getRequiredXP(levelTextData.level + 1);
            if (levelTextData.xp >= requiredXP) {
                levelTextData.level = levelTextData.level + 1;
                levelTextData.xp = levelTextData.xp - requiredXP;
                
                const levelUpChannel = client.channels.cache.get(config.channels.levelUp) as GuildTextBasedChannel;
                await levelUpChannel.send(`<@${userId}> **has levelled up to level ${levelTextData.level} in text!** 🎉`);
            }
            
            await database.manager.save(levelTextData);
        } else {
            await database.manager.insert(LevelText, {
                user: userId,
                guildId,
                level: 0,
                xp
            });
        }
    }

    if (levelVC) {
        const levelVCData = await database.manager.findOne(LevelVC, { where: { user: userId, guildId } });

        if (levelVCData) {
            levelVCData.xp = levelVCData.xp + xp;
    
            const requiredXP = getRequiredXP(levelVCData.level + 1);
            if (levelVCData.xp >= requiredXP) {
                levelVCData.level = levelVCData.level + 1;
                levelVCData.xp = levelVCData.xp - requiredXP;
    
                const levelUpChannel = client.channels.cache.get(config.channels.levelUp) as GuildTextBasedChannel;
                levelUpChannel.send(`<@${userId}> **has levelled up to level ${levelVCData.level} in voice!** 🎉`);
            }
    
            await database.manager.save(levelVCData);
        } else {
            await database.manager.insert(LevelVC, {
                user: userId,
                guildId,
                level: 0,
                xp
            });
        }
    }
}