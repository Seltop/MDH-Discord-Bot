import { GuildTextBasedChannel } from "discord.js";
import config from "../config.js";
import database from "../handlers/databaseHandler.js";
import { client } from "../index.js";
import Competition from "../tables/Competition.js";
import Elo from "../tables/Elo.js";
import Submission from "../tables/Submission.js";
import { buildEmbed } from "./configBuilders.js";

type SortedScore = { submission: number, score: number, public: number };

export async function endCompetition(competition: Competition, sortedScores: SortedScore[]) {

    const winners = sortedScores.slice(0, 3);
    const submissions = await database.manager.find(Submission, { where: { competition: competition.id } });

    const elos = [];

    for await (const submission of submissions) {
        const elo = await database.manager.findOne(Elo, { where: { user: submission.user } });
        const score = sortedScores.find((s) => s.submission === submission.id)?.score;
        if (!elo) {
            if (score < 4) elos.push({ user: submission.user, elo: 1000 });
            else if (score < 5) elos.push({ user: submission.user, elo: 1500 });
            else if (score < 6) elos.push({ user: submission.user, elo: 2500 });
            else if (score < 7) elos.push({ user: submission.user, elo: 3000 });
            else if (score <= 8) elos.push({ user: submission.user, elo: 5000 });
        } else {
            elos.push({ user: submission.user, elo: elo.elo });
        }
    }

    const averageElo = elos.reduce((acc, cur) => acc + cur.elo, 0) / elos.length;
    const eloDifferences = [];

    for (const submission of submissions) {
        const score = sortedScores.find((s) => s.submission === submission.id)?.score;
        const ratio = Math.min(score / averageElo, 1.5);
        const participantElo = elos.find((e) => e.user === submission.user)?.elo;
        let elo = Math.round(participantElo + (score * ratio * 100));
        const eloEntity = await database.manager.findOne(Elo, { where: { user: submission.user } });

        if (winners.find((w) => w.submission === submission.id)) {
            const place = winners.findIndex((w) => w.submission === submission.id);
            elo += place === 0 ? 300 : place === 1 ? 200 : 100;
        }

        const eloDifference = elo - participantElo;
        eloDifferences.push({ user: submission.user, difference: eloDifference, elo });

        if (eloEntity) {
            eloEntity.elo = elo;
            await database.manager.save(eloEntity);
        } else {
            await database.manager.insert(Elo, { user: submission.user, elo });
        }    
    }

    const embed = buildEmbed("eloDifference")
        .setDescription(`**Elo Changes for Competition: ${competition.name}**\n\n${eloDifferences.map((e) => `<@${e.user}>: **${e.elo}** (\`${e.difference > 0 ? "+" : ""}${e.difference}\`)`).join("\n")}`);

    const channel = await client.channels.fetch(config.channels.results) as GuildTextBasedChannel;
    await channel.send({ embeds: [embed] });

    for (const elo of eloDifferences) {
        const guild = await client.guilds.fetch(config.guildId);
        const member = await guild.members.fetch(elo.user).catch(() => null);
        
        if (!member) continue;

        const tier = elo.elo < 2500 ? config.eloTiers.tierThree : elo.elo < 5000 ? config.eloTiers.tierTwo : config.eloTiers.tierOne;
        const role = guild.roles.cache.get(tier.role);

        if (!role) continue;

        for (const role in config.eloTiers) {
            if (member.roles.cache.has(config.eloTiers[role].role) && config.eloTiers[role].role != tier.role) await member.roles.remove(config.eloTiers[role].role);
        }

        await member.roles.add(role);
    }

    await database.manager.update(Competition, { id: competition.id }, { completed: true });
}

/**
 * 4. **Elo Calculation**:
    - Post-competition, each user's Elo is recalculated.
    - The user’s score is taken and divided by the average Elo of all participants in the current competition. This ratio is capped at 1.5. The user's score is then multiplied by this ratio, and further multiplied by 100. The final number is rounded to the nearest integer and then added to the old Elo for the updated Elo score.
    - For a user’s first competition, the initial Elo is assigned based on their score like so:
        - 1-4: 1000 Elo
        - 4-5: 1500 Elo
        - 5-6: 2500 Elo
        - 6-7: 3000 Elo
        - 7-8: 5000 Elo

5. **Rewards and Elo Tiers**:
    - Winners are determined by the highest average score.
    - Additional Elo points are awarded to the top three positions:
        - First place: +300 Elo
        - Second place: +200 Elo
        - Third place: +100 Elo
    - Elo tiers are categorized as follows:
        - 1000 to 2500 Elo: Tier 3
        - 2500 to 5000 Elo: Tier 2
        - 5000 Elo and above: Tier 1
 */