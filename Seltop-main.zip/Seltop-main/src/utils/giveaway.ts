import Giveaway from "../tables/giveaway.js";
import database from "../handlers/databaseHandler.js";
import JoinedGiveaway from "../tables/joinedGiveaways.js";
import { buildEmbed } from "./configBuilders.js";
import config from "../config.js";
import { GuildTextBasedChannel } from "discord.js";

export async function updateGiveaway({ giveaway, prize, winners, length, endsAt, requiredRole }: { giveaway: Giveaway, prize?: string, winners?: number, length?: string, endsAt?: number, requiredRole?: string }) {
    await database.manager.update(Giveaway, { message: giveaway.message }, { 
        prize: prize || giveaway.prize,
        winners: winners || giveaway.winners,
        length: length || giveaway.length,
        endsAt: endsAt || giveaway.endsAt,
        requiredRole: requiredRole || giveaway.requiredRole
    });
}

export async function endGiveaway({ giveaway }: { giveaway: Giveaway }) {
    const { client } = await import("../index.js");

    await database.manager.update(Giveaway, { message: giveaway.message }, { ended: true });

    const entries = await database.manager.find(JoinedGiveaway, { where: { giveaway: giveaway.message } });
    const winners = entries.sort(() => Math.random() - Math.random()).slice(0, giveaway.winners);

    const winnerIDs = winners.map(winner => winner.user);

    const channel = await client.channels.fetch(giveaway.channel) as GuildTextBasedChannel;
    if (!channel) return;
    const message = await channel.messages.fetch(giveaway.message);
    if (!message) return;

    if (winnerIDs.length) {   
        for (const winner of winnerIDs) {
            const embed = buildEmbed("giveawayWinner").setDescription(config.embeds.giveawayWinner.description.replace("{winner}", `<@${winner}>`).replace("{prize}", giveaway.prize));
            
            await message.reply({ content: `<@${winner}>`, embeds: [embed] });
            
            const user = await client.users.fetch(winner);
            await user.send({ content: message.url, embeds: [embed] }).catch(() => null);
        }
    }
    const giveawayEndedEmbed = buildEmbed("giveawayEnded").setDescription(config.embeds.giveawayEnded.description.replace("{prize}", giveaway.prize).replace("{winners}", winnerIDs ? winnerIDs.map(winner => `<@${winner}>`).join(", ") : "None"));

    await message.edit({ embeds: [giveawayEndedEmbed], components: [] });
}