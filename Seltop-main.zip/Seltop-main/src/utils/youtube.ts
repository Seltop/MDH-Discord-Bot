import { google } from "googleapis";
import config from "../config.js";

export const youtube = google.youtube({
    version: "v3",
    auth: config.youtube.apiKey
});

export async function getYouTubeChannelId(channelName) {
    const response = await youtube.search.list({
        // @ts-ignore
        part: "snippet",
        q: channelName,
        type: "channel",
        maxResults: 1,
    });

    // @ts-ignore
    if (response.data.items.length > 0) {
    // @ts-ignore
        const channel = response.data.items[0];
        return channel.id.channelId;
    }

    return null;
}

export async function getYouTubeChannelName(channelId) {
    const response = await youtube.channels.list({
    // @ts-ignore
        part: "snippet",
        id: channelId,
    });

    // @ts-ignore
    if (response.data.items?.length > 0) {
    // @ts-ignore
        const channel = response.data.items[0];
        return channel.snippet.title;
    }

    return null;
}